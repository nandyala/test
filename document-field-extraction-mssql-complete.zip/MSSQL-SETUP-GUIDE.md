# MSSQL Configuration Guide - Document Field Extraction

## 📋 Overview

This guide covers setting up the Document Field Extraction service with Microsoft SQL Server (MSSQL) instead of MySQL, using the latest Spring Boot 3.3.0.

---

## 🔧 Prerequisites

### Software Required
- Java 17 or higher
- Maven 3.8+
- Microsoft SQL Server 2019 or later
- Tesseract OCR
- Git

### Supported MSSQL Versions
- SQL Server 2019
- SQL Server 2022
- Azure SQL Database
- SQL Server Express (for development)

---

## 📥 Installation Steps

### Step 1: Install MSSQL Server

#### Option A: Docker (Recommended for Development)

```bash
# Pull SQL Server image
docker pull mcr.microsoft.com/mssql/server:2022-latest

# Run SQL Server container
docker run -e "ACCEPT_EULA=Y" \
  -e "MSSQL_SA_PASSWORD=YourStrong@Password123" \
  -p 1433:1433 \
  --name mssql-server \
  -d mcr.microsoft.com/mssql/server:2022-latest

# Verify it's running
docker ps | grep mssql
```

#### Option B: Windows Installation

1. Download SQL Server from: https://www.microsoft.com/sql-server
2. Run installer (SqlServer2022-SSEI-Expr.exe)
3. Choose "Developer" or "Express" edition
4. Follow the installation wizard
5. Enable SQL Server Authentication with `sa` account
6. Set strong password: `YourStrong@Password123`

#### Option C: Linux (Ubuntu)

```bash
# Add Microsoft repository
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -
curl https://packages.microsoft.com/config/ubuntu/20.04/mssql-server-2022.list | sudo tee /etc/apt/sources.list.d/mssql-server-2022.list

# Install
sudo apt-get update
sudo apt-get install -y mssql-server

# Run setup
sudo /opt/mssql/bin/mssql-conf setup

# Start service
sudo systemctl start mssql-server
```

### Step 2: Create Database

```bash
# Connect using sqlcmd (Windows/Linux)
sqlcmd -S localhost -U sa -P YourStrong@Password123

# Or use Docker
docker exec -it mssql-server /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P YourStrong@Password123

# Create database
CREATE DATABASE document_extraction;
GO

# Verify
SELECT name FROM sys.databases;
GO

# Exit
EXIT
GO
```

### Step 3: Install Tesseract

```bash
# Ubuntu/Debian
sudo apt-get install tesseract-ocr tesseract-ocr-eng

# Windows (download from)
# https://github.com/UB-Mannheim/tesseract/wiki

# macOS
brew install tesseract
```

### Step 4: Update Application Configuration

Replace your `application.properties` with `application-mssql.properties`:

```bash
cd document-field-extraction
cp ../application-mssql.properties src/main/resources/
```

Edit `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=document_extraction;trustServerCertificate=true
spring.datasource.username=sa
spring.datasource.password=YourStrong@Password123
spring.datasource.driver-class-name=com.microsoft.sqlserver.jdbc.SQLServerDriver
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.SQLServer2016Dialect
spring.flyway.schemas=dbo
```

### Step 5: Update pom.xml

Replace database dependency section:

```xml
<!-- MSSQL Database Driver -->
<dependency>
    <groupId>com.microsoft.sqlserver</groupId>
    <artifactId>mssql-jdbc</artifactId>
    <version>12.6.0.jre11</version>
    <scope>runtime</scope>
</dependency>

<!-- Flyway for MSSQL -->
<dependency>
    <groupId>org.flywaydb</groupId>
    <artifactId>flyway-core</artifactId>
</dependency>

<dependency>
    <groupId>org.flywaydb</groupId>
    <artifactId>flyway-sqlserver</artifactId>
</dependency>

<!-- Spring Boot 3.3.0 -->
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.3.0</version>
</parent>
```

### Step 6: Setup Database Schema

Place `V1__Initial_schema.sql` in:
```
src/main/resources/db/migration/V1__Initial_schema.sql
```

### Step 7: Build and Run

```bash
# Clean build
mvn clean package -DskipTests

# Run application
java -jar target/document-field-extraction-2.0.0.jar

# Or with Maven
mvn spring-boot:run
```

---

## 🧪 Testing with Sample Documents

### Test Auto Loan Application

```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-auto-loan-application.pdf" \
  -F "fieldConfigs=@auto-loan-field-config.json"
```

### Test Credit Dispute

```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-credit-dispute.pdf" \
  -F "fieldConfigs=@credit-dispute-field-config.json"
```

---

## 📊 Querying MSSQL Results

### Connect to Database

```bash
# Using Docker
docker exec -it mssql-server /opt/mssql-tools/bin/sqlcmd \
  -S localhost -U sa -P YourStrong@Password123 \
  -d document_extraction

# Or directly
sqlcmd -S localhost -U sa -P YourStrong@Password123 -d document_extraction
```

### Common Queries

```sql
-- View all documents
SELECT id, document_name, status, created_at FROM dbo.documents;

-- View extracted fields for auto loan
SELECT field_name, field_value, validation_status, confidence 
FROM dbo.extracted_fields ef
JOIN dbo.documents d ON ef.document_id = d.id
WHERE d.document_name LIKE '%auto-loan%';

-- View extracted fields for credit dispute
SELECT field_name, field_value, validation_status, confidence 
FROM dbo.extracted_fields ef
JOIN dbo.documents d ON ef.document_id = d.id
WHERE d.document_name LIKE '%credit-dispute%';

-- View validation summary
SELECT * FROM dbo.document_validation_summary;

-- Get auto loan application fields
SELECT field_name, field_value 
FROM dbo.extracted_fields 
WHERE field_name IN ('applicant_name', 'annual_income', 'vehicle_make', 'amount_to_finance')
ORDER BY created_at DESC;

-- Get credit dispute info
SELECT field_name, field_value 
FROM dbo.extracted_fields 
WHERE field_name IN ('consumer_name', 'dispute_type', 'reported_amount', 'relief_requested')
ORDER BY created_at DESC;
```

---

## 🔌 MSSQL JDBC Driver Features

### Connection String Options

```
# Basic
jdbc:sqlserver://localhost:1433;databaseName=document_extraction

# With authentication
jdbc:sqlserver://localhost:1433;databaseName=document_extraction;user=sa;password=YourPassword

# With SSL/TLS
jdbc:sqlserver://localhost:1433;databaseName=document_extraction;encrypt=true;trustServerCertificate=true

# With connection pooling
jdbc:sqlserver://localhost:1433;databaseName=document_extraction;maxPoolSize=10;minPoolSize=5
```

### Configuration Properties

```properties
# Timeout settings
spring.datasource.hikari.connection-timeout=20000
spring.datasource.hikari.maximum-pool-size=20
spring.datasource.hikari.idle-timeout=300000
spring.datasource.hikari.max-lifetime=1200000

# MSSQL specific
spring.datasource.sqlserver.authentication=sqlPassword
spring.jpa.database-platform=org.hibernate.dialect.SQLServer2016Dialect
spring.jpa.hibernate.ddl-auto=validate
```

---

## 🐳 Docker Compose for Complete Stack

```yaml
version: '3.8'

services:
  mssql:
    image: mcr.microsoft.com/mssql/server:2022-latest
    environment:
      ACCEPT_EULA: "Y"
      MSSQL_SA_PASSWORD: "YourStrong@Password123"
    ports:
      - "1433:1433"
    volumes:
      - mssql-data:/var/opt/mssql

  app:
    build: .
    ports:
      - "8081:8081"
    environment:
      SPRING_DATASOURCE_URL: jdbc:sqlserver://mssql:1433;databaseName=document_extraction;trustServerCertificate=true
      SPRING_DATASOURCE_USERNAME: sa
      SPRING_DATASOURCE_PASSWORD: YourStrong@Password123
    depends_on:
      - mssql

volumes:
  mssql-data:
```

Run with: `docker-compose up -d`

---

## 🔐 Security Best Practices

### For Production

1. **Never use SA account** - Create application user:
```sql
CREATE LOGIN app_user WITH PASSWORD = 'SecureAppPassword123!';
CREATE USER app_user FOR LOGIN app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.documents TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.extracted_fields TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.document_metadata TO app_user;
```

2. **Enable Encryption**:
```properties
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=document_extraction;encrypt=true;trustServerCertificate=false;hostNameInCertificate=your-domain.com
```

3. **Use Environment Variables**:
```bash
export SPRING_DATASOURCE_PASSWORD=YourSecurePassword
export SPRING_DATASOURCE_USERNAME=app_user
```

4. **Configure SSL/TLS**:
```properties
server.ssl.key-store=classpath:keystore.p12
server.ssl.key-store-password=keystorePassword
server.ssl.key-store-type=PKCS12
```

---

## 📈 Performance Tuning for MSSQL

### Index Optimization

```sql
-- Create composite indexes for common queries
CREATE INDEX idx_document_status_date 
  ON dbo.documents(status, created_at DESC);

CREATE INDEX idx_extraction_field_validation 
  ON dbo.extracted_fields(document_id, field_name, validation_status);

-- Check index usage
SELECT 
    OBJECT_NAME(i.object_id) AS TableName,
    i.name AS IndexName,
    s.user_updates,
    s.user_seeks,
    s.user_scans,
    s.user_lookups
FROM sys.indexes i
LEFT JOIN sys.dm_db_index_usage_stats s 
    ON i.object_id = s.object_id 
    AND i.index_id = s.index_id
WHERE database_id = DB_ID()
ORDER BY (s.user_seeks + s.user_scans + s.user_lookups) DESC;
```

### Connection Pooling

```properties
spring.datasource.hikari.maximum-pool-size=20
spring.datasource.hikari.minimum-idle=5
spring.datasource.hikari.connection-timeout=20000
spring.datasource.hikari.idle-timeout=300000
spring.datasource.hikari.max-lifetime=1200000
```

### Batch Processing

```properties
spring.jpa.properties.hibernate.jdbc.batch_size=20
spring.jpa.properties.hibernate.order_inserts=true
spring.jpa.properties.hibernate.order_updates=true
```

---

## 🔧 Troubleshooting

### Cannot Connect to MSSQL

```bash
# Check if MSSQL is running (Docker)
docker ps | grep mssql

# Test connection using sqlcmd
sqlcmd -S localhost -U sa -P YourStrong@Password123

# Check SQL Server logs (Docker)
docker logs mssql-server
```

### Firewall Issues

```bash
# Windows
netsh advfirewall firewall add rule name="Allow SQL Server" dir=in action=allow protocol=tcp localport=1433

# Linux
sudo ufw allow 1433/tcp
sudo ufw allow 1433/udp
```

### Authentication Failed

Verify credentials in `application.properties`:
```properties
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=document_extraction;trustServerCertificate=true
spring.datasource.username=sa
spring.datasource.password=YourStrong@Password123
```

### Database Not Created

Run manually:
```bash
sqlcmd -S localhost -U sa -P YourStrong@Password123 -Q "CREATE DATABASE document_extraction;"
```

---

## 📚 Useful Resources

- MSSQL JDBC Driver: https://github.com/microsoft/mssql-jdbc
- Spring Boot MSSQL Guide: https://spring.io/guides
- MSSQL Documentation: https://docs.microsoft.com/sql
- Flyway MSSQL Support: https://flywaydb.org/documentation/database/sqlserver

---

## ✅ Verification Checklist

- [ ] MSSQL Server installed and running
- [ ] Database `document_extraction` created
- [ ] Tesseract OCR installed
- [ ] Java 17+ installed
- [ ] Maven 3.8+ installed
- [ ] `application.properties` updated with MSSQL connection
- [ ] pom.xml has MSSQL JDBC driver
- [ ] Flyway migration scripts in place
- [ ] Application builds successfully
- [ ] Sample PDFs and configs downloaded
- [ ] API responds at http://localhost:8081/swagger-ui.html

---

**Your MSSQL setup is complete! Happy extracting! 🚀**
