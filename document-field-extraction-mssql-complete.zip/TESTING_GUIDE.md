# Testing Guide - Using Sample Invoice

## 📄 Sample Files Included

I've created two sample files for you to test immediately:

### 1. **sample-invoice.pdf** (3.3 KB)
A complete sample invoice with:
- Invoice number: INV-001234
- Invoice date: 05/15/2024
- Due date: 06/15/2024
- PO number: PO-2024-5678
- Company: Acme Corporation
- Customer: ABC Industries
- Amounts: Subtotal $8,250, Tax $825, Shipping $50, Total $9,125
- Contact info: Phone, email, addresses

### 2. **sample-field-config.json** (3.5 KB)
Configuration to extract all fields from the invoice:
- Invoice number (INV-001234)
- Invoice date (05/15/2024)
- Due date (06/15/2024)
- PO number (PO-2024-5678)
- Company name (Acme Corporation)
- Customer phone
- Customer email
- Subtotal, Tax, Shipping, Total amounts

---

## 🚀 Quick Test (10 minutes)

### Step 1: Extract ZIP and Setup
```bash
unzip document-field-extraction-complete.zip
cd document-field-extraction

# Install MySQL
docker run -d --name mysql \
  -e MYSQL_ROOT_PASSWORD=password \
  -e MYSQL_DATABASE=document_extraction \
  -p 3306:3306 mysql:8.0

# Install Tesseract
sudo apt-get install tesseract-ocr

# Update database credentials if needed
# Edit: src/main/resources/application.properties
```

### Step 2: Build Application
```bash
mvn clean package
```

### Step 3: Start Application
```bash
java -jar target/document-field-extraction-1.0.0.jar
```

Wait for: `Started DocumentFieldExtractionApplication in X seconds`

### Step 4: Test Extraction
```bash
# Extract fields from sample invoice
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-invoice.pdf" \
  -F "fieldConfigs=@sample-field-config.json" \
  -H "Accept: application/json" | jq
```

### Step 5: Check Results
You should see:
```json
{
  "documentId": "550e8400-e29b-41d4...",
  "status": "COMPLETED",
  "extractedFields": [
    {
      "fieldName": "invoice_number",
      "fieldValue": "INV-001234",
      "validationStatus": "VALID",
      "confidence": 0.95
    },
    {
      "fieldName": "invoice_date",
      "fieldValue": "05/15/2024",
      "validationStatus": "VALID",
      "confidence": 0.98
    },
    ...
  ]
}
```

---

## 📊 Expected Results

When you run the test, here's what should be extracted:

| Field | Expected Value | Confidence |
|-------|----------------|-----------|
| invoice_number | INV-001234 | 0.95-0.99 |
| invoice_date | 05/15/2024 | 0.98-0.99 |
| due_date | 06/15/2024 | 0.98-0.99 |
| purchase_order | PO-2024-5678 | 0.95-0.99 |
| company_name | Acme Corporation | 0.90-0.95 |
| customer_phone | 5559876543 | 0.90-0.95 |
| subtotal | 8250.00 | 0.98-0.99 |
| tax_amount | 825.00 | 0.98-0.99 |
| shipping_amount | 50.00 | 0.98-0.99 |
| total_amount | 9125.00 | 0.99 |

---

## 🔍 View Results in Database

After extraction, query the database:

```bash
# Connect to MySQL
mysql -u root -p -h localhost

# Use the database
USE document_extraction;

# See all documents
SELECT id, document_name, status, created_at FROM documents;

# See all extracted fields
SELECT field_name, field_value, validation_status, confidence 
FROM extracted_fields;

# Get document summary
SELECT 
    d.document_name,
    COUNT(ef.id) as total_fields,
    SUM(CASE WHEN ef.validation_status = 'VALID' THEN 1 END) as valid_fields,
    ROUND(AVG(ef.confidence), 2) as avg_confidence
FROM documents d
LEFT JOIN extracted_fields ef ON d.id = ef.document_id
GROUP BY d.id;
```

---

## 🌐 API Testing

### Option 1: Swagger UI (Browser)
```
http://localhost:8081/swagger-ui.html
```
- Click "Try it out" on `/api/v1/extraction/extract`
- Upload sample-invoice.pdf
- Upload sample-field-config.json
- Click "Execute"

### Option 2: cURL (Command Line)
```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-invoice.pdf" \
  -F "fieldConfigs=@sample-field-config.json" \
  -H "Accept: application/json"
```

### Option 3: Postman
1. Create POST request to: `http://localhost:8081/api/v1/extraction/extract`
2. Set Auth: Basic Auth (user/password123)
3. Set Body: form-data
   - Key: "file" → Value: sample-invoice.pdf (file)
   - Key: "fieldConfigs" → Value: sample-field-config.json (file)
4. Send

---

## 📋 Field Configuration Breakdown

The `sample-field-config.json` extracts these fields:

### Invoice Number
```json
{
  "fieldName": "invoice_number",
  "fieldType": "TEXT",
  "keywords": ["Invoice #"],
  "regexPattern": "INV-\\d{6}",
  "validationRules": {"pattern": "INV-\\d{6}"}
}
```
✅ Searches for "Invoice #" keyword
✅ Validates with regex pattern INV-XXXXXX
✅ Results in: INV-001234

### Invoice Date
```json
{
  "fieldName": "invoice_date",
  "fieldType": "DATE",
  "keywords": ["Invoice Date:"],
  "validationRules": {"pattern": "\\d{1,2}/\\d{1,2}/\\d{4}"}
}
```
✅ Searches for "Invoice Date:" keyword
✅ Validates date format MM/DD/YYYY
✅ Results in: 05/15/2024

### Total Amount
```json
{
  "fieldName": "total_amount",
  "fieldType": "CURRENCY",
  "keywords": ["Total:"],
  "regexPattern": "Total:\\s*\\$([\\d,]+\\.\\d{2})",
  "transformations": ["REMOVE_SPECIAL_CHARS"],
  "validationRules": {"pattern": "^\\d+(\\.\\d{2})?$"}
}
```
✅ Searches for "Total:" keyword
✅ Extracts currency with regex
✅ Removes special characters
✅ Results in: 9125.00

---

## ✅ Troubleshooting

### Issue: "Connection refused" to database
**Solution**:
```bash
# Check MySQL is running
docker ps | grep mysql

# If not running, start it
docker run -d --name mysql \
  -e MYSQL_ROOT_PASSWORD=password \
  -e MYSQL_DATABASE=document_extraction \
  -p 3306:3306 mysql:8.0
```

### Issue: "Invalid field type" error
**Solution**:
- Check field config JSON syntax
- Verify all required fields are present
- Ensure field types are valid (TEXT, DATE, CURRENCY, etc.)

### Issue: Low confidence scores
**Solution**:
- Check PDF quality
- Adjust keywords in config
- Use more specific regex patterns
- Enable image enhancement if needed

### Issue: Fields not found
**Solution**:
- Verify keywords appear in the invoice
- Check regex pattern matches the text
- Try broader keyword search
- Check page number setting

---

## 🔄 Test Different Variations

### Test 1: Synchronous Extraction (Immediate)
```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-invoice.pdf" \
  -F "fieldConfigs=@sample-field-config.json"
```
Returns: Complete results immediately

### Test 2: Asynchronous Processing (Background)
```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract-async \
  -u user:password123 \
  -F "file=@sample-invoice.pdf" \
  -F "fieldConfigs=@sample-field-config.json" \
  -F "callbackUrl=https://yourserver.com/callback"
```
Returns: Job ID for tracking

### Test 3: Retrieve Extracted Fields
```bash
# After extraction, get the document ID and retrieve fields
curl http://localhost:8081/api/v1/extraction/fields/{documentId} \
  -u user:password123
```

---

## 📊 What Gets Stored

After extraction, the database contains:

### documents table
```
id: 550e8400-e29b-41d4-a716-446655440000
document_name: sample-invoice.pdf
document_type: PDF
status: COMPLETED
page_count: 1
created_at: 2024-05-15 19:15:00
```

### extracted_fields table
```
document_id: 550e8400-e29b-41d4-a716-446655440000
field_name: invoice_number
field_value: INV-001234
validation_status: VALID
confidence: 0.95
page_number: 0
extraction_method: KEYWORD_MATCHING
```

---

## 🎯 Next Steps

After successful test:

1. **Customize Configuration**
   - Modify sample-field-config.json for your fields
   - Add more field types (email, phone, etc.)
   - Adjust keywords and patterns

2. **Test with Your Documents**
   - Extract fields from your actual invoices
   - Monitor confidence scores
   - Adjust patterns based on results

3. **Deploy**
   - Use provided Docker/Kubernetes configs
   - Set up monitoring and alerts
   - Configure production database

4. **Monitor Results**
   - Track extraction success rates
   - Review low-confidence fields
   - Continuously improve patterns

---

## 📞 Need Help?

- Check **QUICK_START.md** for setup issues
- See **IMPLEMENTATION_GUIDE.md** for technical details
- Review **document-field-extraction/README.md** for API reference
- Check log output for error messages

---

## ✨ You're All Set!

Everything you need to test field extraction is included:
- ✅ Sample PDF invoice
- ✅ Sample field configuration
- ✅ Complete source code
- ✅ Database setup scripts
- ✅ API documentation

**Run the test now and see your fields extracted automatically!** 🚀
