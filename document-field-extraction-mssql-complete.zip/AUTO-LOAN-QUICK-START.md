# 🚀 Auto Loan & Credit Dispute Extraction - Quick Start

## 📦 What You Have

**auto-loan-extraction-complete.zip** (34 KB) contains:

✅ Spring Boot 3.3 application (Java 21)
✅ SQL Server JDBC integration
✅ PDF field extraction engine
✅ Sample auto loan application PDF
✅ Sample credit dispute PDF
✅ Pre-configured field extractors
✅ Complete source code

## ⚡ 5-Minute Setup

### Step 1: Start SQL Server (1 minute)

```bash
docker run -e "ACCEPT_EULA=Y" -e "MSSQL_SA_PASSWORD=YourPassword123!" \
  -p 1433:1433 \
  --name mssql \
  -d mcr.microsoft.com/mssql/server:2022-latest

# Wait for startup
sleep 10

# Create database
sqlcmd -S localhost -U sa -P YourPassword123! -Q "CREATE DATABASE auto_loan_db"
```

### Step 2: Extract & Build (2 minutes)

```bash
unzip auto-loan-extraction-complete.zip
cd auto-loan-extraction

mvn clean package
```

### Step 3: Run Application (1 minute)

```bash
java -jar target/auto-loan-extraction-1.0.0.jar
```

Wait for: `Started AutoLoanExtractionApplication`

### Step 4: Test Extraction (1 minute)

**Option A: Command Line**
```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-auto-loan-application.pdf" \
  -F "fieldConfigs=@examples/auto-loan-config.json" | jq
```

**Option B: Swagger UI**
```
http://localhost:8081/swagger-ui.html
```

Click "Try it out" on `/api/v1/extraction/extract`

## 📋 Default Credentials

```
Username: user
Password: password123
```

## 📊 What Gets Extracted

### Auto Loan Fields
- ✅ Borrower Name, DOB, SSN
- ✅ Phone, Email
- ✅ Vehicle Year, Make, Model, VIN
- ✅ Loan Amount, Down Payment, Term
- ✅ Annual Income, Employment Years
- ✅ Marital Status, Co-Borrower

### Credit Dispute Fields
- ✅ Consumer Name, DOB, SSN
- ✅ Phone, Email, Address
- ✅ Disputed Account Types
- ✅ Creditor Names & Amounts
- ✅ Dispute Reasons
- ✅ Supporting Documents
- ✅ Case Reference Numbers

## 💾 SQL Server Configuration

**Connection String:**
```
jdbc:sqlserver://localhost:1433;databaseName=auto_loan_db;encrypt=false
Username: sa
Password: YourPassword123!
```

**Update in:** `src/main/resources/application.properties`

## 📁 Project Structure

```
auto-loan-extraction/
├── pom.xml (Spring Boot 3.3, SQL Server JDBC)
├── README.md (Full documentation)
├── examples/
│   ├── auto-loan-config.json (16 fields)
│   └── credit-dispute-config.json (13 fields)
├── src/main/java/com/example/autoloan/
│   ├── AutoLoanExtractionApplication.java
│   ├── config/DataSourceConfig.java (SQL Server)
│   ├── controller/DocumentExtractionController.java (REST API)
│   ├── service/DocumentExtractionService.java
│   ├── service/FieldValidationService.java
│   ├── service/extractor/PdfFieldExtractor.java
│   ├── entity/Document.java (JPA Entity)
│   ├── entity/ExtractedField.java (JPA Entity)
│   ├── repository/ (Data access layer)
│   └── dto/ (Request/Response)
└── src/main/resources/
    └── application.properties
```

## 🔧 Technology Stack

- **Spring Boot**: 3.3.0
- **Java**: 21
- **Database**: SQL Server with JDBC Driver 12.6.1
- **PDF**: Apache PDFBox 3.0.0
- **ORM**: JPA/Hibernate
- **API Docs**: Swagger/OpenAPI 2.3.0

## 📝 Sample Extraction Request

```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-auto-loan-application.pdf" \
  -F "fieldConfigs=@examples/auto-loan-config.json" \
  -H "Accept: application/json" | jq '.'
```

## 📊 Response Example

```json
{
  "documentId": 1,
  "documentName": "sample-auto-loan-application.pdf",
  "documentType": "AUTO_LOAN_APPLICATION",
  "status": "COMPLETED",
  "extractedFields": [
    {
      "fieldName": "borrower_full_name",
      "fieldValue": "John Michael Smith",
      "validationStatus": "VALID",
      "confidence": 0.95,
      "pageNumber": 0
    },
    {
      "fieldName": "loan_amount",
      "fieldValue": "52000.00",
      "validationStatus": "VALID",
      "confidence": 0.98,
      "pageNumber": 0
    }
  ],
  "metrics": {
    "totalFieldsExtracted": 16,
    "validFields": 15,
    "invalidFields": 0,
    "averageConfidence": 0.92,
    "successRate": 0.9375
  }
}
```

## 🎯 Common Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/v1/extraction/extract` | POST | Synchronous extraction |
| `/api/v1/extraction/extract-async` | POST | Async background job |
| `/api/v1/extraction/document/{id}` | GET | Get document details |
| `/api/v1/extraction/fields/{id}` | GET | Get extracted fields |
| `/api/v1/extraction/health` | GET | Health check |
| `/swagger-ui.html` | GET | API documentation |
| `/actuator/metrics` | GET | Application metrics |

## 🔍 Test Both PDFs

```bash
# Auto Loan
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-auto-loan-application.pdf" \
  -F "fieldConfigs=@examples/auto-loan-config.json"

# Credit Dispute
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@sample-credit-dispute.pdf" \
  -F "fieldConfigs=@examples/credit-dispute-config.json"
```

## 🗄️ Database Tables

### documents
- Stores document metadata
- Tracks processing status
- File checksums for deduplication

### extracted_fields
- Individual extracted field values
- Validation status
- Confidence scores
- Extraction method used

Both tables are auto-created by Hibernate!

## ⚙️ Customization

### Add Custom Fields

Edit `examples/auto-loan-config.json`:

```json
{
  "fieldName": "your_field_name",
  "fieldType": "TEXT",
  "label": "Your Field Label",
  "required": true,
  "keywords": ["Search Text:", "Keywords"],
  "transformations": ["TRIM"],
  "validationRules": {
    "minLength": 1,
    "maxLength": 255
  }
}
```

### Field Types

- TEXT, EMAIL, PHONE, DATE, NUMERIC, CURRENCY, SSN

## 🆘 Troubleshooting

### SQL Server Connection Failed
```bash
# Check Docker is running
docker ps

# Check SQL Server is ready
sqlcmd -S localhost -U sa -P YourPassword123! -Q "SELECT 1"
```

### Port Already in Use
```bash
# Use different port
# Change server.port in application.properties
server.port=8082
```

### PDF Extraction Not Working
- Verify PDF exists
- Check keywords are correct
- Test regex patterns
- Enable debug logging

## 📞 Help

- **API Docs**: http://localhost:8081/swagger-ui.html
- **Health**: http://localhost:8081/api/v1/extraction/health
- **README**: See `auto-loan-extraction/README.md`

## 🎉 You're Ready!

1. ✅ Start SQL Server
2. ✅ Extract ZIP
3. ✅ Build project
4. ✅ Run application
5. ✅ Extract fields!

**Total time: 5 minutes from download to working extraction** 🚀
