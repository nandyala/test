-- V1__Initial_schema.sql for MSSQL
-- Documents table
IF OBJECT_ID('dbo.documents', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.documents (
        id NVARCHAR(36) PRIMARY KEY,
        document_name NVARCHAR(255) NOT NULL,
        document_type NVARCHAR(50) NOT NULL,
        file_path NVARCHAR(MAX) NOT NULL,
        raw_content NVARCHAR(MAX),
        status NVARCHAR(50) NOT NULL,
        processing_error NVARCHAR(MAX),
        file_size BIGINT,
        page_count INT,
        checksum NVARCHAR(255),
        created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
    );
    
    CREATE INDEX idx_status ON dbo.documents(status);
    CREATE INDEX idx_document_type ON dbo.documents(document_type);
    CREATE INDEX idx_checksum ON dbo.documents(checksum);
END

-- Extracted fields table
IF OBJECT_ID('dbo.extracted_fields', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.extracted_fields (
        id NVARCHAR(36) PRIMARY KEY,
        document_id NVARCHAR(36) NOT NULL,
        field_name NVARCHAR(255) NOT NULL,
        field_type NVARCHAR(50),
        field_value NVARCHAR(MAX),
        confidence DECIMAL(3,2),
        page_number INT,
        bounding_box_x FLOAT,
        bounding_box_y FLOAT,
        bounding_box_width FLOAT,
        bounding_box_height FLOAT,
        extraction_method NVARCHAR(50),
        raw_text NVARCHAR(MAX),
        validation_status NVARCHAR(50),
        validation_notes NVARCHAR(MAX),
        manually_verified BIT,
        created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        updated_at DATETIME2 NOT NULL,
        CONSTRAINT FK_documents FOREIGN KEY (document_id) REFERENCES dbo.documents(id) ON DELETE CASCADE
    );
    
    CREATE INDEX idx_document_id ON dbo.extracted_fields(document_id);
    CREATE INDEX idx_field_name ON dbo.extracted_fields(field_name);
    CREATE INDEX idx_field_type ON dbo.extracted_fields(field_type);
    CREATE INDEX idx_validation_status ON dbo.extracted_fields(validation_status);
END

-- Document metadata table
IF OBJECT_ID('dbo.document_metadata', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.document_metadata (
        id NVARCHAR(36) PRIMARY KEY,
        document_id NVARCHAR(36) NOT NULL,
        metadata_key NVARCHAR(255) NOT NULL,
        metadata_value NVARCHAR(MAX),
        data_type NVARCHAR(50),
        CONSTRAINT FK_documents_metadata FOREIGN KEY (document_id) REFERENCES dbo.documents(id) ON DELETE CASCADE
    );
    
    CREATE INDEX idx_document_metadata ON dbo.document_metadata(document_id);
    CREATE INDEX idx_metadata_key ON dbo.document_metadata(metadata_key);
END

-- Create view for validation summary
IF OBJECT_ID('dbo.document_validation_summary', 'V') IS NOT NULL
    DROP VIEW dbo.document_validation_summary;

CREATE VIEW dbo.document_validation_summary AS
SELECT 
    d.id,
    d.document_name,
    d.status,
    COUNT(ef.id) as total_fields,
    SUM(CASE WHEN ef.validation_status = 'VALID' THEN 1 ELSE 0 END) as valid_fields,
    SUM(CASE WHEN ef.validation_status = 'INVALID' THEN 1 ELSE 0 END) as invalid_fields,
    SUM(CASE WHEN ef.validation_status = 'NEEDS_REVIEW' THEN 1 ELSE 0 END) as needs_review,
    AVG(CAST(ef.confidence AS FLOAT)) as avg_confidence
FROM dbo.documents d
LEFT JOIN dbo.extracted_fields ef ON d.id = ef.document_id
GROUP BY d.id, d.document_name, d.status;
