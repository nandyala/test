// AiWriter - small Windows tool to send text to Azure OpenAI or Claude (Anthropic API)
// Written in C# 5 so it compiles with the csc.exe built into Windows (.NET Framework 4.x).
// All providers and prompts are defined in config.json - no code change needed to add more.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace AiWriter
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            // Corporate endpoints require TLS 1.2 (value 3072); .NET 4.0-4.5 doesn't enable it by default
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            string path = args.Length > 0 ? args[0] : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.json");
            Application.Run(new MainForm(path));
        }
    }

    class MainForm : Form
    {
        ComboBox cboProvider, cboAction;
        TextBox txtExtra, txtInput, txtOutput;
        Button btnRun, btnCopy, btnSwap, btnAttach, btnClearImg;
        List<string[]> images = new List<string[]>(); // {mediaType, base64}
        Label lblStatus;

        List<Dictionary<string, object>> providers = new List<Dictionary<string, object>>();
        List<Dictionary<string, object>> actions = new List<Dictionary<string, object>>();
        HttpClient http;
        string configPath;

        public MainForm(string configPath)
        {
            this.configPath = configPath;
            BuildUi();
            LoadConfig();
            BuildHttp();
        }

        // ---------------- UI ----------------
        void BuildUi()
        {
            Text = "AI Writer";
            Width = 1000; Height = 700;
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 9.5f);
            KeyPreview = true;
            KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Control && e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; RunClicked(null, null); }
            };

            FlowLayoutPanel top = new FlowLayoutPanel();
            top.Dock = DockStyle.Top; top.AutoSize = true; top.Padding = new Padding(8);
            top.WrapContents = false;

            cboProvider = new ComboBox(); cboProvider.DropDownStyle = ComboBoxStyle.DropDownList; cboProvider.Width = 180;
            cboAction = new ComboBox(); cboAction.DropDownStyle = ComboBoxStyle.DropDownList; cboAction.Width = 220;
            txtExtra = new TextBox(); txtExtra.Width = 380;

            top.Controls.Add(Lbl("Provider:")); top.Controls.Add(cboProvider);
            top.Controls.Add(Lbl("  Action:")); top.Controls.Add(cboAction);
            top.Controls.Add(Lbl("  Extra instruction (optional):")); top.Controls.Add(txtExtra);

            SplitContainer split = new SplitContainer();
            split.Dock = DockStyle.Fill;
            split.Orientation = Orientation.Horizontal;

            txtInput = MultiLine(); txtOutput = MultiLine(); txtOutput.ReadOnly = false;
            split.Panel1.Controls.Add(Wrap("Input", txtInput));
            split.Panel2.Controls.Add(Wrap("Output", txtOutput));

            FlowLayoutPanel bottom = new FlowLayoutPanel();
            bottom.Dock = DockStyle.Bottom; bottom.AutoSize = true; bottom.Padding = new Padding(8);

            btnRun = new Button(); btnRun.Text = "Run (Ctrl+Enter)"; btnRun.AutoSize = true; btnRun.Click += RunClicked;
            btnCopy = new Button(); btnCopy.Text = "Copy output"; btnCopy.AutoSize = true;
            btnCopy.Click += delegate { if (txtOutput.Text.Length > 0) Clipboard.SetText(txtOutput.Text); lblStatus.Text = "Copied."; };
            btnSwap = new Button(); btnSwap.Text = "Output -> Input"; btnSwap.AutoSize = true;
            btnSwap.Click += delegate { txtInput.Text = txtOutput.Text; txtOutput.Clear(); };
            btnAttach = new Button(); btnAttach.Text = "Attach file..."; btnAttach.AutoSize = true; btnAttach.Click += AttachClicked;
            btnClearImg = new Button(); btnClearImg.Text = "Clear images"; btnClearImg.AutoSize = true; btnClearImg.Visible = false;
            btnClearImg.Click += delegate { images.Clear(); btnClearImg.Visible = false; lblStatus.Text = "Images cleared."; };
            lblStatus = new Label(); lblStatus.AutoSize = true; lblStatus.Padding = new Padding(10, 7, 0, 0);

            bottom.Controls.Add(btnRun); bottom.Controls.Add(btnAttach); bottom.Controls.Add(btnClearImg); bottom.Controls.Add(btnCopy); bottom.Controls.Add(btnSwap); bottom.Controls.Add(lblStatus);

            Controls.Add(split);
            Controls.Add(bottom);
            Controls.Add(top);
            Shown += delegate { split.SplitterDistance = split.Height / 2; };
        }

        static Label Lbl(string t)
        {
            Label l = new Label(); l.Text = t; l.AutoSize = true; l.Padding = new Padding(0, 6, 0, 0); return l;
        }

        static TextBox MultiLine()
        {
            TextBox t = new TextBox();
            t.Multiline = true; t.ScrollBars = ScrollBars.Vertical; t.Dock = DockStyle.Fill; t.AcceptsReturn = true;
            t.Font = new Font("Consolas", 10f);
            return t;
        }

        static Control Wrap(string title, Control c)
        {
            GroupBox g = new GroupBox(); g.Text = title; g.Dock = DockStyle.Fill; g.Padding = new Padding(6);
            g.Controls.Add(c);
            return g;
        }

        // ---------------- Config ----------------
        static JavaScriptSerializer Json()
        {
            JavaScriptSerializer s = new JavaScriptSerializer();
            s.MaxJsonLength = int.MaxValue;
            return s;
        }

        void LoadConfig()
        {
            try
            {
                var root = (Dictionary<string, object>)Json().DeserializeObject(File.ReadAllText(configPath));
                foreach (object o in (IList)root["providers"]) providers.Add((Dictionary<string, object>)o);
                foreach (object o in (IList)root["actions"]) actions.Add((Dictionary<string, object>)o);
                foreach (var p in providers) cboProvider.Items.Add(S(p, "name", "?"));
                foreach (var a in actions) cboAction.Items.Add(S(a, "name", "?"));
                if (cboProvider.Items.Count > 0) cboProvider.SelectedIndex = 0;
                if (cboAction.Items.Count > 0) cboAction.SelectedIndex = 0;
                lblStatus.Text = "Config loaded: " + configPath;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load config:\n" + configPath + "\n\n" + ex.Message, "AI Writer");
                btnRun.Enabled = false;
            }
        }

        void BuildHttp()
        {
            HttpClientHandler h = new HttpClientHandler();
            // Use the system proxy with the current Windows login (typical corporate setup)
            IWebProxy proxy = WebRequest.GetSystemWebProxy();
            proxy.Credentials = CredentialCache.DefaultCredentials;
            h.Proxy = proxy; h.UseProxy = true;
            http = new HttpClient(h);
            http.Timeout = TimeSpan.FromMinutes(3);
        }

        static string S(Dictionary<string, object> d, string key, string def)
        {
            object v;
            if (d.TryGetValue(key, out v) && v != null) return v.ToString();
            return def;
        }

        // ---------------- Attachments ----------------
        // Text/code files and .docx are inserted into Input as text; images are sent as vision input.
        // shortcut: no PDF/xlsx parsing, no size check (APIs reject images over ~5 MB), upgrade if needed.
        void AttachClicked(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Multiselect = true;
            dlg.Filter = "Supported|*.txt;*.md;*.csv;*.json;*.xml;*.log;*.html;*.docx;*.png;*.jpg;*.jpeg;*.gif;*.webp|All files|*.*";
            if (dlg.ShowDialog() != DialogResult.OK) return;
            foreach (string f in dlg.FileNames)
            {
                try
                {
                    string ext = Path.GetExtension(f).ToLowerInvariant();
                    string mt = ext == ".png" ? "image/png" : ext == ".gif" ? "image/gif" : ext == ".webp" ? "image/webp"
                        : (ext == ".jpg" || ext == ".jpeg") ? "image/jpeg" : null;
                    if (mt != null) images.Add(new string[] { mt, Convert.ToBase64String(File.ReadAllBytes(f)) });
                    else
                    {
                        string t = ext == ".docx" ? ReadDocx(f) : File.ReadAllText(f);
                        txtInput.AppendText((txtInput.TextLength > 0 ? "\r\n\r\n" : "") + "--- " + Path.GetFileName(f) + " ---\r\n" + t.Replace("\r\n", "\n").Replace("\n", "\r\n"));
                    }
                }
                catch (Exception ex) { MessageBox.Show("Could not read " + f + "\n\n" + ex.Message, "AI Writer"); }
            }
            btnClearImg.Visible = images.Count > 0;
            lblStatus.Text = images.Count + " image(s) attached.";
        }

        static string ReadDocx(string path)
        {
            using (ZipArchive z = ZipFile.OpenRead(path))
            using (StreamReader r = new StreamReader(z.GetEntry("word/document.xml").Open(), Encoding.UTF8))
            {
                string x = r.ReadToEnd().Replace("</w:p>", "\n").Replace("<w:tab/>", "\t").Replace("<w:br/>", "\n");
                return WebUtility.HtmlDecode(Regex.Replace(x, "<[^>]+>", ""));
            }
        }

        // ---------------- Run ----------------
        async void RunClicked(object sender, EventArgs e)
        {
            if (!btnRun.Enabled) return;
            if (txtInput.Text.Trim().Length == 0) { lblStatus.Text = "Enter some input text first."; return; }
            var provider = providers[cboProvider.SelectedIndex];
            var action = actions[cboAction.SelectedIndex];

            string system = S(action, "system", "");
            string user = txtInput.Text;
            if (txtExtra.Text.Trim().Length > 0)
                user = "Additional instructions: " + txtExtra.Text.Trim() + "\n\n--- TEXT ---\n" + txtInput.Text;

            btnRun.Enabled = false; lblStatus.Text = "Calling " + S(provider, "name", "") + "...";
            try
            {
                string result = await Send(provider, system, user);
                txtOutput.Text = result.Replace("\r\n", "\n").Replace("\n", "\r\n");
                lblStatus.Text = "Done.";
            }
            catch (Exception ex)
            {
                txtOutput.Text = "ERROR: " + ex.Message;
                lblStatus.Text = "Failed.";
            }
            finally { btnRun.Enabled = true; }
        }

        string ApiKey(Dictionary<string, object> p)
        {
            string env = S(p, "apiKeyEnv", "");
            if (env.Length > 0)
            {
                string v = Environment.GetEnvironmentVariable(env);
                if (!string.IsNullOrEmpty(v)) return v;
            }
            string k = S(p, "apiKey", "");
            if (k.Length == 0) throw new Exception("No API key. Set 'apiKey' or 'apiKeyEnv' for this provider in config.json.");
            return k;
        }

        async Task<string> Send(Dictionary<string, object> p, string system, string user)
        {
            string type = S(p, "type", "").ToLowerInvariant();
            string endpoint = S(p, "endpoint", "").TrimEnd('/');
            int maxTokens = int.Parse(S(p, "maxTokens", "4096"));
            string key = ApiKey(p);
            var js = Json();
            HttpRequestMessage req;

            if (type == "azure-openai")
            {
                string url = endpoint + "/openai/deployments/" + Uri.EscapeDataString(S(p, "deployment", ""))
                    + "/chat/completions?api-version=" + Uri.EscapeDataString(S(p, "apiVersion", "2024-10-21"));
                var body = new Dictionary<string, object>();
                object content = user;
                if (images.Count > 0)
                {
                    var parts = new List<object>();
                    parts.Add(Part("type", "text", "text", user));
                    foreach (string[] im in images)
                    {
                        var u = new Dictionary<string, object>(); u["url"] = "data:" + im[0] + ";base64," + im[1];
                        var ip = new Dictionary<string, object>(); ip["type"] = "image_url"; ip["image_url"] = u;
                        parts.Add(ip);
                    }
                    content = parts;
                }
                body["messages"] = new object[] { Msg("system", system), Msg("user", content) };
                // Newer models (o-series, gpt-5) need "max_completion_tokens" - set tokenParam in config
                body[S(p, "tokenParam", "max_tokens")] = maxTokens;
                string temp = S(p, "temperature", "");
                if (temp.Length > 0) body["temperature"] = double.Parse(temp, System.Globalization.CultureInfo.InvariantCulture);
                req = new HttpRequestMessage(HttpMethod.Post, url);
                req.Headers.Add("api-key", key);
                req.Content = new StringContent(js.Serialize(body), Encoding.UTF8, "application/json");
            }
            else if (type == "anthropic")
            {
                // Works with api.anthropic.com or any Anthropic-compatible endpoint (e.g. Azure-hosted Claude)
                string url = endpoint + "/v1/messages";
                var body = new Dictionary<string, object>();
                body["model"] = S(p, "model", "");
                body["max_tokens"] = maxTokens;
                if (system.Length > 0) body["system"] = system;
                object content = user;
                if (images.Count > 0)
                {
                    var parts = new List<object>();
                    foreach (string[] im in images)
                    {
                        var src = new Dictionary<string, object>(); src["type"] = "base64"; src["media_type"] = im[0]; src["data"] = im[1];
                        var ip = new Dictionary<string, object>(); ip["type"] = "image"; ip["source"] = src;
                        parts.Add(ip);
                    }
                    parts.Add(Part("type", "text", "text", user));
                    content = parts;
                }
                body["messages"] = new object[] { Msg("user", content) };
                string temp = S(p, "temperature", "");
                if (temp.Length > 0) body["temperature"] = double.Parse(temp, System.Globalization.CultureInfo.InvariantCulture);
                req = new HttpRequestMessage(HttpMethod.Post, url);
                req.Headers.Add("x-api-key", key);
                req.Headers.Add("anthropic-version", S(p, "anthropicVersion", "2023-06-01"));
                req.Content = new StringContent(js.Serialize(body), Encoding.UTF8, "application/json");
            }
            else throw new Exception("Unknown provider type '" + type + "'. Use 'azure-openai' or 'anthropic'.");

            HttpResponseMessage resp = await http.SendAsync(req);
            string text = await resp.Content.ReadAsStringAsync();
            if (!resp.IsSuccessStatusCode)
                throw new Exception("HTTP " + (int)resp.StatusCode + " " + resp.ReasonPhrase + "\n" + text);

            var d = (Dictionary<string, object>)js.DeserializeObject(text);
            if (type == "azure-openai")
            {
                var choice = (Dictionary<string, object>)((IList)d["choices"])[0];
                var message = (Dictionary<string, object>)choice["message"];
                return S(message, "content", "");
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                foreach (object o in (IList)d["content"])
                {
                    var block = (Dictionary<string, object>)o;
                    if (S(block, "type", "") == "text") sb.Append(S(block, "text", ""));
                }
                return sb.ToString();
            }
        }

        static Dictionary<string, object> Part(string k1, string v1, string k2, string v2)
        {
            var m = new Dictionary<string, object>(); m[k1] = v1; m[k2] = v2; return m;
        }

        static Dictionary<string, object> Msg(string role, object content)
        {
            var m = new Dictionary<string, object>();
            m["role"] = role; m["content"] = content;
            return m;
        }
    }
}
