# Document Field Extraction Service

A Spring Boot-based microservice for extracting, validating, and preserving specific fields from PDF and TIFF documents with intelligent pattern matching, OCR support, and database persistence.

## Features

### Document Processing
- **PDF Support**: Extract form fields and text content using Apache PDFBox
- **TIFF Support**: OCR-based field extraction using Tesseract
- **Multi-page Documents**: Process documents with multiple pages
- **Async Processing**: Background job processing for large documents

### Field Extraction Methods
- **Form Field Extraction**: Direct extraction from PDF forms
- **Pattern Matching**: Regex-based field extraction
- **Keyword Matching**: Context-aware extraction near keywords
- **OCR**: Optical Character Recognition for scanned documents
- **Deduplication**: Automatic removal of duplicate fields

### Field Validation
- **Type-based Validation**: Email, Phone, Date, Numeric, Currency, SSN, ZIP Code, etc.
- **Pattern Validation**: Custom regex patterns
- **Length Constraints**: Min/max length validation
- **Allowed Values**: Whitelist-based validation
- **Manual Verification**: Mark fields for manual review

### Database Persistence
- **Document Metadata**: Store document information with checksums
- **Extracted Fields**: Persist all extracted fields with confidence scores
- **Validation Status**: Track validation state for each field
- **Bounding Boxes**: Store field positions within documents
- **Audit Trail**: Timestamps and update tracking

## Architecture

```
┌──────────────────────────────────────────────────────┐
│              REST API Controller                     │
├──────────────────────────────────────────────────────┤
│          Document Extraction Service                 │
├──────────────────────────────────────────────────────┤
│                                                      │
│  ┌──────────────────┐  ┌──────────────────────┐    │
│  │  PDF Extractor   │  │  TIFF Extractor      │    │
│  │ • Form Fields    │  │ • OCR Processing     │    │
│  │ • Pattern Match  │  │ • Pattern Match      │    │
│  │ • Keyword Match  │  │ • Keyword Match      │    │
│  └──────────────────┘  └──────────────────────┘    │
│                                                      │
│         ┌─────────────────────────────┐             │
│         │ Field Validation Service    │             │
│         │ • Type Validation           │             │
│         │ • Format Validation         │             │
│         │ • Business Rule Validation  │             │
│         └─────────────────────────────┘             │
├──────────────────────────────────────────────────────┤
│                  Database (MySQL)                    │
│  • Documents                                         │
│  • Extracted Fields                                  │
│  • Document Metadata                                │
└──────────────────────────────────────────────────────┘
```

## Installation

### Prerequisites
- Java 17+
- Maven 3.6+
- MySQL 8.0+
- Tesseract OCR (for TIFF support)

### Setup

1. **Install Tesseract** (for TIFF processing):
```bash
# Ubuntu/Debian
sudo apt-get install tesseract-ocr tesseract-ocr-eng

# macOS
brew install tesseract

# Windows
# Download from: https://github.com/UB-Mannheim/tesseract/wiki
```

2. **Create Database**:
```sql
CREATE DATABASE document_extraction CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

3. **Build and Run**:
```bash
mvn clean package
java -jar target/document-field-extraction-1.0.0.jar
```

4. **Access Services**:
- API: http://localhost:8081
- Swagger UI: http://localhost:8081/swagger-ui.html
- Health: http://localhost:8081/actuator/health

## API Usage

### Extract Fields (Synchronous)

```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@invoice.pdf" \
  -F "fieldConfigs=@field-config.json" \
  -H "Accept: application/json"
```

**Field Configuration Example** (field-config.json):
```json
{
  "fieldConfigs": [
    {
      "fieldName": "invoice_number",
      "fieldType": "TEXT",
      "label": "Invoice Number",
      "keywords": ["Invoice #", "Invoice Number"],
      "regexPattern": "INV-\\d{6}",
      "transformations": ["UPPERCASE", "TRIM"],
      "validationRules": {
        "pattern": "INV-\\d{6}",
        "minLength": 10,
        "maxLength": 15
      }
    },
    {
      "fieldName": "invoice_date",
      "fieldType": "DATE",
      "keywords": ["Invoice Date", "Date"],
      "transformations": ["NORMALIZE_SPACES"],
      "validationRules": {
        "pattern": "\\d{2}/\\d{2}/\\d{4}"
      }
    },
    {
      "fieldName": "total_amount",
      "fieldType": "CURRENCY",
      "regexPattern": "Total[:\\s]*\\$?([\\d,]+\\.\\d{2})",
      "transformations": ["REMOVE_SPECIAL_CHARS"],
      "validationRules": {
        "pattern": "^\\$?\\d+(\\.\\d{2})?$"
      }
    }
  ]
}
```

### Extract Fields (Asynchronous)

```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract-async \
  -u user:password123 \
  -F "file=@large-document.pdf" \
  -F "fieldConfigs=@field-config.json" \
  -F "callbackUrl=https://yourserver.com/callback"
```

### Retrieve Extracted Fields

```bash
# Get document details
curl http://localhost:8081/api/v1/extraction/document/{documentId} \
  -u user:password123

# Get all extracted fields
curl http://localhost:8081/api/v1/extraction/fields/{documentId} \
  -u user:password123
```

## Field Extraction Configuration

### FieldExtractionConfig Schema

```java
{
  "fieldName": "string",           // Unique field identifier
  "fieldType": "string",            // TEXT, NUMERIC, DATE, CHECKBOX, EMAIL, PHONE, etc.
  "label": "string",                // Human-readable label
  "pageNumber": "integer",          // -1 for all pages, or specific page number
  "searchAllPages": "boolean",      // Override pageNumber
  "regexPattern": "string",         // Regex for pattern matching
  "keywords": ["string"],           // Keywords to search near
  "transformations": ["string"],    // UPPERCASE, LOWERCASE, TRIM, etc.
  "validationRules": {
    "pattern": "string",            // Regex for validation
    "minLength": "integer",
    "maxLength": "integer",
    "allowedValues": ["string"]
  },
  "templateOptions": {
    "contextWindowSize": "float",   // Characters to search after keyword
    "useOCR": "boolean",
    "confidenceThreshold": "float"
  }
}
```

### Supported Field Types
- **TEXT**: General text
- **NUMERIC**: Numbers
- **DATE**: Dates
- **CURRENCY**: Money amounts
- **EMAIL**: Email addresses
- **PHONE**: Phone numbers
- **SSN**: Social Security Numbers
- **ZIPCODE**: ZIP codes
- **CHECKBOX**: Boolean/checkbox values
- **SIGNATURE**: Signature fields

### Transformations
- `UPPERCASE`: Convert to uppercase
- `LOWERCASE`: Convert to lowercase
- `TRIM`: Remove leading/trailing whitespace
- `REMOVE_SPECIAL_CHARS`: Remove non-alphanumeric characters
- `REMOVE_WHITESPACE`: Remove all whitespace
- `NORMALIZE_SPACES`: Collapse multiple spaces

## Advanced Features

### Multi-Page Processing

```json
{
  "fieldName": "all_dates",
  "fieldType": "DATE",
  "keywords": ["Date:"],
  "searchAllPages": true,
  "transformations": ["NORMALIZE_SPACES"]
}
```

### Regex-based Extraction

```json
{
  "fieldName": "invoice_number",
  "fieldType": "TEXT",
  "regexPattern": "INV-\\d{6}",
  "pageNumber": 0
}
```

### Context-aware Extraction

```json
{
  "fieldName": "vendor_name",
  "fieldType": "TEXT",
  "keywords": ["Vendor:", "From:"],
  "templateOptions": {
    "contextWindowSize": 100
  }
}
```

## Database Schema

### documents table
- `id`: Document UUID
- `document_name`: Original filename
- `document_type`: PDF, TIFF, etc.
- `file_path`: Storage location
- `status`: PENDING, PROCESSING, COMPLETED, FAILED
- `page_count`: Number of pages
- `checksum`: SHA-256 for duplicate detection

### extracted_fields table
- `document_id`: Reference to document
- `field_name`: Field identifier
- `field_value`: Extracted value
- `confidence`: Extraction confidence (0-1)
- `page_number`: Page where found
- `validation_status`: VALID, INVALID, NEEDS_REVIEW
- `extraction_method`: FORM_FIELD, REGEX, KEYWORD_MATCHING, OCR

## Performance Tuning

### Optimize PDF Processing
```properties
spring.jpa.properties.hibernate.jdbc.batch_size=20
spring.jpa.properties.hibernate.order_inserts=true
spring.jpa.properties.hibernate.order_updates=true
```

### Tesseract Configuration
- Adjust `pageSegMode` for different document types (0-13)
- Use language-specific training data
- Configure OCR engine mode (0-3)

### Database Indexing
Indexes are created on:
- document status and type
- field name and type
- validation status
- document checksum

## Error Handling

The service provides detailed error responses:

```json
{
  "status": "FAILED",
  "error": "Error message describing the issue",
  "metrics": {
    "totalFieldsExtracted": 0,
    "processingTimeMs": 1234
  }
}
```

## Validation Examples

### Email Validation
```json
{
  "fieldType": "EMAIL",
  "validationRules": {
    "pattern": "^[A-Za-z0-9+_.-]+@(.+)$"
  }
}
```

### Phone Number
```json
{
  "fieldType": "PHONE",
  "transformations": ["REMOVE_SPECIAL_CHARS"],
  "validationRules": {
    "pattern": "^\\d{10}$|^\\d{11}$"
  }
}
```

### Currency Amount
```json
{
  "fieldType": "CURRENCY",
  "regexPattern": "\\$([\\d,]+\\.\\d{2})",
  "validationRules": {
    "pattern": "^\\$?\\d+(\\.\\d{2})?$"
  }
}
```

## Testing

### Unit Tests
```bash
mvn test
```

### Integration Tests
```bash
mvn verify
```

### Example Test
```java
@SpringBootTest
class DocumentExtractionServiceTest {
    
    @Test
    void testExtractFieldsFromPdf() throws Exception {
        // Create config
        FieldExtractionConfig config = FieldExtractionConfig.builder()
            .fieldName("invoice_number")
            .fieldType("TEXT")
            .regexPattern("INV-\\d{6}")
            .build();
        
        // Process document
        ExtractionResponse response = extractionService.processDocument(
            mockFile, List.of(config)
        );
        
        // Verify
        assertEquals("COMPLETED", response.getStatus());
        assertTrue(response.getExtractedFields().size() > 0);
    }
}
```

## Production Considerations

1. **Security**:
   - Implement JWT authentication
   - Enable HTTPS/TLS
   - Use environment variables for sensitive config

2. **Performance**:
   - Use connection pooling
   - Implement caching for repeated documents
   - Use async processing for large batches

3. **Monitoring**:
   - Set up logging aggregation
   - Monitor extraction success rates
   - Track performance metrics

4. **Data Management**:
   - Implement document retention policies
   - Archive processed documents
   - Backup database regularly

## Troubleshooting

### Tesseract Not Found
```bash
# Set explicit path
export TESSDATA_PREFIX=/usr/share/tesseract-ocr/4.00/tessdata
```

### PDF Processing Errors
- Ensure PDF is not corrupted
- Check if PDF requires password
- Verify PDF format (some scanned PDFs need OCR)

### Low Confidence Scores
- Enable image enhancement
- Use higher DPI settings
- Check document quality
- Consider using specific language packs

## License

Apache License 2.0

## Support

For issues and questions:
- GitHub Issues
- Email: support@example.com
