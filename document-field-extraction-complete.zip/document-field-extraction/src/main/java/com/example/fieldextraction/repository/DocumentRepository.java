package com.example.fieldextraction.repository;

import com.example.fieldextraction.entity.Document;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface DocumentRepository extends JpaRepository<Document, String> {
    List<Document> findByStatus(Document.ProcessingStatus status);
    List<Document> findByDocumentType(String documentType);
    Optional<Document> findByChecksum(String checksum);
    List<Document> findByCreatedAtBefore(LocalDateTime dateTime);
    
    @Query("SELECT d FROM Document d WHERE d.status = ?1 AND d.createdAt < ?2")
    List<Document> findStaleDocuments(Document.ProcessingStatus status, LocalDateTime dateTime);
}
