package com.example.fieldextraction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FieldExtractionConfig {
    
    @NotNull(message = "Field name is required")
    private String fieldName;
    
    @NotNull(message = "Field type is required")
    private String fieldType; // TEXT, NUMERIC, DATE, CHECKBOX, SIGNATURE, EMAIL, PHONE, etc.
    
    private String label;
    
    private String description;
    
    private Boolean required;
    
    private Integer pageNumber; // -1 for all pages
    
    private Boolean searchAllPages;
    
    // Pattern matching for extraction
    private String regexPattern;
    
    // Keywords to search near the field
    private List<String> keywords;
    
    // Bounding box constraints (optional, for template-based extraction)
    private BoundingBoxConfig boundingBox;
    
    // Post-processing rules
    private List<String> transformations; // UPPERCASE, LOWERCASE, TRIM, REMOVE_SPECIAL_CHARS, etc.
    
    // Validation rules
    private ValidationRules validationRules;
    
    // Template matching options
    private TemplateOptions templateOptions;
    
    // Machine learning model for extraction
    private String mlModelId;
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BoundingBoxConfig {
        private Float x;
        private Float y;
        private Float width;
        private Float height;
        private Float tolerance; // percentage tolerance for box matching
    }
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ValidationRules {
        private String pattern; // Regex pattern for validation
        private Integer minLength;
        private Integer maxLength;
        private List<String> allowedValues;
        private String customValidator; // Reference to custom validator bean
    }
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TemplateOptions {
        private Float contextWindowSize; // Distance from keyword to search
        private Boolean useOCR;
        private Boolean useFormFields;
        private Float confidenceThreshold;
    }
}
