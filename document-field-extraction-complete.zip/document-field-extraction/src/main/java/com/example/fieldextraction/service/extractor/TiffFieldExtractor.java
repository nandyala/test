package com.example.fieldextraction.service.extractor;

import com.example.fieldextraction.dto.FieldExtractionConfig;
import com.example.fieldextraction.entity.ExtractedField;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.apache.commons.imaging.ImageReadException;
import org.apache.commons.imaging.Imaging;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
@RequiredArgsConstructor
public class TiffFieldExtractor {
    
    @Value("${ocr.tesseract.datapath}")
    private String tessdataPath;
    
    /**
     * Extract text from TIFF using OCR
     */
    public String extractTextFromTiff(File tiffFile) throws TesseractException, IOException {
        Tesseract tesseract = configureTesseract();
        return tesseract.doOCR(tiffFile);
    }
    
    /**
     * Extract text from TIFF with page information
     */
    public Map<Integer, String> extractTextByPageFromTiff(File tiffFile) throws IOException, TesseractException {
        Map<Integer, String> pageContent = new HashMap<>();
        
        try {
            // Read TIFF pages
            List<BufferedImage> pages = extractTiffPages(tiffFile);
            Tesseract tesseract = configureTesseract();
            
            for (int i = 0; i < pages.size(); i++) {
                String pageText = tesseract.doOCR(pages.get(i));
                pageContent.put(i, pageText);
            }
        } catch (ImageReadException e) {
            log.error("Error reading TIFF file: ", e);
            throw new IOException("Failed to read TIFF file", e);
        }
        
        return pageContent;
    }
    
    /**
     * Extract fields from TIFF using regex patterns and keyword matching
     */
    public List<ExtractedField> extractFieldsByPattern(File tiffFile, List<FieldExtractionConfig> configs) 
            throws IOException, TesseractException {
        List<ExtractedField> extractedFields = new ArrayList<>();
        Map<Integer, String> pageContent = extractTextByPageFromTiff(tiffFile);
        
        for (FieldExtractionConfig config : configs) {
            List<Integer> pagesToSearch = determinePages(config, pageContent.size());
            
            for (Integer pageNum : pagesToSearch) {
                String content = pageContent.getOrDefault(pageNum, "");
                
                // Extract using regex pattern
                if (config.getRegexPattern() != null) {
                    extractedFields.addAll(extractByRegex(config, content, pageNum));
                }
                
                // Extract using keywords
                if (config.getKeywords() != null && !config.getKeywords().isEmpty()) {
                    extractedFields.addAll(extractByKeyword(config, content, pageNum));
                }
            }
        }
        
        return extractedFields;
    }
    
    /**
     * Extract field using regex pattern
     */
    private List<ExtractedField> extractByRegex(FieldExtractionConfig config, String content, Integer pageNum) {
        List<ExtractedField> fields = new ArrayList<>();
        
        try {
            Pattern pattern = Pattern.compile(config.getRegexPattern(), Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
            Matcher matcher = pattern.matcher(content);
            
            while (matcher.find()) {
                ExtractedField field = new ExtractedField();
                field.setFieldName(config.getFieldName());
                field.setFieldType(config.getFieldType());
                field.setRawText(matcher.group(0));
                field.setFieldValue(processFieldValue(matcher.group(0), config));
                field.setPageNumber(pageNum);
                field.setExtractionMethod("OCR_REGEX");
                field.setValidationStatus(ExtractedField.ValidationStatus.UNVALIDATED);
                field.setUpdatedAt(java.time.LocalDateTime.now());
                
                fields.add(field);
            }
        } catch (Exception e) {
            log.error("Error extracting field with regex pattern: {}", config.getFieldName(), e);
        }
        
        return fields;
    }
    
    /**
     * Extract field using keyword matching
     */
    private List<ExtractedField> extractByKeyword(FieldExtractionConfig config, String content, Integer pageNum) {
        List<ExtractedField> fields = new ArrayList<>();
        
        float contextWindowSize = config.getTemplateOptions() != null ? 
            config.getTemplateOptions().getContextWindowSize() : 200f;
        
        for (String keyword : config.getKeywords()) {
            int index = content.toLowerCase().indexOf(keyword.toLowerCase());
            
            while (index != -1) {
                int startIdx = Math.max(0, index);
                int endIdx = Math.min(content.length(), 
                    (int)(index + keyword.length() + contextWindowSize));
                
                String contextText = content.substring(startIdx, endIdx);
                String extractedValue = extractValueFromContext(contextText, keyword, config);
                
                if (extractedValue != null && !extractedValue.isEmpty()) {
                    ExtractedField field = new ExtractedField();
                    field.setFieldName(config.getFieldName());
                    field.setFieldType(config.getFieldType());
                    field.setRawText(contextText);
                    field.setFieldValue(extractedValue);
                    field.setPageNumber(pageNum);
                    field.setExtractionMethod("OCR_KEYWORD");
                    field.setUpdatedAt(java.time.LocalDateTime.now());
                    field.setValidationStatus(ExtractedField.ValidationStatus.UNVALIDATED);
                    
                    fields.add(field);
                }
                
                index = content.toLowerCase().indexOf(keyword.toLowerCase(), index + 1);
            }
        }
        
        return fields;
    }
    
    /**
     * Extract individual pages from TIFF file
     */
    private List<BufferedImage> extractTiffPages(File tiffFile) throws IOException, ImageReadException {
        List<BufferedImage> pages = new ArrayList<>();
        
        try {
            // Try using ImageIO for multi-page TIFF
            List<BufferedImage> images = (List<BufferedImage>) Imaging.getBufferedImages(tiffFile);
            if (images != null) {
                pages.addAll(images);
            } else {
                // Fallback: read as single image
                BufferedImage image = ImageIO.read(tiffFile);
                if (image != null) {
                    pages.add(image);
                }
            }
        } catch (ImageReadException e) {
            log.warn("Error reading TIFF with Imaging library, trying ImageIO", e);
            BufferedImage image = ImageIO.read(tiffFile);
            if (image != null) {
                pages.add(image);
            }
        }
        
        return pages;
    }
    
    /**
     * Get page count from TIFF
     */
    public int getPageCount(File tiffFile) throws IOException, ImageReadException {
        try {
            List<BufferedImage> images = (List<BufferedImage>) Imaging.getBufferedImages(tiffFile);
            return images != null ? images.size() : 1;
        } catch (ImageReadException e) {
            log.warn("Could not determine page count, assuming 1");
            return 1;
        }
    }
    
    /**
     * Process field value with transformations
     */
    private String processFieldValue(String rawValue, FieldExtractionConfig config) {
        String processedValue = rawValue;
        
        if (config.getTransformations() != null) {
            for (String transformation : config.getTransformations()) {
                processedValue = applyTransformation(processedValue, transformation);
            }
        }
        
        return processedValue.trim();
    }
    
    /**
     * Apply transformation
     */
    private String applyTransformation(String value, String transformation) {
        return switch (transformation.toUpperCase()) {
            case "UPPERCASE" -> value.toUpperCase();
            case "LOWERCASE" -> value.toLowerCase();
            case "TRIM" -> value.trim();
            case "REMOVE_SPECIAL_CHARS" -> value.replaceAll("[^a-zA-Z0-9\\s]", "");
            case "REMOVE_WHITESPACE" -> value.replaceAll("\\s+", "");
            case "NORMALIZE_SPACES" -> value.replaceAll("\\s+", " ").trim();
            default -> value;
        };
    }
    
    /**
     * Extract value from context
     */
    private String extractValueFromContext(String contextText, String keyword, FieldExtractionConfig config) {
        int keywordIndex = contextText.toLowerCase().indexOf(keyword.toLowerCase());
        if (keywordIndex == -1) return null;
        
        int startIndex = keywordIndex + keyword.length();
        String afterKeyword = contextText.substring(startIndex);
        
        String[] tokens = afterKeyword.split("[:\\s,;\n]");
        for (String token : tokens) {
            String cleaned = token.trim();
            if (!cleaned.isEmpty() && cleaned.length() > 1) {
                return processFieldValue(cleaned, config);
            }
        }
        
        return null;
    }
    
    /**
     * Determine which pages to search
     */
    private List<Integer> determinePages(FieldExtractionConfig config, int totalPages) {
        List<Integer> pages = new ArrayList<>();
        
        if (config.getSearchAllPages() != null && config.getSearchAllPages()) {
            for (int i = 0; i < totalPages; i++) {
                pages.add(i);
            }
        } else if (config.getPageNumber() != null && config.getPageNumber() >= 0) {
            pages.add(config.getPageNumber());
        } else {
            pages.add(0);
        }
        
        return pages;
    }
    
    /**
     * Configure Tesseract
     */
    private Tesseract configureTesseract() {
        Tesseract tesseract = new Tesseract();
        tesseract.setDatapath(tessdataPath);
        tesseract.setLanguage("eng");
        tesseract.setPageSegMode(3);
        tesseract.setOcrEngineMode(1);
        return tesseract;
    }
}
