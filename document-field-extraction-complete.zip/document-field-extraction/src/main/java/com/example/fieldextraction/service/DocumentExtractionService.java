package com.example.fieldextraction.service;

import com.example.fieldextraction.dto.ExtractionResponse;
import com.example.fieldextraction.dto.FieldExtractionConfig;
import com.example.fieldextraction.entity.Document;
import com.example.fieldextraction.entity.ExtractedField;
import com.example.fieldextraction.repository.DocumentRepository;
import com.example.fieldextraction.repository.ExtractedFieldRepository;
import com.example.fieldextraction.service.extractor.PdfFieldExtractor;
import com.example.fieldextraction.service.extractor.TiffFieldExtractor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DocumentExtractionService {
    
    private final DocumentRepository documentRepository;
    private final ExtractedFieldRepository extractedFieldRepository;
    private final PdfFieldExtractor pdfExtractor;
    private final TiffFieldExtractor tiffExtractor;
    private final FieldValidationService validationService;
    
    private static final String UPLOAD_DIR = "uploads/documents";
    
    /**
     * Process document synchronously
     */
    @Transactional
    public ExtractionResponse processDocument(MultipartFile file, List<FieldExtractionConfig> fieldConfigs) throws Exception {
        long startTime = System.currentTimeMillis();
        
        // Save file and create document record
        Document document = saveDocument(file);
        
        try {
            // Extract fields
            List<ExtractedField> extractedFields = extractFields(document, fieldConfigs);
            
            // Validate fields
            for (ExtractedField field : extractedFields) {
                FieldExtractionConfig config = findConfig(fieldConfigs, field.getFieldName());
                if (config != null) {
                    validationService.validateField(field, config);
                }
                field.setDocument(document);
                field.setUpdatedAt(LocalDateTime.now());
            }
            
            // Save extracted fields
            extractedFieldRepository.saveAll(extractedFields);
            
            // Update document status
            document.setStatus(Document.ProcessingStatus.COMPLETED);
            document.setExtractedFields(extractedFields);
            documentRepository.save(document);
            
            long processingTime = System.currentTimeMillis() - startTime;
            
            return buildResponse(document, extractedFields, processingTime);
        } catch (Exception e) {
            log.error("Error processing document: {}", document.getId(), e);
            document.setStatus(Document.ProcessingStatus.FAILED);
            document.setProcessingError(e.getMessage());
            documentRepository.save(document);
            throw e;
        }
    }
    
    /**
     * Process document asynchronously
     */
    @Async
    @Transactional
    public void processDocumentAsync(MultipartFile file, List<FieldExtractionConfig> fieldConfigs, String callbackUrl) {
        try {
            ExtractionResponse response = processDocument(file, fieldConfigs);
            if (callbackUrl != null) {
                notifyCallback(callbackUrl, response);
            }
        } catch (Exception e) {
            log.error("Error in async document processing: ", e);
        }
    }
    
    /**
     * Extract fields from document
     */
    private List<ExtractedField> extractFields(Document document, List<FieldExtractionConfig> fieldConfigs) throws Exception {
        List<ExtractedField> fields = new ArrayList<>();
        Path filePath = Paths.get(document.getFilePath());
        File file = filePath.toFile();
        
        if (!file.exists()) {
            throw new IOException("Document file not found: " + document.getFilePath());
        }
        
        String documentType = document.getDocumentType().toUpperCase();
        
        try {
            if ("PDF".equals(documentType)) {
                fields = extractFromPdf(file, fieldConfigs);
            } else if ("TIFF".equals(documentType) || "TIF".equals(documentType)) {
                fields = extractFromTiff(file, fieldConfigs);
            } else {
                throw new IllegalArgumentException("Unsupported document type: " + documentType);
            }
        } catch (Exception e) {
            log.error("Error extracting fields from document: {}", document.getId(), e);
            throw e;
        }
        
        return fields;
    }
    
    /**
     * Extract from PDF
     */
    private List<ExtractedField> extractFromPdf(File pdfFile, List<FieldExtractionConfig> fieldConfigs) throws IOException {
        List<ExtractedField> fields = new ArrayList<>();
        
        // Extract form fields
        try {
            fields.addAll(pdfExtractor.extractFormFields(pdfFile));
        } catch (Exception e) {
            log.warn("Could not extract form fields from PDF: ", e);
        }
        
        // Extract using pattern matching
        try {
            fields.addAll(pdfExtractor.extractFieldsByPattern(pdfFile, fieldConfigs));
        } catch (Exception e) {
            log.warn("Could not extract fields by pattern from PDF: ", e);
        }
        
        return deduplicateFields(fields);
    }
    
    /**
     * Extract from TIFF
     */
    private List<ExtractedField> extractFromTiff(File tiffFile, List<FieldExtractionConfig> fieldConfigs) throws Exception {
        return deduplicateFields(tiffExtractor.extractFieldsByPattern(tiffFile, fieldConfigs));
    }
    
    /**
     * Remove duplicate fields, keeping the one with highest confidence
     */
    private List<ExtractedField> deduplicateFields(List<ExtractedField> fields) {
        Map<String, ExtractedField> deduplicated = new LinkedHashMap<>();
        
        for (ExtractedField field : fields) {
            String key = field.getFieldName() + "_" + field.getPageNumber();
            
            if (!deduplicated.containsKey(key)) {
                deduplicated.put(key, field);
            } else {
                ExtractedField existing = deduplicated.get(key);
                // Keep field with higher confidence
                if (field.getConfidence() != null && 
                    (existing.getConfidence() == null || field.getConfidence() > existing.getConfidence())) {
                    deduplicated.put(key, field);
                }
            }
        }
        
        return new ArrayList<>(deduplicated.values());
    }
    
    /**
     * Save document to disk and database
     */
    @Transactional
    private Document saveDocument(MultipartFile file) throws IOException {
        // Create upload directory if not exists
        Path uploadPath = Paths.get(UPLOAD_DIR);
        Files.createDirectories(uploadPath);
        
        // Save file
        String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();
        Path filePath = uploadPath.resolve(filename);
        Files.write(filePath, file.getBytes());
        
        // Create document record
        Document document = new Document();
        document.setDocumentName(file.getOriginalFilename());
        document.setDocumentType(getDocumentType(file.getOriginalFilename()));
        document.setFilePath(filePath.toString());
        document.setFileSize(file.getSize());
        document.setChecksum(calculateChecksum(file.getBytes()));
        document.setStatus(Document.ProcessingStatus.PROCESSING);
        document.setCreatedAt(LocalDateTime.now());
        document.setUpdatedAt(LocalDateTime.now());
        
        // Set page count if possible
        try {
            if ("PDF".equalsIgnoreCase(document.getDocumentType())) {
                document.setPageCount(pdfExtractor.getPageCount(filePath.toFile()));
            } else if ("TIFF".equalsIgnoreCase(document.getDocumentType())) {
                document.setPageCount(tiffExtractor.getPageCount(filePath.toFile()));
            }
        } catch (Exception e) {
            log.warn("Could not determine page count for document: {}", document.getId(), e);
        }
        
        return documentRepository.save(document);
    }
    
    /**
     * Get document type from filename
     */
    private String getDocumentType(String filename) {
        String extension = filename.substring(filename.lastIndexOf(".") + 1).toUpperCase();
        return switch (extension) {
            case "PDF" -> "PDF";
            case "TIFF", "TIF" -> "TIFF";
            default -> extension;
        };
    }
    
    /**
     * Calculate file checksum
     */
    private String calculateChecksum(byte[] fileBytes) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(fileBytes);
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            log.warn("Error calculating checksum: ", e);
            return UUID.randomUUID().toString();
        }
    }
    
    /**
     * Find field config by name
     */
    private FieldExtractionConfig findConfig(List<FieldExtractionConfig> configs, String fieldName) {
        return configs.stream()
            .filter(c -> c.getFieldName().equals(fieldName))
            .findFirst()
            .orElse(null);
    }
    
    /**
     * Build extraction response
     */
    private ExtractionResponse buildResponse(Document document, List<ExtractedField> fields, long processingTime) {
        List<ExtractionResponse.ExtractedFieldDTO> fieldDtos = fields.stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());
        
        long validFields = fields.stream()
            .filter(f -> f.getValidationStatus() == ExtractedField.ValidationStatus.VALID)
            .count();
        
        long invalidFields = fields.stream()
            .filter(f -> f.getValidationStatus() == ExtractedField.ValidationStatus.INVALID)
            .count();
        
        long needsReview = fields.stream()
            .filter(f -> f.getValidationStatus() == ExtractedField.ValidationStatus.NEEDS_REVIEW)
            .count();
        
        double avgConfidence = fields.stream()
            .mapToDouble(f -> f.getConfidence() != null ? f.getConfidence() : 0.0)
            .average()
            .orElse(0.0);
        
        float successRate = fields.isEmpty() ? 0 : (float) validFields / fields.size();
        
        return ExtractionResponse.builder()
            .documentId(document.getId())
            .documentName(document.getDocumentName())
            .status(document.getStatus().toString())
            .extractedFields(fieldDtos)
            .metrics(ExtractionResponse.ExtractionMetrics.builder()
                .totalFieldsExtracted(fields.size())
                .validFields((int) validFields)
                .invalidFields((int) invalidFields)
                .fieldsNeedingReview((int) needsReview)
                .averageConfidence(avgConfidence)
                .processingTimeMs(processingTime)
                .successRate(successRate)
                .build())
            .processedAt(LocalDateTime.now())
            .build();
    }
    
    /**
     * Convert ExtractedField to DTO
     */
    private ExtractionResponse.ExtractedFieldDTO convertToDto(ExtractedField field) {
        return ExtractionResponse.ExtractedFieldDTO.builder()
            .fieldName(field.getFieldName())
            .fieldType(field.getFieldType())
            .fieldValue(field.getFieldValue())
            .confidence(field.getConfidence())
            .pageNumber(field.getPageNumber())
            .validationStatus(field.getValidationStatus().toString())
            .extractionMethod(field.getExtractionMethod())
            .validationNotes(field.getValidationNotes())
            .boundingBox(field.getBoundingBoxX() != null ? 
                ExtractionResponse.BoundingBox.builder()
                    .x(field.getBoundingBoxX())
                    .y(field.getBoundingBoxY())
                    .width(field.getBoundingBoxWidth())
                    .height(field.getBoundingBoxHeight())
                    .build() : null)
            .build();
    }
    
    /**
     * Notify callback URL
     */
    private void notifyCallback(String callbackUrl, ExtractionResponse response) {
        try {
            // Implementation would send HTTP POST to callback URL
            log.info("Document extraction completed for document: {}", response.getDocumentId());
        } catch (Exception e) {
            log.error("Error notifying callback: {}", callbackUrl, e);
        }
    }
    
    /**
     * Get document by ID
     */
    public Optional<Document> getDocument(String documentId) {
        return documentRepository.findById(documentId);
    }
    
    /**
     * Get extracted fields for document
     */
    public List<ExtractedField> getExtractedFields(String documentId) {
        return extractedFieldRepository.findByDocumentId(documentId);
    }
}
