package com.example.fieldextraction.service.extractor;

import com.example.fieldextraction.dto.FieldExtractionConfig;
import com.example.fieldextraction.entity.ExtractedField;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class PdfFieldExtractor {
    
    /**
     * Extract form fields from PDF
     */
    public List<ExtractedField> extractFormFields(File pdfFile) throws IOException {
        List<ExtractedField> fields = new ArrayList<>();
        
        try (PDDocument document = PDDocument.load(pdfFile)) {
            var pdForm = document.getDocumentCatalog().getAcroForm();
            
            if (pdForm != null) {
                for (PDField field : pdForm.getFields()) {
                    ExtractedField extractedField = new ExtractedField();
                    extractedField.setFieldName(field.getFullyQualifiedName());
                    extractedField.setFieldType(getFieldType(field));
                    extractedField.setFieldValue(field.getValueAsString());
                    extractedField.setExtractionMethod("FORM_FIELD");
                    extractedField.setValidationStatus(ExtractedField.ValidationStatus.UNVALIDATED);
                    extractedField.setUpdatedAt(java.time.LocalDateTime.now());
                    
                    fields.add(extractedField);
                }
            }
        }
        
        return fields;
    }
    
    /**
     * Extract text content from PDF with position information
     */
    public Map<Integer, String> extractTextByPage(File pdfFile) throws IOException {
        Map<Integer, String> pageContent = new HashMap<>();
        
        try (PDDocument document = PDDocument.load(pdfFile)) {
            PDFTextStripper stripper = new PDFTextStripper();
            
            for (int pageNum = 0; pageNum < document.getNumberOfPages(); pageNum++) {
                stripper.setStartPage(pageNum + 1);
                stripper.setEndPage(pageNum + 1);
                String pageText = stripper.getText(document);
                pageContent.put(pageNum, pageText);
            }
        }
        
        return pageContent;
    }
    
    /**
     * Extract fields using regex patterns and keyword matching
     */
    public List<ExtractedField> extractFieldsByPattern(File pdfFile, List<FieldExtractionConfig> configs) throws IOException {
        List<ExtractedField> extractedFields = new ArrayList<>();
        Map<Integer, String> pageContent = extractTextByPage(pdfFile);
        
        for (FieldExtractionConfig config : configs) {
            List<Integer> pagesToSearch = determinePages(config, pageContent.size());
            
            for (Integer pageNum : pagesToSearch) {
                String content = pageContent.getOrDefault(pageNum, "");
                
                // Extract using regex pattern
                if (config.getRegexPattern() != null) {
                    extractedFields.addAll(extractByRegex(config, content, pageNum));
                }
                
                // Extract using keywords
                if (config.getKeywords() != null && !config.getKeywords().isEmpty()) {
                    extractedFields.addAll(extractByKeyword(config, content, pageNum));
                }
            }
        }
        
        return extractedFields;
    }
    
    /**
     * Extract field using regex pattern
     */
    private List<ExtractedField> extractByRegex(FieldExtractionConfig config, String content, Integer pageNum) {
        List<ExtractedField> fields = new ArrayList<>();
        
        try {
            Pattern pattern = Pattern.compile(config.getRegexPattern(), Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
            Matcher matcher = pattern.matcher(content);
            
            while (matcher.find()) {
                ExtractedField field = new ExtractedField();
                field.setFieldName(config.getFieldName());
                field.setFieldType(config.getFieldType());
                field.setRawText(matcher.group(0));
                field.setFieldValue(processFieldValue(matcher.group(0), config));
                field.setPageNumber(pageNum);
                field.setExtractionMethod("REGEX");
                field.setValidationStatus(ExtractedField.ValidationStatus.UNVALIDATED);
                field.setUpdatedAt(java.time.LocalDateTime.now());
                
                fields.add(field);
            }
        } catch (Exception e) {
            log.error("Error extracting field with regex pattern: {}", config.getFieldName(), e);
        }
        
        return fields;
    }
    
    /**
     * Extract field using keyword matching with context window
     */
    private List<ExtractedField> extractByKeyword(FieldExtractionConfig config, String content, Integer pageNum) {
        List<ExtractedField> fields = new ArrayList<>();
        
        float contextWindowSize = config.getTemplateOptions() != null ? 
            config.getTemplateOptions().getContextWindowSize() : 200f;
        
        for (String keyword : config.getKeywords()) {
            int index = content.toLowerCase().indexOf(keyword.toLowerCase());
            
            while (index != -1) {
                // Extract context around keyword
                int startIdx = Math.max(0, index);
                int endIdx = Math.min(content.length(), 
                    (int)(index + keyword.length() + contextWindowSize));
                
                String contextText = content.substring(startIdx, endIdx);
                String extractedValue = extractValueFromContext(contextText, keyword, config);
                
                if (extractedValue != null && !extractedValue.isEmpty()) {
                    ExtractedField field = new ExtractedField();
                    field.setFieldName(config.getFieldName());
                    field.setFieldType(config.getFieldType());
                    field.setRawText(contextText);
                    field.setFieldValue(extractedValue);
                    field.setPageNumber(pageNum);
                    field.setExtractionMethod("KEYWORD_MATCHING");
                    field.setValidationStatus(ExtractedField.ValidationStatus.UNVALIDATED);
                    field.setUpdatedAt(java.time.LocalDateTime.now());
                    
                    fields.add(field);
                }
                
                index = content.toLowerCase().indexOf(keyword.toLowerCase(), index + 1);
            }
        }
        
        return fields;
    }
    
    /**
     * Process field value with transformations
     */
    private String processFieldValue(String rawValue, FieldExtractionConfig config) {
        String processedValue = rawValue;
        
        if (config.getTransformations() != null) {
            for (String transformation : config.getTransformations()) {
                processedValue = applyTransformation(processedValue, transformation);
            }
        }
        
        return processedValue.trim();
    }
    
    /**
     * Apply transformation to field value
     */
    private String applyTransformation(String value, String transformation) {
        return switch (transformation.toUpperCase()) {
            case "UPPERCASE" -> value.toUpperCase();
            case "LOWERCASE" -> value.toLowerCase();
            case "TRIM" -> value.trim();
            case "REMOVE_SPECIAL_CHARS" -> value.replaceAll("[^a-zA-Z0-9\\s]", "");
            case "REMOVE_WHITESPACE" -> value.replaceAll("\\s+", "");
            case "NORMALIZE_SPACES" -> value.replaceAll("\\s+", " ").trim();
            default -> value;
        };
    }
    
    /**
     * Extract value from context text
     */
    private String extractValueFromContext(String contextText, String keyword, FieldExtractionConfig config) {
        // Simple strategy: extract text after the keyword
        int keywordIndex = contextText.toLowerCase().indexOf(keyword.toLowerCase());
        if (keywordIndex == -1) return null;
        
        int startIndex = keywordIndex + keyword.length();
        String afterKeyword = contextText.substring(startIndex);
        
        // Split by common delimiters and get the first non-empty token
        String[] tokens = afterKeyword.split("[:\\s,;\n]");
        for (String token : tokens) {
            String cleaned = token.trim();
            if (!cleaned.isEmpty() && cleaned.length() > 1) {
                return processFieldValue(cleaned, config);
            }
        }
        
        return null;
    }
    
    /**
     * Determine which pages to search based on configuration
     */
    private List<Integer> determinePages(FieldExtractionConfig config, int totalPages) {
        List<Integer> pages = new ArrayList<>();
        
        if (config.getSearchAllPages() != null && config.getSearchAllPages()) {
            for (int i = 0; i < totalPages; i++) {
                pages.add(i);
            }
        } else if (config.getPageNumber() != null && config.getPageNumber() >= 0) {
            pages.add(config.getPageNumber());
        } else {
            // Default: first page only
            pages.add(0);
        }
        
        return pages;
    }
    
    /**
     * Get field type from PDF form field
     */
    private String getFieldType(PDField field) {
        String fieldType = field.getType();
        return switch (fieldType) {
            case "Tx" -> "TEXT";
            case "Ch" -> "CHOICE";
            case "Btn" -> "BUTTON";
            case "Sig" -> "SIGNATURE";
            default -> "UNKNOWN";
        };
    }
    
    /**
     * Get total page count
     */
    public int getPageCount(File pdfFile) throws IOException {
        try (PDDocument document = PDDocument.load(pdfFile)) {
            return document.getNumberOfPages();
        }
    }
}
