package com.example.fieldextraction.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "extracted_fields", indexes = {
    @Index(name = "idx_document_id", columnList = "document_id"),
    @Index(name = "idx_field_name", columnList = "field_name"),
    @Index(name = "idx_field_type", columnList = "field_type")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExtractedField {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_id", nullable = false)
    private Document document;
    
    @Column(nullable = false)
    private String fieldName;
    
    @Column(nullable = false)
    private String fieldType; // TEXT, NUMERIC, DATE, CHECKBOX, SIGNATURE, etc.
    
    @Column(columnDefinition = "LONGTEXT")
    private String fieldValue;
    
    @Column
    private Double confidence; // Confidence score from 0 to 1
    
    @Column
    private Integer pageNumber;
    
    @Column
    private Float boundingBoxX;
    
    @Column
    private Float boundingBoxY;
    
    @Column
    private Float boundingBoxWidth;
    
    @Column
    private Float boundingBoxHeight;
    
    @Column
    private String extractionMethod; // OCR, FORM_FIELD, REGEX, ML_MODEL, etc.
    
    @Column(columnDefinition = "LONGTEXT")
    private String rawText; // Raw extracted text before processing
    
    @Enumerated(EnumType.STRING)
    private ValidationStatus validationStatus; // VALID, INVALID, NEEDS_REVIEW
    
    @Column(columnDefinition = "LONGTEXT")
    private String validationNotes;
    
    @Column
    private Boolean manuallyVerified;
    
    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @Column(nullable = false)
    private LocalDateTime updatedAt;
    
    public enum ValidationStatus {
        VALID, INVALID, NEEDS_REVIEW, UNVALIDATED
    }
}
