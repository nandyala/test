package com.example.fieldextraction.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExtractionResponse {
    private String documentId;
    private String documentName;
    private String status;
    private List<ExtractedFieldDTO> extractedFields;
    private ExtractionMetrics metrics;
    private String error;
    private LocalDateTime processedAt;
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ExtractedFieldDTO {
        private String fieldName;
        private String fieldType;
        private String fieldValue;
        private Double confidence;
        private Integer pageNumber;
        private String validationStatus;
        private BoundingBox boundingBox;
        private String extractionMethod;
        private String validationNotes;
    }
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BoundingBox {
        private Float x;
        private Float y;
        private Float width;
        private Float height;
    }
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ExtractionMetrics {
        private Integer totalFieldsExtracted;
        private Integer validFields;
        private Integer invalidFields;
        private Integer fieldsNeedingReview;
        private Double averageConfidence;
        private Long processingTimeMs;
        private Float successRate;
    }
}
