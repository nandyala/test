package com.example.fieldextraction.service;

import com.example.fieldextraction.dto.FieldExtractionConfig;
import com.example.fieldextraction.entity.ExtractedField;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

@Service
@Slf4j
public class FieldValidationService {
    
    /**
     * Validate extracted field based on configuration
     */
    public void validateField(ExtractedField field, FieldExtractionConfig config) {
        try {
            if (field.getFieldValue() == null || field.getFieldValue().isEmpty()) {
                if (config.getRequired() != null && config.getRequired()) {
                    field.setValidationStatus(ExtractedField.ValidationStatus.INVALID);
                    field.setValidationNotes("Field is required but empty");
                } else {
                    field.setValidationStatus(ExtractedField.ValidationStatus.VALID);
                }
                return;
            }
            
            // Validate based on field type
            boolean isValid = validateByType(field, config);
            
            // Validate using regex if provided
            if (isValid && config.getValidationRules() != null 
                    && config.getValidationRules().getPattern() != null) {
                isValid = validateByPattern(field.getFieldValue(), 
                    config.getValidationRules().getPattern());
            }
            
            // Validate length constraints
            if (isValid && config.getValidationRules() != null) {
                if (config.getValidationRules().getMinLength() != null 
                        && field.getFieldValue().length() < config.getValidationRules().getMinLength()) {
                    isValid = false;
                    field.setValidationNotes("Value is shorter than minimum length: " 
                        + config.getValidationRules().getMinLength());
                }
                
                if (config.getValidationRules().getMaxLength() != null 
                        && field.getFieldValue().length() > config.getValidationRules().getMaxLength()) {
                    isValid = false;
                    field.setValidationNotes("Value is longer than maximum length: " 
                        + config.getValidationRules().getMaxLength());
                }
            }
            
            // Validate against allowed values
            if (isValid && config.getValidationRules() != null 
                    && config.getValidationRules().getAllowedValues() != null 
                    && !config.getValidationRules().getAllowedValues().isEmpty()) {
                if (!config.getValidationRules().getAllowedValues().contains(field.getFieldValue())) {
                    isValid = false;
                    field.setValidationNotes("Value not in allowed values list");
                }
            }
            
            field.setValidationStatus(isValid ? 
                ExtractedField.ValidationStatus.VALID : ExtractedField.ValidationStatus.INVALID);
        } catch (Exception e) {
            log.error("Error validating field: {}", field.getFieldName(), e);
            field.setValidationStatus(ExtractedField.ValidationStatus.NEEDS_REVIEW);
            field.setValidationNotes("Validation error: " + e.getMessage());
        }
    }
    
    /**
     * Validate field by type
     */
    private boolean validateByType(ExtractedField field, FieldExtractionConfig config) {
        String fieldType = config.getFieldType().toUpperCase();
        String value = field.getFieldValue();
        
        return switch (fieldType) {
            case "EMAIL" -> validateEmail(value);
            case "PHONE" -> validatePhone(value);
            case "DATE" -> validateDate(value);
            case "NUMERIC" -> validateNumeric(value);
            case "CURRENCY" -> validateCurrency(value);
            case "ZIPCODE" -> validateZipCode(value);
            case "SSN" -> validateSSN(value);
            case "TEXT", "TEXTBOX" -> !value.isEmpty();
            case "CHECKBOX", "SIGNATURE" -> true; // Already validated if present
            default -> true;
        };
    }
    
    /**
     * Validate email format
     */
    private boolean validateEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return Pattern.matches(emailRegex, email);
    }
    
    /**
     * Validate phone number
     */
    private boolean validatePhone(String phone) {
        // Remove common separators
        String cleaned = phone.replaceAll("[\\s\\-\\(\\)]+", "");
        // US format: 10 digits
        return cleaned.matches("\\d{10}") || cleaned.matches("\\d{11}");
    }
    
    /**
     * Validate date format
     */
    private boolean validateDate(String date) {
        String[] dateFormats = {
            "yyyy-MM-dd",
            "MM/dd/yyyy",
            "dd/MM/yyyy",
            "yyyy/MM/dd",
            "dd-MM-yyyy",
            "MMddyyyy"
        };
        
        for (String format : dateFormats) {
            try {
                LocalDate.parse(date, DateTimeFormatter.ofPattern(format));
                return true;
            } catch (Exception e) {
                // Try next format
            }
        }
        return false;
    }
    
    /**
     * Validate numeric value
     */
    private boolean validateNumeric(String value) {
        try {
            Double.parseDouble(value.replaceAll("[^\\d.-]", ""));
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    /**
     * Validate currency format
     */
    private boolean validateCurrency(String value) {
        String currencyRegex = "^\\$?\\d+(\\.\\d{2})?$";
        return Pattern.matches(currencyRegex, value);
    }
    
    /**
     * Validate US ZIP code
     */
    private boolean validateZipCode(String zipcode) {
        String zipRegex = "^\\d{5}(-\\d{4})?$";
        return Pattern.matches(zipRegex, zipcode);
    }
    
    /**
     * Validate Social Security Number
     */
    private boolean validateSSN(String ssn) {
        String ssnRegex = "^\\d{3}-\\d{2}-\\d{4}$";
        return Pattern.matches(ssnRegex, ssn);
    }
    
    /**
     * Validate by regex pattern
     */
    private boolean validateByPattern(String value, String pattern) {
        try {
            return Pattern.matches(pattern, value);
        } catch (Exception e) {
            log.error("Invalid regex pattern: {}", pattern, e);
            return false;
        }
    }
}
