package com.example.fieldextraction.repository;

import com.example.fieldextraction.entity.ExtractedField;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExtractedFieldRepository extends JpaRepository<ExtractedField, String> {
    List<ExtractedField> findByDocumentId(String documentId);
    List<ExtractedField> findByFieldName(String fieldName);
    
    @Query("SELECT ef FROM ExtractedField ef WHERE ef.document.id = ?1 AND ef.validationStatus = ?2")
    List<ExtractedField> findByDocumentIdAndValidationStatus(String documentId, ExtractedField.ValidationStatus status);
    
    @Query("SELECT ef FROM ExtractedField ef WHERE ef.fieldName = ?1 AND ef.validationStatus = ?2")
    List<ExtractedField> findByFieldNameAndValidationStatus(String fieldName, ExtractedField.ValidationStatus status);
    
    List<ExtractedField> findByValidationStatus(ExtractedField.ValidationStatus status);
}
