package com.example.fieldextraction.controller;

import com.example.fieldextraction.dto.ExtractionResponse;
import com.example.fieldextraction.dto.FieldExtractionConfig;
import com.example.fieldextraction.entity.Document;
import com.example.fieldextraction.entity.ExtractedField;
import com.example.fieldextraction.service.DocumentExtractionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/v1/extraction")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Document Field Extraction", description = "Extract and preserve fields from PDF and TIFF documents")
public class DocumentExtractionController {
    
    private final DocumentExtractionService extractionService;
    
    @PostMapping(value = "/extract", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Extract fields from document", description = "Process PDF or TIFF and extract configured fields")
    @ApiResponse(responseCode = "200", description = "Document processed successfully")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<ExtractionResponse> extractFields(
            @RequestParam("file") MultipartFile file,
            @RequestParam("fieldConfigs") String fieldConfigsJson) {
        
        log.info("Received extraction request for file: {}", file.getOriginalFilename());
        
        try {
            // Parse field configurations (from JSON)
            List<FieldExtractionConfig> fieldConfigs = parseFieldConfigs(fieldConfigsJson);
            
            // Process document
            ExtractionResponse response = extractionService.processDocument(file, fieldConfigs);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error extracting fields: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ExtractionResponse.builder()
                            .error(e.getMessage())
                            .build());
        }
    }
    
    @PostMapping(value = "/extract-async", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Extract fields asynchronously", description = "Submit document for async processing")
    @ApiResponse(responseCode = "202", description = "Document submitted for processing")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<ExtractionResponse> extractFieldsAsync(
            @RequestParam("file") MultipartFile file,
            @RequestParam("fieldConfigs") String fieldConfigsJson,
            @RequestParam(value = "callbackUrl", required = false) String callbackUrl) {
        
        log.info("Received async extraction request for file: {}", file.getOriginalFilename());
        
        try {
            List<FieldExtractionConfig> fieldConfigs = parseFieldConfigs(fieldConfigsJson);
            
            // Process asynchronously
            extractionService.processDocumentAsync(file, fieldConfigs, callbackUrl);
            
            return ResponseEntity.accepted()
                    .body(ExtractionResponse.builder()
                            .status("PROCESSING")
                            .build());
        } catch (Exception e) {
            log.error("Error submitting async extraction: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ExtractionResponse.builder()
                            .error(e.getMessage())
                            .build());
        }
    }
    
    @GetMapping("/document/{documentId}")
    @Operation(summary = "Get document details", description = "Retrieve document and its extracted fields")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getDocument(@PathVariable String documentId) {
        return extractionService.getDocument(documentId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/fields/{documentId}")
    @Operation(summary = "Get extracted fields", description = "Retrieve all extracted fields for a document")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<List<ExtractedField>> getExtractedFields(@PathVariable String documentId) {
        List<ExtractedField> fields = extractionService.getExtractedFields(documentId);
        return ResponseEntity.ok(fields);
    }
    
    @GetMapping("/health")
    @Operation(summary = "Health check", description = "Check service availability")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Service is running");
    }
    
    /**
     * Parse field configurations from JSON string
     * In production, use ObjectMapper from Jackson
     */
    private List<FieldExtractionConfig> parseFieldConfigs(String json) {
        // This is a placeholder - in production use proper JSON parsing
        return List.of();
    }
}
