package com.example.fieldextraction.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "documents")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class Document {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Column(nullable = false)
    private String documentName;
    
    @Column(nullable = false)
    private String documentType; // PDF, TIFF, etc.
    
    @Column(nullable = false)
    private String filePath;
    
    @Column(columnDefinition = "LONGTEXT")
    private String rawContent;
    
    @Enumerated(EnumType.STRING)
    private ProcessingStatus status; // PENDING, PROCESSING, COMPLETED, FAILED
    
    @Column(columnDefinition = "LONGTEXT")
    private String processingError;
    
    @Column
    private Long fileSize;
    
    @Column
    private Integer pageCount;
    
    @Column
    private String checksum;
    
    @OneToMany(mappedBy = "document", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ExtractedField> extractedFields;
    
    @OneToMany(mappedBy = "document", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<DocumentMetadata> metadata;
    
    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @LastModifiedDate
    @Column(nullable = false)
    private LocalDateTime updatedAt;
    
    public enum ProcessingStatus {
        PENDING, PROCESSING, COMPLETED, FAILED, PARTIALLY_COMPLETED
    }
}
