-- V1__Initial_schema.sql
-- Documents table
CREATE TABLE IF NOT EXISTS documents (
    id VARCHAR(36) PRIMARY KEY,
    document_name VARCHAR(255) NOT NULL,
    document_type VARCHAR(50) NOT NULL,
    file_path TEXT NOT NULL,
    raw_content LONGTEXT,
    status VARCHAR(50) NOT NULL,
    processing_error LONGTEXT,
    file_size BIGINT,
    page_count INT,
    checksum VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_document_type (document_type),
    INDEX idx_checksum (checksum)
);

-- Extracted fields table
CREATE TABLE IF NOT EXISTS extracted_fields (
    id VARCHAR(36) PRIMARY KEY,
    document_id VARCHAR(36) NOT NULL,
    field_name VARCHAR(255) NOT NULL,
    field_type VARCHAR(50),
    field_value LONGTEXT,
    confidence DECIMAL(3,2),
    page_number INT,
    bounding_box_x FLOAT,
    bounding_box_y FLOAT,
    bounding_box_width FLOAT,
    bounding_box_height FLOAT,
    extraction_method VARCHAR(50),
    raw_text LONGTEXT,
    validation_status VARCHAR(50),
    validation_notes LONGTEXT,
    manually_verified BOOLEAN,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE,
    INDEX idx_document_id (document_id),
    INDEX idx_field_name (field_name),
    INDEX idx_field_type (field_type),
    INDEX idx_validation_status (validation_status)
);

-- Document metadata table
CREATE TABLE IF NOT EXISTS document_metadata (
    id VARCHAR(36) PRIMARY KEY,
    document_id VARCHAR(36) NOT NULL,
    metadata_key VARCHAR(255) NOT NULL,
    metadata_value LONGTEXT,
    data_type VARCHAR(50),
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE,
    INDEX idx_document_id (document_id),
    INDEX idx_metadata_key (metadata_key)
);

-- Create view for validation summary
CREATE OR REPLACE VIEW document_validation_summary AS
SELECT 
    d.id,
    d.document_name,
    d.status,
    COUNT(ef.id) as total_fields,
    SUM(CASE WHEN ef.validation_status = 'VALID' THEN 1 ELSE 0 END) as valid_fields,
    SUM(CASE WHEN ef.validation_status = 'INVALID' THEN 1 ELSE 0 END) as invalid_fields,
    SUM(CASE WHEN ef.validation_status = 'NEEDS_REVIEW' THEN 1 ELSE 0 END) as needs_review,
    AVG(ef.confidence) as avg_confidence
FROM documents d
LEFT JOIN extracted_fields ef ON d.id = ef.document_id
GROUP BY d.id, d.document_name, d.status;
