# Document Field Extraction - Implementation Guide

## Overview

This solution provides **intelligent field extraction from PDF and TIFF documents** with **database persistence**. It combines multiple extraction strategies to accurately identify and preserve specific document fields.

## Key Components

### 1. **PdfFieldExtractor** Service
Handles PDF documents through three mechanisms:
- **Form Field Extraction**: Directly reads PDF form fields (AcroForm)
- **Pattern Matching**: Uses regex to find structured data
- **Keyword Matching**: Context-aware extraction near specific keywords

```java
// Example: Extract form fields
List<ExtractedField> formFields = pdfExtractor.extractFormFields(pdfFile);

// Example: Extract using patterns
List<ExtractedField> patternFields = pdfExtractor.extractFieldsByPattern(
    pdfFile, 
    fieldConfigs
);
```

### 2. **TiffFieldExtractor** Service
Handles TIFF documents using OCR:
- **Tesseract OCR**: Extracts text from scanned images
- **Pattern Matching**: Same regex-based approach on OCR'd text
- **Multi-page Support**: Processes each TIFF page individually

```java
// Extract text with OCR
String extractedText = tiffExtractor.extractTextFromTiff(tiffFile);

// Extract fields using patterns
List<ExtractedField> fields = tiffExtractor.extractFieldsByPattern(
    tiffFile, 
    fieldConfigs
);
```

### 3. **FieldValidationService**
Validates extracted fields based on configuration:
- **Type-based Validation**: EMAIL, PHONE, DATE, CURRENCY, SSN, ZIPCODE
- **Pattern Validation**: Custom regex patterns
- **Constraint Validation**: Length, allowed values, format
- **Status Tracking**: VALID, INVALID, NEEDS_REVIEW

```java
// Validate extracted field
validationService.validateField(extractedField, config);
// Sets validation_status and validation_notes
```

### 4. **DocumentExtractionService**
Orchestrates the entire extraction workflow:
- Saves documents to disk and database
- Coordinates extractors
- Manages validation
- Handles deduplication
- Calculates metrics

## Real-World Examples

### Example 1: Invoice Processing

**Configuration**:
```json
{
  "fieldName": "invoice_number",
  "fieldType": "TEXT",
  "keywords": ["Invoice #", "Invoice Number"],
  "regexPattern": "INV-\\d{6}",
  "transformations": ["UPPERCASE", "TRIM"],
  "validationRules": {
    "pattern": "INV-\\d{6}",
    "minLength": 10
  }
}
```

**Extraction Flow**:
1. Extract all form fields from PDF (if any)
2. Search PDF text for "Invoice #" keyword
3. Extract text matching pattern `INV-\d{6}`
4. Apply transformations (UPPERCASE, TRIM)
5. Validate against pattern `INV-\d{6}`
6. Store in database with confidence score and page number

**Database Result**:
```sql
INSERT INTO extracted_fields (
  document_id, field_name, field_value, extraction_method, 
  validation_status, page_number, created_at
) VALUES (
  'doc-123', 'invoice_number', 'INV-001234', 'KEYWORD_MATCHING',
  'VALID', 0, NOW()
);
```

### Example 2: Multi-Page Form Processing

**Configuration for searching all pages**:
```json
{
  "fieldName": "signature",
  "fieldType": "SIGNATURE",
  "searchAllPages": true,
  "keywords": ["Authorized By", "Signature", "Signed"],
  "templateOptions": {
    "contextWindowSize": 200.0
  }
}
```

**Process**:
1. Iterate through each page of document
2. Search for keyword "Signature" on each page
3. Extract context window (200 chars) after keyword
4. Deduplicate results (keep first valid occurrence)
5. Store all results with page numbers

**Database Result**: Multiple records, one per page
```sql
-- Page 0
INSERT INTO extracted_fields (...) VALUES (..., 'signature', '...', 0);
-- Page 5
INSERT INTO extracted_fields (...) VALUES (..., 'signature', '...', 5);
```

### Example 3: Scanned Document (TIFF) Processing

**Configuration with OCR**:
```json
{
  "fieldName": "document_title",
  "fieldType": "TEXT",
  "keywords": ["Document Title", "Title:"],
  "templateOptions": {
    "useOCR": true,
    "contextWindowSize": 100.0
  }
}
```

**Process**:
1. Convert each TIFF page to BufferedImage
2. Run Tesseract OCR on each image
3. Search OCR'd text for keyword
4. Extract and clean OCR results
5. Validate extracted value
6. Store with confidence score from OCR

### Example 4: Date Field with Multiple Formats

**Configuration**:
```json
{
  "fieldName": "invoice_date",
  "fieldType": "DATE",
  "keywords": ["Date:", "Dated"],
  "regexPattern": "\\d{1,2}[/-]\\d{1,2}[/-]\\d{4}",
  "transformations": ["NORMALIZE_SPACES"],
  "validationRules": {
    "pattern": "^(\\d{1,2}[/-]\\d{1,2}[/-]\\d{4})$"
  }
}
```

**Field Validation**:
- Accepts formats: MM/DD/YYYY, MM-DD-YYYY, DD/MM/YYYY, etc.
- Normalizes spaces before validation
- Validates extracted date exists in extracted_fields table

### Example 5: Currency with Special Characters

**Configuration**:
```json
{
  "fieldName": "invoice_total",
  "fieldType": "CURRENCY",
  "keywords": ["Total:", "Amount Due"],
  "regexPattern": "\\$([\\d,]+\\.\\d{2})",
  "transformations": ["REMOVE_SPECIAL_CHARS"],
  "validationRules": {
    "pattern": "^\\$?\\d+(\\.\\d{2})?$"
  }
}
```

**Transformation Flow**:
1. Raw OCR: "$1,234.56"
2. Extraction: "1,234.56"
3. Transformation: "123456"
4. Validation: Passes (is valid currency)
5. Stored value: "1234.56"

## Database Schema Usage

### Document Storage
```sql
-- Store reference to uploaded document
INSERT INTO documents (id, document_name, document_type, file_path, status)
VALUES ('uuid', 'invoice.pdf', 'PDF', '/uploads/uuid_invoice.pdf', 'PROCESSING');
```

### Field Storage
```sql
-- Store extracted fields with metadata
INSERT INTO extracted_fields 
(document_id, field_name, field_value, confidence, page_number, 
 extraction_method, validation_status)
VALUES 
('doc-id', 'invoice_number', 'INV-001234', 0.95, 0, 'KEYWORD_MATCHING', 'VALID'),
('doc-id', 'total_amount', '1234.56', 0.98, 0, 'REGEX', 'VALID'),
('doc-id', 'signature', 'John Doe', 0.65, 5, 'OCR', 'NEEDS_REVIEW');
```

### Querying Extracted Data

```sql
-- Get all valid fields for a document
SELECT * FROM extracted_fields 
WHERE document_id = 'doc-123' AND validation_status = 'VALID';

-- Find fields needing review
SELECT d.document_name, ef.field_name, ef.field_value
FROM documents d
JOIN extracted_fields ef ON d.id = ef.document_id
WHERE ef.validation_status = 'NEEDS_REVIEW'
ORDER BY ef.confidence ASC;

-- Get extraction summary
SELECT 
    document_name,
    COUNT(*) as total_fields,
    SUM(CASE WHEN validation_status = 'VALID' THEN 1 END) as valid_count,
    AVG(confidence) as avg_confidence
FROM documents d
JOIN extracted_fields ef ON d.id = ef.document_id
GROUP BY d.id;
```

## API Usage Examples

### Curl Example: Extract Invoice Fields

```bash
# 1. Create field configuration
cat > invoice-config.json << 'EOF'
{
  "fieldConfigs": [
    {
      "fieldName": "invoice_number",
      "fieldType": "TEXT",
      "keywords": ["Invoice #", "INV"],
      "regexPattern": "INV-\\d{6}",
      "validationRules": {"pattern": "INV-\\d{6}"}
    },
    {
      "fieldName": "invoice_date",
      "fieldType": "DATE",
      "keywords": ["Date:"],
      "validationRules": {"pattern": "\\d{1,2}/\\d{1,2}/\\d{4}"}
    }
  ]
}
EOF

# 2. Submit document for processing
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@invoice.pdf" \
  -F "fieldConfigs=@invoice-config.json"

# Response:
# {
#   "documentId": "550e8400-e29b-41d4-a716-446655440000",
#   "status": "COMPLETED",
#   "extractedFields": [
#     {
#       "fieldName": "invoice_number",
#       "fieldValue": "INV-001234",
#       "validationStatus": "VALID",
#       "confidence": 0.95
#     }
#   ],
#   "metrics": {
#     "totalFieldsExtracted": 2,
#     "validFields": 2,
#     "successRate": 1.0
#   }
# }

# 3. Retrieve extracted data
curl http://localhost:8081/api/v1/extraction/fields/{documentId} \
  -u user:password123
```

### Java Example: Programmatic Usage

```java
@Service
public class InvoiceProcessingService {
    
    @Autowired
    private DocumentExtractionService extractionService;
    
    public void processInvoice(MultipartFile invoiceFile) throws Exception {
        // Define fields to extract
        List<FieldExtractionConfig> fieldConfigs = List.of(
            FieldExtractionConfig.builder()
                .fieldName("invoice_number")
                .fieldType("TEXT")
                .keywords(List.of("Invoice #", "INV"))
                .regexPattern("INV-\\d{6}")
                .transformations(List.of("UPPERCASE", "TRIM"))
                .validationRules(new ValidationRules(
                    "INV-\\d{6}", 5, 20, null, null
                ))
                .build(),
            
            FieldExtractionConfig.builder()
                .fieldName("invoice_total")
                .fieldType("CURRENCY")
                .keywords(List.of("Total:", "Amount Due"))
                .regexPattern("\\$([\\d,]+\\.\\d{2})")
                .transformations(List.of("REMOVE_SPECIAL_CHARS"))
                .build()
        );
        
        // Process document
        ExtractionResponse response = extractionService.processDocument(
            invoiceFile, 
            fieldConfigs
        );
        
        // Handle results
        System.out.println("Document ID: " + response.getDocumentId());
        System.out.println("Status: " + response.getStatus());
        System.out.println("Success Rate: " + response.getMetrics().getSuccessRate());
        
        for (ExtractedFieldDTO field : response.getExtractedFields()) {
            if ("VALID".equals(field.getValidationStatus())) {
                System.out.println(field.getFieldName() + ": " + field.getFieldValue());
            }
        }
    }
}
```

## Advanced Features

### Bounding Box Tracking
Extracted fields include position information (for UI overlays):
```json
"boundingBox": {
  "x": 150.5,
  "y": 200.3,
  "width": 120.0,
  "height": 20.0
}
```

### Confidence Scoring
Each extraction includes confidence (0-1):
- Form fields: 1.0 (highest confidence)
- Pattern matches: 0.85-0.95 (high confidence)
- OCR results: 0.65-0.85 (variable based on quality)
- Keyword matches: 0.70-0.90 (context-dependent)

### Deduplication Strategy
When multiple extraction methods find the same field:
```java
// Keeps the highest confidence result
if (extractedField.getConfidence() > existing.getConfidence()) {
    deduplicated.put(key, extractedField);
}
```

### Manual Verification Flag
Fields can be marked for human review:
```sql
UPDATE extracted_fields 
SET manually_verified = true, validation_notes = 'Verified by John Doe'
WHERE id = 'field-id';
```

## Performance Tips

1. **Use Regex Patterns**: More efficient than keyword matching
2. **Limit Page Search**: Specify `pageNumber` instead of `searchAllPages`
3. **Batch Processing**: Use async endpoint for multiple documents
4. **Database Indexing**: Indexes on document_id, field_name, validation_status
5. **OCR Configuration**: Tune Tesseract page segmentation mode for document type

## Troubleshooting Common Issues

### Issue: Low Confidence Scores
**Solution**:
- Increase Tesseract DPI setting
- Check document quality
- Use more specific keywords
- Add image enhancement

### Issue: Missing Fields
**Solution**:
- Verify field configuration correctness
- Check regex pattern with test data
- Try broader keyword matching
- Review raw OCR text

### Issue: False Positives
**Solution**:
- Make regex patterns more specific
- Add length constraints
- Use validation patterns
- Mark false positives and adjust patterns

---

This implementation provides **production-ready field extraction** with **flexible configuration**, **robust validation**, and **complete database tracking** for PDF and TIFF documents.
