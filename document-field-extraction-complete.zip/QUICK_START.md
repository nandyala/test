# Quick Start Guide - Document Field Extraction

## 5-Minute Setup

### Step 1: Install Dependencies
```bash
# MySQL
docker run -d --name mysql \
  -e MYSQL_ROOT_PASSWORD=password \
  -e MYSQL_DATABASE=document_extraction \
  -p 3306:3306 \
  mysql:8.0

# Tesseract (for TIFF support)
sudo apt-get update
sudo apt-get install tesseract-ocr tesseract-ocr-eng
```

### Step 2: Configure Database
```bash
cd document-field-extraction

# Edit src/main/resources/application.properties
spring.datasource.url=jdbc:mysql://localhost:3306/document_extraction
spring.datasource.username=root
spring.datasource.password=password
```

### Step 3: Build & Run
```bash
mvn clean package
java -jar target/document-field-extraction-1.0.0.jar
```

Visit: http://localhost:8081/swagger-ui.html

---

## Extract Fields from Your First Document

### Step 1: Create Field Configuration

Create `invoice-config.json`:
```json
{
  "fieldConfigs": [
    {
      "fieldName": "invoice_number",
      "fieldType": "TEXT",
      "keywords": ["Invoice #", "Invoice Number"],
      "regexPattern": "INV-\\d{6}",
      "validationRules": {"pattern": "INV-\\d{6}"}
    },
    {
      "fieldName": "invoice_date",
      "fieldType": "DATE",
      "keywords": ["Date:", "Dated:"],
      "validationRules": {"pattern": "\\d{1,2}/\\d{1,2}/\\d{4}"}
    },
    {
      "fieldName": "total_amount",
      "fieldType": "CURRENCY",
      "keywords": ["Total:", "Amount Due"],
      "regexPattern": "\\$([\\d,]+\\.\\d{2})",
      "validationRules": {"pattern": "^\\$?\\d+(\\.\\d{2})?$"}
    }
  ]
}
```

### Step 2: Extract Fields

```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@invoice.pdf" \
  -F "fieldConfigs=@invoice-config.json" \
  -H "Accept: application/json" | jq
```

### Step 3: View Results

Response:
```json
{
  "documentId": "550e8400-e29b-41d4-a716-446655440000",
  "documentName": "invoice.pdf",
  "status": "COMPLETED",
  "extractedFields": [
    {
      "fieldName": "invoice_number",
      "fieldValue": "INV-001234",
      "validationStatus": "VALID",
      "confidence": 0.95,
      "pageNumber": 0
    },
    {
      "fieldName": "invoice_date",
      "fieldValue": "05/15/2024",
      "validationStatus": "VALID",
      "confidence": 0.98,
      "pageNumber": 0
    },
    {
      "fieldName": "total_amount",
      "fieldValue": "1234.56",
      "validationStatus": "VALID",
      "confidence": 0.99,
      "pageNumber": 0
    }
  ],
  "metrics": {
    "totalFieldsExtracted": 3,
    "validFields": 3,
    "invalidFields": 0,
    "successRate": 1.0,
    "processingTimeMs": 1234
  }
}
```

### Step 4: Retrieve from Database

```bash
# Get document details
curl http://localhost:8081/api/v1/extraction/document/550e8400-e29b-41d4-a716-446655440000 \
  -u user:password123

# Get all extracted fields
curl http://localhost:8081/api/v1/extraction/fields/550e8400-e29b-41d4-a716-446655440000 \
  -u user:password123
```

---

## Common Field Configurations

### Simple Text Field
```json
{
  "fieldName": "company_name",
  "fieldType": "TEXT",
  "keywords": ["Company:", "Business Name"],
  "transformations": ["TRIM"],
  "validationRules": {"minLength": 2, "maxLength": 255}
}
```

### Email Field
```json
{
  "fieldName": "contact_email",
  "fieldType": "EMAIL",
  "regexPattern": "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}",
  "validationRules": {"pattern": "^[A-Za-z0-9+_.-]+@(.+)$"}
}
```

### Phone Number
```json
{
  "fieldName": "phone",
  "fieldType": "PHONE",
  "regexPattern": "\\b(\\d{3}[-.]?\\d{3}[-.]?\\d{4})\\b",
  "transformations": ["REMOVE_SPECIAL_CHARS"],
  "validationRules": {"pattern": "^\\d{10}$"}
}
```

### Date Field
```json
{
  "fieldName": "transaction_date",
  "fieldType": "DATE",
  "keywords": ["Transaction Date", "Date:"],
  "validationRules": {"pattern": "\\d{1,2}[/-]\\d{1,2}[/-]\\d{4}"}
}
```

### Currency Field
```json
{
  "fieldName": "amount",
  "fieldType": "CURRENCY",
  "keywords": ["Amount", "Price", "Total"],
  "regexPattern": "\\$?([\\d,]+\\.\\d{2})",
  "transformations": ["REMOVE_SPECIAL_CHARS"],
  "validationRules": {"pattern": "^\\d+(\\.\\d{2})?$"}
}
```

---

## Database Queries

### See All Extracted Data
```sql
SELECT 
    d.document_name,
    ef.field_name,
    ef.field_value,
    ef.validation_status,
    ef.confidence
FROM documents d
JOIN extracted_fields ef ON d.id = ef.document_id
ORDER BY d.created_at DESC
LIMIT 20;
```

### Find Invalid Fields
```sql
SELECT 
    d.document_name,
    ef.field_name,
    ef.field_value,
    ef.validation_notes
FROM documents d
JOIN extracted_fields ef ON d.id = ef.document_id
WHERE ef.validation_status = 'INVALID'
ORDER BY ef.confidence ASC;
```

### Processing Statistics
```sql
SELECT 
    DATE(d.created_at) as date,
    COUNT(DISTINCT d.id) as documents_processed,
    COUNT(ef.id) as total_fields,
    SUM(CASE WHEN ef.validation_status = 'VALID' THEN 1 ELSE 0 END) as valid_fields,
    ROUND(AVG(ef.confidence), 2) as avg_confidence
FROM documents d
JOIN extracted_fields ef ON d.id = ef.document_id
GROUP BY DATE(d.created_at)
ORDER BY date DESC;
```

---

## Troubleshooting

### Issue: "Cannot connect to database"
```bash
# Check MySQL is running
docker ps | grep mysql

# Verify credentials in application.properties
spring.datasource.url=jdbc:mysql://localhost:3306/document_extraction
spring.datasource.username=root
spring.datasource.password=password
```

### Issue: "Tesseract not found" (for TIFF)
```bash
# Install Tesseract
sudo apt-get install tesseract-ocr

# Set data path (if not in default location)
export TESSDATA_PREFIX=/usr/share/tesseract-ocr/4.00/tessdata
```

### Issue: "File not found" error
```bash
# Create uploads directory
mkdir -p uploads/documents

# Check permissions
chmod 755 uploads/documents
```

### Issue: Low confidence scores
- Check document quality (clarity, resolution)
- Use more specific keywords
- Add regex patterns for better matching
- For scanned documents, ensure good OCR quality

---

## Configuration Cheatsheet

### Keywords Search
```json
"keywords": ["Invoice #", "Invoice Number", "INV #"]
```
Searches for any of these keywords in the document.

### Regex Patterns
```json
"regexPattern": "INV-\\d{6}"  // Matches INV-001234
"regexPattern": "\\$([\\d,]+\\.\\d{2})"  // Matches $1,234.56
"regexPattern": "\\d{1,2}/\\d{1,2}/\\d{4}"  // Matches dates
```

### Transformations
```json
"transformations": [
  "UPPERCASE",              // ABC
  "LOWERCASE",              // abc
  "TRIM",                   // Remove spaces
  "REMOVE_SPECIAL_CHARS",   // abc123
  "NORMALIZE_SPACES"        // Collapse spaces
]
```

### Validation Rules
```json
"validationRules": {
  "pattern": "INV-\\d{6}",           // Regex pattern
  "minLength": 10,                   // Minimum length
  "maxLength": 20,                   // Maximum length
  "allowedValues": ["YES", "NO"]     // Allowed values
}
```

---

## Supported Document Types

### PDFs
- ✅ Fillable forms (extracting form fields)
- ✅ Text-based PDFs
- ✅ Mixed content (forms + images)
- ⚠️ Scanned PDFs (use OCR methods)

### TIFFs
- ✅ Single page TIFF
- ✅ Multi-page TIFF
- ✅ Scanned documents
- ✅ Faxed documents

---

## Field Types & Auto-Validation

| Field Type | Example | Validation | Confidence |
|------------|---------|-----------|-----------|
| TEXT | Any text | Length, pattern | 0.85-0.95 |
| EMAIL | user@domain.com | Email format | 0.90-0.98 |
| PHONE | (123) 456-7890 | 10-11 digits | 0.85-0.95 |
| DATE | 05/15/2024 | Date format | 0.90-0.99 |
| NUMERIC | 12345.67 | Number | 0.95-0.99 |
| CURRENCY | $1,234.56 | Currency format | 0.90-0.98 |
| SSN | 123-45-6789 | SSN format | 0.95-0.99 |
| ZIPCODE | 12345 | ZIP format | 0.95-0.99 |

---

## Example Real-World Scenario

### Processing W-2 Tax Forms (TIFF)

**Field Configuration**:
```json
{
  "fieldConfigs": [
    {
      "fieldName": "box_1_wages",
      "fieldType": "CURRENCY",
      "pageNumber": 0,
      "keywords": ["Box 1", "Wages"],
      "templateOptions": {"contextWindowSize": 150}
    },
    {
      "fieldName": "box_2_federal_tax",
      "fieldType": "CURRENCY",
      "keywords": ["Box 2", "Federal"],
      "templateOptions": {"contextWindowSize": 150}
    },
    {
      "fieldName": "employee_ssn",
      "fieldType": "SSN",
      "keywords": ["Employee", "SSN"],
      "regexPattern": "\\d{3}-\\d{2}-\\d{4}"
    },
    {
      "fieldName": "employer_ein",
      "fieldType": "TEXT",
      "keywords": ["EIN", "Employer ID"],
      "regexPattern": "\\d{2}-\\d{7}"
    }
  ]
}
```

**Processing**:
```bash
curl -X POST http://localhost:8081/api/v1/extraction/extract \
  -u user:password123 \
  -F "file=@w2_form_2024.tiff" \
  -F "fieldConfigs=@w2-config.json"
```

**Results Stored**:
- Document record with filename, status, page count
- Extracted fields with values and confidence scores
- Validation status for each field
- Page numbers where fields were found

---

## Tips for Success

1. **Start Simple**: Begin with text fields before complex ones
2. **Test Keywords**: Verify keywords appear in your documents
3. **Test Regex**: Use online regex testers before adding to config
4. **Check Confidence**: Monitor confidence scores to adjust patterns
5. **Use Transformations**: Clean data before validation
6. **Manual Review**: Mark uncertain fields for human verification
7. **Batch Testing**: Process sample documents before bulk operations
8. **Monitor Metrics**: Track success rates and confidence trends

---

## Next Steps

1. ✅ Setup database and service
2. ✅ Create field configuration for your document type
3. ✅ Test with sample documents
4. ✅ Adjust patterns based on results
5. ✅ Deploy to production
6. ✅ Monitor extraction quality
7. ✅ Refine rules over time

---

**Questions?** Check the complete documentation in:
- `/document-field-extraction/README.md`
- `/IMPLEMENTATION_GUIDE.md`
- `/SOLUTION_SUMMARY.md`
