# Template Data Dual-Source Design

## Goal

Retire large stored procedures without creating hardcoded Java procedures.

The new design must support both:

1. **Database source mode**: current batch process fetches facts from existing tables/views.
2. **JSON source mode**: future APIs/events send all required mapped fields directly as JSON, with no direct database dependency.

The important design rule is:

> The template assembly engine should not care whether data came from database tables or JSON. It should receive canonical source facts and produce template data.

## What The Sample Procedures Show

`one.sql` / form `9012` and `two.sql` / form `8722` repeat many same concepts.

Common logic:

- run date and business date
- buyer/co-buyer row handling
- buyer vs co-buyer recipient selection
- address line formatting
- postal code formatting
- city/state/ZIP formatting
- same-address detection
- LOB
- mail type
- send-to value
- barcode creation
- vehicle fields
- location code
- create PDF / pending / reject decision
- duplicate prior form suppression

Form-specific logic:

- form `9012` is event-reason based
- form `8722` is delinquency / repossession / bankruptcy / fraud / exception based
- form `8722` has more rejection and pending logic
- form `8722` uses form metadata such as `paper_size`, `num_sides`, and `is_active`

## Recommended Architecture

```text
Request
  |
  v
TemplateDataOrchestrator
  |
  v
Template Flow Config
  |
  v
Input Adapter
  |-------- DatabaseInputAdapter
  |-------- JsonInputAdapter
  |
  v
Canonical Source Facts
  |
  v
Reusable Assembly Steps
  |
  v
Rules / Decisions
  |
  v
Template Field Mapper
  |
  v
Validation
  |
  v
TemplateData JSON / DTO / Batch Writer
```

## Core Principle

Do not let business logic depend directly on database table names.

Bad:

```text
Rule reads pah.xcptn_typ_cd directly from database row
Mapper reads ctrct_buyr.addr_line_1 directly
Template step knows table alias names
```

Good:

```text
Rule reads sourceFacts.account.exceptionTypeCode
Mapper reads sourceFacts.recipient.address
Template step knows canonical domain fields only
```

## Canonical Source Model

Create one canonical input object that represents all facts needed by template assembly.

Example:

```json
{
  "request": {
    "requestId": "REQ-123",
    "templateCode": "8722",
    "runDate": "2026-06-10",
    "businessDate": "2026-06-09"
  },
  "account": {
    "accountNumber": "1234567890",
    "lobCode": "RL",
    "contractStatus": "ACTIVE",
    "contractStatusDate": "2026-01-15",
    "fraudTypeCode": "CI",
    "exceptionTypeCode": "AA",
    "zoneNumber": "250"
  },
  "buyer": {
    "customerNumber": "100",
    "fullName": "Anita Rao",
    "address": {
      "line1": "120 Main Street",
      "line2": "",
      "city": "Boston",
      "state": "MA",
      "postalCode": "021101234"
    }
  },
  "cobuyer": {
    "customerNumber": "101",
    "fullName": "Ravi Rao",
    "address": {
      "line1": "44 Side Street",
      "line2": "Apt 2",
      "city": "Boston",
      "state": "MA",
      "postalCode": "021111234"
    }
  },
  "vehicle": {
    "vin": "1HGBH41JXMN109186",
    "make": "Honda",
    "model": "Civic",
    "modelYear": "2022"
  },
  "location": {
    "areaNumber": "123",
    "regionNumber": "456",
    "zoneNumber": "789"
  },
  "formMetadata": {
    "formNumber": "8722",
    "active": true,
    "paperSize": "LETTER",
    "numSides": 1
  },
  "delinquency": {
    "daysPastDue": 35,
    "categoryCode": "R",
    "worklistQueueCode": 60,
    "paymentDueDate": "2026-06-01",
    "paymentAmount": 125.50
  },
  "event": {
    "processCode": "48,000",
    "reasonCode": "89,010",
    "reasonDescription": "Reason description",
    "lastUpdated": "2026-06-09"
  },
  "priorForms": {
    "hasDuplicatePendingForm": false
  },
  "exceptions": {
    "formExceptionCode": "0",
    "formExceptionReason": ""
  }
}
```

This JSON shape becomes the contract between data providers and the template assembly engine.

## Two Input Modes

### Mode 1: Database Source Mode

Used while database still exists.

```text
DatabaseInputAdapter
  -> fetch raw rows from tables/views
  -> map table columns to canonical source facts
  -> pass source facts to template engine
```

SQL responsibility:

- joins
- effective-date filtering
- set-based candidate fetch
- latest-row selection when needed
- data extraction

SQL should not own:

- address formatting
- buyer/co-buyer branching
- reject reason text
- create PDF decision
- mail type decision
- pending decision
- template output assembly

### Mode 2: JSON Source Mode

Used when upstream systems provide the facts directly.

```text
JsonInputAdapter
  -> validate JSON schema
  -> map JSON to canonical source facts
  -> pass source facts to template engine
```

No database calls should be needed if JSON contains all required facts.

## Package Design

```text
template-data/
  api/
    TemplateDataController
    TemplateDataRequest

  orchestration/
    TemplateDataOrchestrator

  source/
    TemplateSourceProvider
    DatabaseTemplateSourceProvider
    JsonTemplateSourceProvider
    SourceMode

  canonical/
    TemplateSourceFacts
    AccountFacts
    PartyFacts
    AddressFacts
    VehicleFacts
    LocationFacts
    FormMetadataFacts
    DelinquencyFacts
    EventFacts
    PriorFormFacts
    ExceptionFacts

  flow/
    TemplateFlow
    TemplateFlowConfig

  step/
    DataStep
    StepRegistry

  common/
    RecipientAssembler
    AddressFormatter
    PostalCodeFormatter
    CityStateZipFormatter
    SameAddressDetector
    BarcodeGenerator
    MailTypeResolver
    LocationCodeFormatter
    DispositionResolver

  rule/
    BusinessRule
    RuleResult
    RuleCatalog
    RuleEngine

  mapper/
    TemplateFieldMapper
    Form8722FieldMapper
    Form9012FieldMapper

  validation/
    RequiredFieldValidator
    TemplateSchemaValidator

  audit/
    AuditService
    AuditEvent

  repository/
    Form8722Repository
    Form9012Repository
```

## Source Provider Interface

```java
public interface TemplateSourceProvider {
    SourceMode mode();
    TemplateSourceFacts load(TemplateRequest request);
}
```

Implementations:

```java
public class DatabaseTemplateSourceProvider implements TemplateSourceProvider {
    public TemplateSourceFacts load(TemplateRequest request) {
        // Use repositories to fetch DB rows and map to canonical facts.
    }
}
```

```java
public class JsonTemplateSourceProvider implements TemplateSourceProvider {
    public TemplateSourceFacts load(TemplateRequest request) {
        // Use request JSON payload and map to canonical facts.
    }
}
```

## Request Design

```json
{
  "requestId": "REQ-123",
  "templateCode": "8722",
  "sourceMode": "DATABASE",
  "runDate": "2026-06-10",
  "keys": {
    "accountNumber": "1234567890"
  },
  "sourceFacts": null
}
```

For JSON mode:

```json
{
  "requestId": "REQ-124",
  "templateCode": "8722",
  "sourceMode": "JSON",
  "runDate": "2026-06-10",
  "sourceFacts": {
    "account": {},
    "buyer": {},
    "cobuyer": {},
    "vehicle": {},
    "formMetadata": {}
  }
}
```

## Template Flow

The template flow should start after source facts are loaded.

```text
loadSourceFacts
assembleRecipients
applyCommonFormatting
applyCommonRules
applyTemplateRules
mapTemplateFields
validateTemplateData
writeOrReturnOutput
```

Example YAML:

```yaml
templates:
  "9012":
    sourceProviders:
      - DATABASE
      - JSON
    steps:
      - assembleRecipients
      - applyAddressFormatting
      - applyDuplicateFormRules
      - mapForm9012Fields
      - validateOutput

  "8722":
    sourceProviders:
      - DATABASE
      - JSON
    steps:
      - assembleRecipients
      - applyAddressFormatting
      - applyBankruptcyFraudRules
      - applyFormExceptionRules
      - decidePendingOrCreatePdf
      - mapForm8722Fields
      - validateOutput
```

## Shared Components

### RecipientAssembler

Handles buyer/co-buyer repeated logic.

Responsibilities:

- produce buyer row
- produce co-buyer row when applicable
- select recipient name/address based on `isCobuyer`
- populate co-buyer display name on buyer row
- suppress co-buyer row when same address or missing name if template requires it

### AddressFormatter

Responsibilities:

- trim all address fields
- combine line 1 and line 2
- uppercase state
- format postal code
- build city/state/ZIP

### SameAddressDetector

Responsibilities:

- compare buyer and co-buyer address fields after trim/null handling

### BarcodeGenerator

Responsibilities:

- account number + timestamp
- future option: deterministic job timestamp instead of current timestamp

### MailTypeResolver

Responsibilities:

- `first_class = 1 and certified = 1 -> X`
- `certified = 1 -> C`
- else `R`

### DispositionResolver

Responsibilities:

- rejected business rule flag
- rejected data flag
- pending flag
- create PDF flag
- final rejection reason

## Avoiding Hardcoding

Move constants and reason mappings into configuration or reference data.

### Good candidates for config

```yaml
forms:
  "9012":
    formNumber: "9012"
    lobCode: "RL"
    mailType: "R"
    sendTo: "B"
    firstClass: true
    certified: false
    numSides: 1
    event:
      processCode: "48,000"
      allowedReasonCodes:
        - "89,010"
        - "89,020"
        - "89,030"
        - "89,040"
        - "89,050"
        - "89,060"
        - "89,070"
        - "89,080"
        - "89,090"

  "8722":
    formNumber: "8722"
    sendTo: "B"
    firstClass: true
    certified: false
    licenseRequiredStates:
      - "NC"
```

### Good candidates for rule catalog

```yaml
rules:
  bankruptcyRejectReasons:
    A: "In Bankruptcy, Chapter 7"
    AA: "In Bankruptcy, Chapter 7"
    AB: "In BK - Discharged Non-Reaffirmed"
    QA: "Joint Acct Primary filed Petition 11"
    QB: "Joint Acct Primary filed Discharged Non Reaffirmed 11"

  fraudRejectReasons:
    CI: "Confirmed Identity Theft"
    DI: "Confirmed Identity Theft"
    CF: "Confirmed Fraud"
    DF: "Confirmed Fraud"
    CY: "Confirmed Synthetic Identity Theft"
```

Do not hardcode these lists inside Java methods unless they are temporary during migration.

## Database Retirement Strategy

### Phase 1: Current state

```text
Template engine uses DatabaseInputAdapter.
Repositories fetch facts from existing views.
Rules and mapping move to Java.
Output is compared against stored procedure.
```

### Phase 2: Dual source

```text
Same template engine accepts DATABASE or JSON source mode.
For each template, run DB source and JSON source through same Java steps.
Validate both produce same TemplateData.
```

### Phase 3: JSON primary

```text
Upstream systems send canonical source facts.
DB source remains only for fallback, reconciliation, or old batch.
```

### Phase 4: DB retired

```text
Remove repository source providers.
Keep canonical model, common steps, rules, mappers, validators, and audit.
```

## Stored Procedure To Java Split

| Stored procedure concern | Future owner |
| --- | --- |
| Joins and raw data fetch | Repository / DatabaseInputAdapter |
| JSON payload ingestion | JsonInputAdapter |
| Common address logic | AddressFormatter |
| Buyer/co-buyer logic | RecipientAssembler |
| Duplicate prior form check | Rule using `PriorFormFacts` |
| Bankruptcy/fraud reject reason | Rule catalog |
| Pending/create PDF decision | DispositionResolver |
| Output field names | TemplateFieldMapper |
| Required fields | Validator |
| Traceability | AuditService |

## Key Design Decision

The central object should be this:

```text
TemplateSourceFacts
```

Not a database row. Not a procedure-specific DTO. Not a JSON map.

Everything should be mapped into `TemplateSourceFacts`, then all logic should run from that canonical object.

That is what allows both capabilities:

- database-backed migration today
- JSON-driven template data assembly tomorrow

## Example Flow For Form 8722

```text
DATABASE mode:
  Form8722Repository -> TemplateSourceFacts -> common steps -> 8722 rules -> output

JSON mode:
  Request.sourceFacts -> TemplateSourceFacts -> common steps -> 8722 rules -> output
```

The common and template-specific logic is reused in both modes.

## Recommendation

Build the framework around this boundary:

```text
Source Adapter -> Canonical Facts -> Template Engine -> Template Data
```

Do not build it around:

```text
Database Query -> Template Class
```

The first design lets you retire the database. The second design keeps the database dependency alive inside Java.
