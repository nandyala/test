# Codex Milestone Plan: Procedure Evaluation Batch Framework

## Objective

Implement a Spring Batch based Procedure Evaluation Framework that replaces legacy stored procedure logic with configurable, reusable Java logic blocks.

The framework must:

* Receive all required input data points from REST API
* Execute procedure-specific logic using reusable Java blocks
* Support conditional block and group execution
* Externalize hardcoded values into YAML
* Write final evaluation output to a database table
* Capture traceability and observability for every block
* Support migration of 58 procedures

---

# Milestone 1: Project Skeleton and Package Structure

## Goal

Create the base Spring Boot project structure.

## Tasks

* Create Spring Boot project.
* Add dependencies:

    * Spring Batch
    * Spring Web
    * Spring Validation
    * Spring JDBC or Spring Data JPA
    * Jackson
    * Lombok
    * Micrometer
    * JUnit 5
    * Mockito
* Create package structure:

```text
com.company.procedureevaluation
  batch
  client
  core
  config
  block
  audit
  repository
  model
  exception
```

## Acceptance Criteria

* Application starts successfully.
* Empty Spring Batch job configuration compiles.
* Unit test framework is available.

---

# Milestone 2: Core Evaluation Models

## Goal

Create core request, context, result, and flow models.

## Tasks

Implement:

```text
ProcedureRequest
EvaluationContext
EvaluationResult
ProcedureDefinition
FlowStep
Condition
```

`EvaluationContext` should contain:

```text
batchId
requestId
procedureCode
input
constants
metadata
```

`EvaluationResult` should contain:

```text
requestId
procedureCode
output
warnings
errors
status
```

## Acceptance Criteria

* Models support dynamic input/output using maps.
* Constants can be attached per procedure.
* Unit tests cover getters, builder behavior, and helper methods.

---

# Milestone 3: YAML Procedure Configuration

## Goal

Support procedure-specific configuration through YAML.

## Example YAML

```yaml
procedures:
  PROC_001:
    constants:
      defaultLanguage: EN
      allowedStates:
        - TX
        - CA
        - NY
      renewalTypes:
        - ANNUAL
        - SEMI_ANNUAL

    flow:
      - block: defaultValueBlock

      - block: stateSpecificBlock
        when:
          field: stateCode
          inConstant: allowedStates

      - group: renewalFlow
        when:
          field: transactionType
          inConstant: renewalTypes
        steps:
          - block: renewalEligibilityBlock
          - block: renewalDateCalculationBlock
          - block: renewalOutputMappingBlock

      - group: rejectedFlow
        when:
          resultField: eligibilityStatus
          equals: REJECTED
        steps:
          - block: rejectionReasonBlock
          - block: rejectedOutputMappingBlock
```

## Tasks

* Create `ProcedureConfigProperties`.
* Bind YAML to Java objects.
* Add validation for:

    * missing procedure code
    * missing flow
    * unknown constants
    * duplicate block names if applicable

## Acceptance Criteria

* YAML config loads successfully.
* Config can return definition by procedure code.
* Missing procedure code throws a clear exception.

---

# Milestone 4: LogicBlock Contract and Registry

## Goal

Create reusable business logic block abstraction.

## Tasks

Create:

```java
public interface LogicBlock {
    String name();
    void evaluate(EvaluationContext context, EvaluationResult result);
}
```

Implement `LogicBlockRegistry` that:

* Loads all Spring beans implementing `LogicBlock`
* Maps block name to implementation
* Throws clear error when configured block is missing

## Acceptance Criteria

* Blocks are discoverable by name.
* Missing block produces meaningful exception.
* Unit tests verify registry behavior.

---

# Milestone 5: Condition Evaluator

## Goal

Support conditional execution for blocks and groups.

## Supported Conditions

```text
field equals value
field in list
field in configured constant list
resultField equals value
resultField in list
resultField in configured constant list
```

## Tasks

Implement `ConditionEvaluator`.

It should evaluate:

```yaml
when:
  field: stateCode
  equals: TX
```

```yaml
when:
  field: stateCode
  inConstant: allowedStates
```

```yaml
when:
  resultField: eligibilityStatus
  equals: REJECTED
```

## Acceptance Criteria

* Null condition returns true.
* Input-field conditions work.
* Result-field conditions work.
* Constants-based conditions work.
* Invalid condition fails with clear error.

---

# Milestone 6: Flow Executor

## Goal

Execute configured blocks and groups in order.

## Tasks

Implement `ProcedureFlowExecutor`.

Responsibilities:

* Iterate through configured flow steps
* Evaluate `when` condition before block or group
* Execute block if condition is true
* Skip block/group if condition is false
* Recursively execute group steps
* Record skipped blocks/groups in trace

## Acceptance Criteria

* Single block execution works.
* Block-level skip works.
* Group-level skip works.
* Nested group execution works if needed.
* Skipped block produces trace event with status `SKIPPED`.

---

# Milestone 7: Procedure Evaluator

## Goal

Create the central engine.

## Tasks

Implement `ProcedureEvaluator`.

Responsibilities:

* Receive `EvaluationContext`
* Resolve `ProcedureDefinition`
* Attach constants to context
* Initialize `EvaluationResult`
* Execute configured flow through `ProcedureFlowExecutor`
* Return final result

## Acceptance Criteria

* Evaluator executes configured flow end-to-end.
* Constants are available inside blocks.
* Output map is populated.
* Errors are propagated or recorded consistently.

---

# Milestone 8: Common Logic Blocks

## Goal

Create reusable blocks that can be used across procedures.

## Initial Blocks

Implement:

```text
defaultValueBlock
validationBlock
stateEligibilityBlock
productEligibilityBlock
dateCalculationBlock
outputMappingBlock
```

## Acceptance Criteria

* Each block has unit tests.
* Each block uses `EvaluationContext` and `EvaluationResult`.
* Hardcoded values come from constants where applicable.
* Blocks do not call database directly.

---

# Milestone 9: Procedure-Specific Sample Flow

## Goal

Implement one sample migrated procedure.

## Tasks

Create:

```text
proc001CaseLogicBlock
proc001OutputMappingBlock
```

Add YAML config for `PROC_001`.

Sample behavior:

* Apply defaults
* Validate required fields
* Check allowed state
* Run renewal flow only for configured renewal transaction types
* Produce final output payload

## Acceptance Criteria

* `PROC_001` evaluates successfully with valid input.
* Blocks are skipped when conditions are not met.
* Output payload matches expected test data.
* Trace includes executed and skipped blocks.

---

# Milestone 10: REST Data Client

## Goal

Fetch procedure input data points from REST API.

## Tasks

Implement `InputDataApiClient`.

Responsibilities:

* Call external REST endpoint using request ID and procedure code
* Return input data as `Map<String, Object>`
* Handle timeout, retry, and error response
* Log request ID and procedure code

## Acceptance Criteria

* Client supports mock integration test.
* Error responses are handled cleanly.
* Processor can consume returned data map.

---

# Milestone 11: Spring Batch Reader, Processor, Writer

## Goal

Implement batch execution flow.

## Tasks

Create:

```text
ProcedureItemReader
ProcedureItemProcessor
EvaluationResultWriter
ProcedureBatchJobConfig
```

Processor flow:

```text
ProcedureRequest
  ↓
REST API call
  ↓
EvaluationContext
  ↓
ProcedureEvaluator
  ↓
EvaluationResult
```

Writer flow:

```text
EvaluationResult
  ↓
EVALUATION_OUTPUT table
```

## Acceptance Criteria

* Batch job processes sample records.
* Chunk processing works.
* Failed records are handled according to configured policy.
* Final output is persisted.

---

# Milestone 12: Output Persistence

## Goal

Persist final evaluation result.

## Tasks

Create table/entity:

```text
EVALUATION_OUTPUT
- id
- batch_id
- request_id
- procedure_code
- output_payload_json
- status
- created_at
```

Implement:

```text
EvaluationOutputEntity
EvaluationOutputRepository
```

## Acceptance Criteria

* Output payload is stored as JSON.
* Status is stored.
* Request ID and procedure code are searchable.

---

# Milestone 13: Trace and Audit Persistence

## Goal

Capture block-level traceability.

## Tasks

Create table/entity:

```text
EVALUATION_TRACE
- id
- batch_id
- request_id
- procedure_code
- block_name
- status
- duration_ms
- skip_reason
- error_message
- created_at
```

Implement:

```text
TraceEvent
TraceService
TraceRepository
```

Trace statuses:

```text
SUCCESS
FAILED
SKIPPED
```

## Acceptance Criteria

* Every executed block has trace row.
* Every skipped block or group has trace row.
* Failed block captures error message.
* Trace includes duration.

---

# Milestone 14: Observability and Logging

## Goal

Make execution production-supportable.

## Tasks

Add structured logs for:

```text
batchId
jobExecutionId
stepExecutionId
requestId
procedureCode
blockName
status
durationMs
```

Add Micrometer metrics:

```text
procedure.evaluation.count
procedure.evaluation.failure.count
procedure.block.duration
procedure.block.skipped.count
```

## Acceptance Criteria

* Logs are searchable by request ID.
* Metrics are emitted for procedure and block execution.
* Failures include procedure code and block name.

---

# Milestone 15: Error Handling Strategy

## Goal

Standardize failure behavior.

## Tasks

Create exceptions:

```text
MissingProcedureConfigException
MissingLogicBlockException
InvalidConditionException
InputDataApiException
EvaluationException
```

Define behavior:

* Missing config: fail item
* Missing block: fail item
* REST API failure: retry according to batch policy
* Validation failure: configurable as failed or warning
* Business rule failure: record in result errors

## Acceptance Criteria

* Exceptions are meaningful.
* Batch retry/skip policies are configured.
* Failed item writes trace where possible.

---

# Milestone 16: Testing Framework

## Goal

Enable safe migration of 58 procedures.

## Tasks

Create test layers:

```text
Unit tests for each LogicBlock
Unit tests for ConditionEvaluator
Unit tests for FlowExecutor
Unit tests for ProcedureEvaluator
Integration test for batch job
Regression test harness for legacy vs Java output comparison
```

## Acceptance Criteria

* Sample procedure has full test coverage.
* Condition skip behavior is tested.
* Group skip behavior is tested.
* Regression comparison produces clear mismatch report.

---

# Milestone 17: Migration Guide

## Goal

Document how to migrate each stored procedure.

## Tasks

Create `STORED_PROCEDURE_MIGRATION_GUIDE.md`.

Include steps:

```text
1. Identify all input data points
2. Identify all hardcoded values
3. Move hardcoded values to YAML constants
4. Classify logic into reusable blocks
5. Identify procedure-specific blocks
6. Define flow order
7. Define block/group conditions
8. Implement Java blocks
9. Write unit tests
10. Compare output with legacy procedure
11. Sign off migrated procedure
```

## Acceptance Criteria

* Guide is committed.
* Guide includes sample before/after mapping.
* Guide includes standards for block naming and YAML naming.

---

# Milestone 18: Developer Documentation

## Goal

Make the framework understandable for future teams.

## Tasks

Create:

```text
README.md
ARCHITECTURE.md
CONFIGURATION_GUIDE.md
OBSERVABILITY_GUIDE.md
```

Include:

* Architecture diagram
* Package structure
* YAML examples
* Block examples
* Conditional execution examples
* Trace examples

## Acceptance Criteria

* New developer can understand framework flow.
* Docs explain how to add a new procedure.
* Docs explain how to add a reusable block.

---

# Milestone 19: Production Readiness

## Goal

Prepare for real batch execution.

## Tasks

Review:

* Retry policy
* Skip policy
* Database transaction boundaries
* REST timeout configuration
* Batch restartability
* Idempotency
* Duplicate request handling
* Output table indexing
* Trace table retention
* Sensitive data masking

## Acceptance Criteria

* Batch is restartable.
* Duplicate request handling is defined.
* Sensitive fields are not logged.
* Tables have required indexes.
* Trace volume strategy is documented.

---

# Milestone 20: First Procedure Migration

## Goal

Migrate first real legacy procedure using the framework.

## Tasks

* Select one representative stored procedure.
* Extract input data points.
* Extract constants.
* Create YAML config.
* Implement common and procedure-specific blocks.
* Run regression comparison.
* Review trace output with support team.
* Finalize migration pattern.

## Acceptance Criteria

* First real procedure runs end-to-end.
* Java output matches stored procedure output.
* Differences are documented and approved.
* Pattern is approved for remaining 57 procedures.

---

# Suggested Codex Execution Order

Run Codex in small PR-sized tasks:

```text
PR 1: Project skeleton and core models
PR 2: YAML configuration binding
PR 3: LogicBlock registry
PR 4: ConditionEvaluator
PR 5: FlowExecutor
PR 6: ProcedureEvaluator
PR 7: Common sample blocks
PR 8: Sample PROC_001 YAML and blocks
PR 9: Spring Batch reader/processor/writer
PR 10: Output persistence
PR 11: Trace persistence
PR 12: Observability and metrics
PR 13: Error handling
PR 14: Test harness
PR 15: Documentation
```

---

# Codex Working Instructions

For every PR:

* Keep changes small and reviewable.
* Add or update tests.
* Do not introduce business logic in batch reader, processor, or writer.
* Do not hardcode procedure constants in Java.
* Use YAML constants for fixed values.
* Make every logic block independently testable.
* Add trace events for executed, skipped, and failed blocks.
* Do not create one Java class per stored procedure.
* Prefer reusable common blocks.
* Use procedure-specific blocks only for unique logic.
* Keep output payload flexible as JSON.
* Do not log sensitive input values directly.
* Update documentation when behavior changes.

---

# Definition of Done

The milestone is complete when:

* Framework can process a batch item end-to-end
* REST input data is evaluated through configurable logic blocks
* Conditional blocks and groups work
* Constants are read from YAML
* Output is written to final table
* Trace rows are written for executed and skipped blocks
* Logs and metrics include request ID, procedure code, and block name
* Sample procedure has tests
* Documentation explains how to add the next procedure
