# FORM 9012 Procedure Split

Source: `procedures/one.sql`  
Procedure: `forms_db.alc_form9012_hist`

Use this split to migrate and debug the procedure section by section. The `PROC-9012-S*` marker should appear in code comments and logs.

| Marker | Procedure section | Original SQL responsibility | Java component |
| --- | --- | --- | --- |
| `PROC-9012-S1` | Run cleanup | Delete existing rows from `forms_db.alc_form9012_hist_nppi` for run date | Future batch writer step: `form9012.deleteExistingRunRows` |
| `PROC-9012-S2` | Date window | Resolve `pBUSDT`, `pMINDT`, `pMAXDT` from `forms_views.form_calendar` | `ResolveForm9012DateWindowStep` |
| `PROC-9012-S3` | Source load | Fetch raw account/event/customer/vehicle/reason/orh/daily form facts | `LoadForm9012CandidatesStep` / repository |
| `PROC-9012-S4` | Buyer/co-buyer split | Generate `is_cobuyer = 0/1` rows and choose buyer vs co-buyer fields | `AssembleForm9012CandidatesStep`, `Form9012CandidateAssembler` |
| `PROC-9012-S5` | Address derivation | Combine address lines, uppercase state, detect same address, location code | `Form9012CandidateAssembler` |
| `PROC-9012-S6` | Eligibility | Required buyer fields and duplicate daily form suppression | `ApplyForm9012EligibilityStep` |
| `PROC-9012-S7` | Output mapping | Populate final macro/view field names, constants, barcode, ZIP+4, CSZ | `PopulateForm9012RowsStep`, `Form9012Mapper` |
| `PROC-9012-S8` | Validation | Ensure required output fields are present | `ValidateForm9012RowsStep` |
| `PROC-9012-S9` | Macro/view replacement | Return all rows or account-filtered rows | API response / service query |

## Logging Standard

Each migrated section should log:

- `requestId`
- `templateCode`
- marker, for example `PROC-9012-S4`
- important input keys, such as run date or account number
- counts, such as source records, candidates, eligible rows, rejected rows
- major rule results and failure reasons

Example:

```text
PROC-9012-S6 requestId=REQ-123 candidates=10 eligible=8 rejected=2
PROC-9012-S6 rejected account=1234567890 isCobuyer=1 reason=Duplicate daily form exists
```

## Debugging Flow

1. Check `PROC-9012-S2` to confirm the date window matches the stored procedure.
2. Check `PROC-9012-S3` source record count against the SQL source query.
3. Check `PROC-9012-S4` candidate count. It should usually be source record count times two before co-buyer filtering.
4. Check `PROC-9012-S6` rejected count and rule results.
5. Check `PROC-9012-S7` output row count and final field values.
6. Check `PROC-9012-S8` validation failures for missing required fields.

## Design Note

When JSON replaces database input, steps `PROC-9012-S3` changes from database repository source loading to JSON source loading. Steps `PROC-9012-S4` through `PROC-9012-S8` should stay the same.
