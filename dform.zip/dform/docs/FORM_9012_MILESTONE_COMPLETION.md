# FORM 9012 Migration Milestone

## Status

FORM_9012 migration is functionally implemented in the Java Spring Batch framework.

The local test path runs with `sourceMode=DEMO` because the enterprise Teradata views and tables from `procedures/one.sql` are not available in the local H2 database. The production database path is implemented behind `Form9012SourceRecordRepository` and must be validated in an environment that has access to the real schemas.

## Completed

- Common Spring Boot entry point imports `batch/all-jobs.xml`.
- `batch/all-jobs.xml` imports FORM_9012 job XML and is ready to import more form jobs.
- FORM_9012 job has its own XML job id: `form9012TemplateDataJob`.
- Job resolution is generalized through `TemplateJobResolver`.
- FORM_9012 reader is XML-wired and source-mode driven.
- FORM_9012 SQL is externalized under `src/main/resources/sql/form9012`.
- FORM_9012 source repository loads SQL resources and maps results:
  - `pBUSDT` date resolution from `forms_views.form_calendar`.
  - `pMINDT` and `pMAXDT` date-window resolution.
  - Event source joins.
  - Buyer/co-buyer source joins.
  - Vehicle source join.
  - ORH/location join.
  - Reason and form-description joins.
  - Event process and reason filters.
  - Active RL account filter.
  - ORH zone filter.
  - Recent daily-form duplicate suppression.
  - Latest event selection.
- Java processor implements:
  - Duplicate prior-form filter guard.
  - Buyer row assembly.
  - Co-buyer row assembly.
  - Co-buyer skip reason logging.
  - Same-address comparison logging.
- Java mapper implements final output fields:
  - `run_date`
  - `bus_date`
  - `acct_nmbr`
  - buyer/co-buyer recipient fields
  - `cobuyer_has_buyer_address`
  - `event_proc_cd`
  - `event_reas_cd`
  - `reas_desc`
  - `form_desc`
  - form metadata/default fields
  - `barcode`
  - `vin`
  - `loctn_cd`
- Validation uses required fields from `forms/forms.yml`.
- Writer persists final rows to `LetterChannelResult`.
- Writer persists every resolved field to `LetterTemplateResolvedValue`.
- Audit fields include job execution id, step execution id, template code, account number, row sequence, co-buyer flag, source mode, payload hash, legacy procedure, legacy section, and timestamps.
- Procedure conversion logs include legacy procedure and legacy section names.
- Local integration test verifies:
  - Batch job completes.
  - One source account is read.
  - One processed item is written.
  - Two final channel rows are persisted.
  - Seventy-two resolved field audit rows are persisted.

## Database Dependency Boundary

The remaining direct database dependency is isolated to these SQL resource files:

- `src/main/resources/sql/form9012/resolve-business-date.sql`
- `src/main/resources/sql/form9012/resolve-event-date-window.sql`
- `src/main/resources/sql/form9012/find-source-records.sql`

When the source moves from database to JSON/API input, these SQL files and the repository reader path can be retired without changing mapper, validation, writer, audit table, or job tracking logic.

## Validation Still Required In Higher Environment

The following must be verified against real Teradata schemas because they cannot be proven locally:

- SQL syntax compatibility of the translated repository query.
- Calendar/date-window values for `pBUSDT`, `pMINDT`, and `pMAXDT`.
- Row counts from Java source query vs stored procedure.
- Field-by-field comparison of `LetterChannelResult.output_payload` vs legacy macro output.
- Duplicate suppression behavior against `forms_views.daily_forms`.
- Latest-event behavior matching the stored procedure `QUALIFY` clause.

## How To Add Another Form

1. Add form metadata to `forms/forms.yml`.
2. Add a job XML file under `batch/jobs`.
3. Give the job id this pattern: `form<NUMBER>TemplateDataJob`.
4. Import the job XML from `batch/all-jobs.xml`.
5. Add or reuse a source repository/reader.
6. Add procedure mapping comments and `PROC-CONVERSION-*` logs.
7. Add stored procedure vs Java comparison tests.
