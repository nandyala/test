# FORM 9012 Stored Procedure Inventory

Source procedure: `procedures/one.sql`  
Procedure name: `forms_db.alc_form9012_hist`  
Template code: `FORM_9012`  
Legacy form number: `9012`

## Purpose

This procedure prepares template data rows for form `9012`. It does not generate the letter document. It fetches eligible accounts/events, resolves buyer or co-buyer recipient data, formats address fields, assigns form delivery defaults, and stores final rows in `forms_db.alc_form9012_hist_nppi`.

## Migration Principle

Do not translate this stored procedure line by line.

Use SQL only to fetch raw source facts from tables and views. Move procedural logic into Java:

- date-window orchestration
- buyer/co-buyer branching
- address formatting
- postal-code formatting
- same-address detection
- duplicate-form rule
- eligibility checks
- default output values
- barcode generation
- final DTO assembly
- validation and audit

## Inputs

| Input | Type | Source | Description |
| --- | --- | --- | --- |
| `pRUNDT` | `DATE` | procedure parameter | Batch run date |

## Internal Dates

| Variable | Source | Current SQL | Java target |
| --- | --- | --- | --- |
| `pBUSDT` | `forms_views.form_calendar.prior_business_day` | Lookup by `cal_date = pRUNDT` | `ResolveForm9012DateWindowStep` |
| `pMINDT` | `forms_views.form_calendar.min(cal_date)` | Where `us_forms_data_dt = pBUSDT` | `ResolveForm9012DateWindowStep` |
| `pMAXDT` | `forms_views.form_calendar.max(cal_date)` | Where `us_forms_data_dt = pBUSDT` | `ResolveForm9012DateWindowStep` |

## Side Effects

| Side effect | Current SQL | Migration target |
| --- | --- | --- |
| Delete existing rows | Delete from `forms_db.alc_form9012_hist_nppi` for `run_date = pRUNDT` and `bus_date is not null` | Batch writer/persistence step |
| Insert final rows | Insert into `forms_db.alc_form9012_hist_nppi` | Java writer or API response, depending on channel |

## Data Sources

| Source | Alias | Join type | Purpose |
| --- | --- | --- | --- |
| `SPOT_BVAL.faw_event` | `faw_ev` | driving table | Event account, process code, reason code, update date |
| `forms_db.faw_reas_descform9012` | `faw_re9012` | left join | Form-specific reason description |
| `forms_views.pfolio_acct_hist` | `pah` | inner join | Active RL account and related customer references |
| `forms_views.acct_cust_nppi` | `ctrct_buyr` | inner join | Buyer name and address |
| `sys_calendar.calendar` | `ic` | inner join / row generator | Produces `is_cobuyer = 0` and `1` |
| `forms_views.pfolio_acct_vhcl_hist` | `pavh` | inner join | Vehicle VIN |
| `forms_views.acct_cust_nppi` | `ctrct_cobuyr` | left join | Co-buyer name and address |
| `forms_views.orh` | `orh` | left join | Area, region, zone for location code |
| `SPOT_BVAL.faw_reas` | `faw_reas` | left join | General reason description |
| `forms_views.daily_forms` | `df` | `NOT EXISTS` | Suppress duplicate recent successful pending form |

## Source Filters

| Filter | Current SQL | Java target |
| --- | --- | --- |
| Event reason allowed list | `Event_Reas_Cd in ('89,010' ... '89,090')` | Repository source query or config constant |
| Event process code | `Event_Proc_Cd = '48,000'` | Repository source query or config constant |
| Event date window | `Event_last_updated between pMINDT and pMAXDT` | Repository source query |
| Account effective date | `pBUSDT between pfolio_acct_hist_strt_dt and pfolio_acct_hist_end_dt` | Repository source query |
| Account status | `ctrct_stat_hist_name = 'ACTIVE'` | Repository source query |
| LOB | `lob_cd = 'RL'` | Repository source query or config constant |
| Buyer relationship | `relshp_typ_cd = '1'` | Repository source query |
| Vehicle effective date | `pBUSDT between vehicle history start/end` | Repository source query |
| ORH zone range | `zone_nmbr between '200' and '323' and <> '318'` | Repository source query or Java rule if business-owned |
| Latest event row | `QUALIFY ROW_NUMBER() ... = 1` | Repository source query |
| Required buyer fields | `buyr_* is not null` | Java validation / eligibility step |
| Duplicate daily form | `NOT EXISTS daily_forms ...` | Java rule using repository-fetched duplicate flag |

## Logical Sections

| Section | Stored procedure lines/concept | Java step |
| --- | --- | --- |
| Cleanup old run | `DELETE FROM forms_db.alc_form9012_hist_nppi` | `form9012.deleteExistingRunRows` or batch writer setup |
| Resolve date window | `pBUSDT`, `pMINDT`, `pMAXDT` queries | `form9012.resolveDateWindow` |
| Load source facts | Main joins from event/account/customer/vehicle/reason/orh/daily forms | `form9012.loadSourceRecords` |
| Split buyer/co-buyer rows | `sys_calendar.calendar` generated `is_cobuyer` rows | `form9012.assembleCandidates` |
| Choose recipient fields | SQL `CASE when ic.is_cobuyer = 0 then buyer else cobuyer` | `Form9012CandidateAssembler` |
| Format address | SQL `CASE` for address line 1 + optional line 2 | `Form9012CandidateAssembler` |
| Format postal code | 9-digit ZIP converted to `12345-6789` | `Form9012Mapper` or shared `PostalCodeFormatter` |
| Detect same address | SQL comparison across buyer/co-buyer address fields | `Form9012CandidateAssembler` |
| Apply eligibility | Required fields and duplicate daily form rule | `form9012.applyEligibility` |
| Populate defaults | `create_pdf`, `form_number`, `lob_cd`, `mail_type`, etc. | `form9012.populateRows` |
| Validate output | Final not-null fields | `form9012.validateRows` |
| Persist / return rows | Insert table + macro/view | writer step or API response rows |

## Output Fields

| Output field | Current derivation | Java target |
| --- | --- | --- |
| `run_date` | `pRUNDT` | Date window context |
| `bus_date` | `pBUSDT` | Date window context |
| `acct_nmbr` | `faw_ev.acct_nmbr` | Source record |
| `buyr_full_name` | Buyer/co-buyer conditional | Candidate assembler |
| `buyr_addr_line_1` | Buyer/co-buyer conditional + optional line 2 | Candidate assembler |
| `buyr_city_name` | Buyer/co-buyer conditional | Candidate assembler |
| `buyr_state_cd` | Buyer/co-buyer conditional + uppercase | Candidate assembler |
| `buyr_postl_cd` | Buyer/co-buyer conditional + ZIP formatting | Mapper/shared formatter |
| `buyr_csz` | City + state + postal | Mapper |
| `cobuyr_full_name` | Co-buyer name only on buyer row | Candidate assembler |
| `cobuyr_addr_line_1` | Empty string | Mapper/defaults |
| `cobuyr_city_name` | Empty string | Mapper/defaults |
| `cobuyr_state_cd` | Empty string | Mapper/defaults |
| `cobuyr_postl_cd` | Empty string | Mapper/defaults |
| `cobuyr_csz` | Empty string | Mapper/defaults |
| `cobuyer_has_buyer_address` | Address comparison | Candidate assembler |
| `event_proc_cd` | `faw_ev.Event_Proc_Cd` | Source record |
| `event_reas_cd` | `faw_ev.Event_Reas_Cd` | Source record |
| `reas_desc` | `faw_reas.reas_desc` | Source record |
| `form_desc` | `faw_re9012.reas_desc` | Source record |
| `create_pdf` | Constant `1` | Mapper/defaults |
| `form_number` | Constant `9012` | Mapper/defaults |
| `paper_size` | `null` | Mapper/defaults |
| `lob_cd` | Constant `RL` | Mapper/defaults |
| `mail_type` | Constant `R` | Mapper/defaults |
| `send_to` | Constant `B` | Mapper/defaults |
| `barcode` | Account number + timestamp | Mapper/barcode service |
| `is_cobuyer` | Generated `0` or `1` | Candidate assembler |
| `is_pending` | Constant `0` | Mapper/defaults |
| `pending_group` | `null` | Mapper/defaults |
| `days_in_pending` | Constant `0` | Mapper/defaults |
| `num_sides` | Constant `1` | Mapper/defaults |
| `vin` | `trim(pavh.vin)` | Candidate assembler |
| `loctn_cd` | `'0' || area || region || zone` | Candidate assembler |

## Legacy Macros / View

| Object | Purpose | Java/API replacement |
| --- | --- | --- |
| `forms_db.alc_form9012(prundt)` | Return all rows for run date | `POST /template-data/generate` with `templateCode = FORM_9012` and run date |
| `forms_db.alc_form9012_acct_nmbr(prundt, pacct_nmbr)` | Return rows for run date + account | API filter or service method by account |
| `forms_views.alc_form9012_hist_nppi` | Read view over history table | Repository/read model or compatibility DB view |

## Proposed Java Pipeline

```yaml
FORM_9012:
  steps:
    - form9012.resolveDateWindow
    - form9012.loadSourceRecords
    - form9012.assembleCandidates
    - form9012.applyEligibility
    - form9012.populateRows
    - form9012.validateRows
    - form9012.persistRows
```

`persistRows` can be omitted for API-only usage and included for batch/history-table compatibility.

## Open Questions

1. Should Java continue writing to `forms_db.alc_form9012_hist_nppi` for compatibility, or should it return JSON only and let a downstream writer persist?
2. Should event reason code list remain hard-coded, move to YAML, or be loaded from a form metadata table?
3. Should barcode generation use current timestamp exactly like SQL, or a job/request timestamp for deterministic reruns?
4. Should duplicate daily form check remain a source-query flag or become a separate repository call/rule step?
5. Should the `sys_calendar.calendar` two-row co-buyer generator be replaced by fixed Java generation of buyer row and co-buyer row?
