# FORM 9012 Field Database Mapping

Source procedure: `procedures/one.sql`  
Procedure: `forms_db.alc_form9012_hist`  
Target table: `forms_db.alc_form9012_hist_nppi`  
Template/Form number: `9012`

| Output field | Database source / expression | Source alias | Source table / view | Mapping notes |
| --- | --- | --- | --- | --- |
| `run_date` | `:pRUNDT` | parameter | procedure input | Run date passed to procedure |
| `bus_date` | `prior_business_day` where `cal_date = :pRUNDT` | calendar | `forms_views.form_calendar` | Stored in `pBUSDT` |
| `acct_nmbr` | `acct_nmbr` | `faw_ev` | `SPOT_BVAL.faw_event` | Event account number |
| `buyr_full_name` | `case when ic.is_cobuyer = 0 then trim(ctrct_buyr.full_name) else trim(ctrct_cobuyr.full_name) end` | `ctrct_buyr`, `ctrct_cobuyr`, `ic` | `forms_views.acct_cust_nppi` | Buyer/co-buyer recipient selection |
| `buyr_addr_line_1` | Buyer or co-buyer `addr_line_1`, plus `addr_line_2` when present | `ctrct_buyr`, `ctrct_cobuyr`, `ic` | `forms_views.acct_cust_nppi` | Concatenates line 1 and line 2 with comma |
| `buyr_city_name` | `case when ic.is_cobuyer = 0 then trim(ctrct_buyr.city_name) else trim(ctrct_cobuyr.city_name) end` | `ctrct_buyr`, `ctrct_cobuyr`, `ic` | `forms_views.acct_cust_nppi` | Recipient city |
| `buyr_state_cd` | `case when ic.is_cobuyer = 0 then trim(upper(ctrct_buyr.state_cd)) else trim(upper(ctrct_cobuyr.state_cd)) end` | `ctrct_buyr`, `ctrct_cobuyr`, `ic` | `forms_views.acct_cust_nppi` | Recipient state uppercased |
| `buyr_postl_cd` | Buyer or co-buyer `postl_cd`; if 9 digits and no hyphen, format as `12345-6789` | `ctrct_buyr`, `ctrct_cobuyr`, `ic` | `forms_views.acct_cust_nppi` | ZIP+4 formatting logic |
| `buyr_csz` | `buyr_city_name || ', ' || buyr_state_cd || ' ' || buyr_postl_cd` | derived | derived from output fields | City/state/ZIP display value |
| `cobuyr_full_name` | `case when ic.is_cobuyer = 0 then trim(coalesce(ctrct_cobuyr.full_name, '')) else '' end` | `ctrct_cobuyr`, `ic` | `forms_views.acct_cust_nppi` | Only populated on buyer row |
| `cobuyr_addr_line_1` | `''` | constant | none | Always empty string |
| `cobuyr_city_name` | `''` | constant | none | Always empty string |
| `cobuyr_state_cd` | `''` | constant | none | Always empty string |
| `cobuyr_postl_cd` | `''` | constant | none | Always empty string |
| `cobuyr_csz` | `''` | constant | none | Always empty string |
| `cobuyer_has_buyer_address` | Compare buyer and co-buyer `addr_line_1`, `addr_line_2`, `city_name`, `state_cd`; if equal then `1` else `0` | `ctrct_buyr`, `ctrct_cobuyr` | `forms_views.acct_cust_nppi` | Same-address flag |
| `event_proc_cd` | `Event_Proc_Cd` | `faw_ev` | `SPOT_BVAL.faw_event` | Filtered to `'48,000'` |
| `event_reas_cd` | `Event_Reas_Cd` | `faw_ev` | `SPOT_BVAL.faw_event` | Filtered to allowed reason list |
| `reas_desc` | `reas_desc` | `faw_reas` | `SPOT_BVAL.faw_reas` | Joined by `Proc_Cd = '48,000'` and reason code |
| `form_desc` | `reas_desc` | `faw_re9012` | `forms_db.faw_reas_descform9012` | Form-specific reason description |
| `create_pdf` | `1` | constant | none | Always create PDF |
| `form_number` | `'9012'` | constant | none | Static form number |
| `paper_size` | `null` | constant | none | Always null in this procedure |
| `lob_cd` | `'RL'` | constant | none | Account join also filters `pah.lob_cd = 'RL'` |
| `mail_type` | `'R'` | constant | none | Regular mail |
| `first_class` | `1` | constant | none | Insert field only, not returned by macro/view |
| `certified` | `0` | constant | none | Insert field only, not returned by macro/view |
| `send_to` | `'B'` | constant | none | Send to buyer |
| `barcode` | `faw_ev.acct_nmbr || current_timestamp(format 'yyyymmddhhmi')` | `faw_ev` | `SPOT_BVAL.faw_event` | Account number plus timestamp |
| `is_cobuyer` | `row_number() over(order by calendar_date) - 1` | `ic` | `sys_calendar.calendar` | Generates two rows: `0` and `1` |
| `is_pending` | `0` | constant | none | Always not pending |
| `pending_group` | `null` | constant | none | Always null |
| `days_in_pending` | `0` | constant | none | Always zero |
| `num_sides` | `1` | constant | none | One-sided form |
| `vin` | `trim(vin)` | `pavh` | `forms_views.pfolio_acct_vhcl_hist` | Vehicle VIN |
| `loctn_cd` | `'0' || orh.area_nmbr || orh.reg_nmbr || orh.zone_nmbr` | `orh` | `forms_views.orh` | Location code |

## Procedure Variables / Lookup Fields

| Field / variable | Database source / expression | Source table / view | Usage |
| --- | --- | --- | --- |
| `pRUNDT` | Procedure input | none | Run date |
| `pBUSDT` | `prior_business_day` where `cal_date = :pRUNDT` | `forms_views.form_calendar` | Business date for effective-date joins |
| `pMINDT` | `min(cal_date)` where `us_forms_data_dt = :pBUSDT` | `forms_views.form_calendar` | Event date lower bound |
| `pMAXDT` | `max(cal_date)` where `us_forms_data_dt = :pBUSDT` | `forms_views.form_calendar` | Event date upper bound |

## Database Tables / Views Used

| Table / view | Alias | Fields used |
| --- | --- | --- |
| `forms_views.form_calendar` | none | `cal_date`, `prior_business_day`, `us_forms_data_dt` |
| `SPOT_BVAL.faw_event` | `faw_ev` | `acct_nmbr`, `Event_Proc_Cd`, `Event_Reas_Cd`, `Event_last_updated` |
| `forms_db.faw_reas_descform9012` | `faw_re9012` | `event_proc_Cd`, `event_reas_Cd`, `reas_desc` |
| `forms_views.pfolio_acct_hist` | `pah` | `acct_nmbr`, `pfolio_acct_hist_strt_dt`, `pfolio_acct_hist_end_dt`, `ctrct_stat_hist_name`, `lob_cd`, `cust_nmbr`, `cust_addr_nmbr`, `rlatd_cust_nmbr_1`, `rlatd_cust_addr_nmbr_1`, `rlatd_cust_relshp_typ_1`, `zone_nmbr` |
| `forms_views.acct_cust_nppi` | `ctrct_buyr` | `acct_nmbr`, `relshp_typ_cd`, `acct_cust_strt_dt`, `acct_cust_end_dt`, `cust_nmbr`, `addr_nmbr`, `full_name`, `addr_line_1`, `addr_line_2`, `city_name`, `state_cd`, `postl_cd` |
| `forms_views.acct_cust_nppi` | `ctrct_cobuyr` | `acct_nmbr`, `relshp_typ_cd`, `acct_cust_strt_dt`, `acct_cust_end_dt`, `cust_nmbr`, `addr_nmbr`, `full_name`, `addr_line_1`, `addr_line_2`, `city_name`, `state_cd`, `postl_cd` |
| `sys_calendar.calendar` | `ic` | `calendar_date` |
| `forms_views.pfolio_acct_vhcl_hist` | `pavh` | `acct_nmbr`, `pfolio_acct_vhcl_hist_strt_dt`, `pfolio_acct_vhcl_hist_end_dt`, `vin` |
| `forms_views.orh` | `orh` | `zone_nmbr`, `area_nmbr`, `reg_nmbr`, `orh_strt_dt`, `orh_end_dt` |
| `SPOT_BVAL.faw_reas` | `faw_reas` | `Proc_Cd`, `Reas_Cd`, `reas_desc` |
| `forms_views.daily_forms` | `df` | `AccountNum`, `FormNum`, `Status`, `WolverineStatus`, `ProcessedDate` |

## Filter Fields Used

| Field | Source | Filter |
| --- | --- | --- |
| `faw_ev.Event_Reas_Cd` | `SPOT_BVAL.faw_event` | In `89,010` through `89,090` allowed list |
| `faw_ev.Event_Proc_Cd` | `SPOT_BVAL.faw_event` | Equals `'48,000'` |
| `faw_ev.Event_last_updated` | `SPOT_BVAL.faw_event` | Between `pMINDT` and `pMAXDT` |
| `pah.ctrct_stat_hist_name` | `forms_views.pfolio_acct_hist` | Equals `'ACTIVE'` |
| `pah.lob_cd` | `forms_views.pfolio_acct_hist` | Equals `'RL'` |
| `ctrct_buyr.relshp_typ_cd` | `forms_views.acct_cust_nppi` | Equals `'1'` |
| `orh.zone_nmbr` | `forms_views.orh` | Between `'200'` and `'323'`, not `'318'` |
| `df.FormNum` | `forms_views.daily_forms` | Equals `'9012'` |
| `df.Status` | `forms_views.daily_forms` | Equals `'P'` |
| `df.WolverineStatus` | `forms_views.daily_forms` | Equals `'S'` |
| `df.ProcessedDate` | `forms_views.daily_forms` | Greater than or equal to `pRUNDT - 1` |
