# Stored Procedure Migration Guide

Use this guide once per stored procedure. The goal is not to translate SQL line by line. The goal is to convert buried procedure logic into small, named, traceable Java pipeline steps.

## Recommended Migration Flow

```text
Stored Procedure
   -> Logic Inventory
   -> Decision Tables / Rule Catalog
   -> Java Steps
   -> Validated Output Comparison
```

## Migration Sheet

Create one sheet per procedure.

| Area | Capture |
| --- | --- |
| Inputs | Procedure parameters, session values, run date, business date |
| Data sources | Tables, views, joins, effective-date filters |
| Derived fields | Calculated template values, formatting, defaults |
| Conditions | IF/ELSE, CASE, EXISTS, NOT EXISTS, QUALIFY, row_number filters |
| Side effects | Temp tables, history-table writes, updates, logs |
| Output | Final fields returned by macro/view/API |
| Dependencies | Other procedures, macros, functions, reference tables |

## Procedure Sectioning

Split the procedure into logical sections before coding:

1. Load base customer/policy/account data
2. Load related account, billing, vehicle, event, or form metadata data
3. Apply eligibility conditions
4. Derive template fields
5. Apply formatting/defaults
6. Apply reject, pending, and create-output decisions
7. Validate final required fields
8. Return or persist final template data

## Implementation Process

1. Identify procedure inputs.
2. List all tables and views used.
3. Extract temp table or staging-table logic.
4. Classify logic into data retrieval, rules, mappings, formatting, defaults, and exceptions.
5. Convert each logical section into a `DataStep`.
6. Add the step to `application.yml` under the template code.
7. Write unit tests for the step.
8. Run stored procedure vs Java output comparison.
9. Fix mismatches.
10. Repeat for the next procedure.

## Java Mapping Rules

- Keep SQL inside repository classes only.
- Keep business rules out of controllers.
- Keep steps small and named after procedure sections.
- Use shared steps for repeated logic like customer lookup, co-buyer handling, postal-code formatting, duplicate-form checks, and form metadata lookup.
- Add comments in each step showing which stored procedure section it replaces.
- Use audit events to record step status, duration, records fetched, fields populated, and errors.

## Output Comparison Pattern

For each migrated procedure, create a comparison test:

1. Run the old stored procedure for a fixed input.
2. Capture the old output rows.
3. Run the Java pipeline for the same input.
4. Compare field by field.
5. Report:
   - missing fields
   - extra fields
   - value mismatches
   - formatting mismatches
   - record-count mismatches

Keep comparison failures readable. A migration mismatch report should tell the developer exactly which field and account/template record differs.

## Example YAML

```yaml
template-data:
  templates:
    RENEWAL_LETTER:
      steps:
        - loadCustomer
        - loadPolicy
        - loadBilling
        - applyRenewalRules
        - populateRenewalFields
        - validateOutput
      required-fields:
        - customerFullName
        - customerAddressLine1
        - customerCityStateZip
        - policyId
        - renewalDate
        - amountDue
        - renewalMessage
```

## Stored Procedure Anti-Patterns To Avoid

- Do not create one Java class per 2000-line procedure.
- Do not translate every SQL `CASE` into a long method without naming the rule.
- Do not put SQL in rules, mappers, validators, or controllers.
- Do not hide rejects or skips by only returning empty output.
- Do not skip audit logging; traceability is the main reason for the migration.

## Suggested Step Names For Current Samples

For forms like `alc_form9012_hist` and `alc_form8722_hist`, likely reusable steps include:

- `resolveBusinessDate`
- `loadCandidateAccounts`
- `loadBuyerCobuyerData`
- `loadVehicleData`
- `loadFormMetadata`
- `checkDailyFormDuplicate`
- `applyEligibilityRules`
- `applyBusinessRejectRules`
- `applyDataRejectRules`
- `populateTemplateFields`
- `formatAddressFields`
- `decideDisposition`
- `validateOutput`
- `persistHistoryRows`

## FORM_9012 Migration Notes

`procedures/one.sql` has been migrated as the first concrete flow under template code `FORM_9012`.

| Stored procedure section | Java replacement |
| --- | --- |
| Resolve `pBUSDT`, `pMINDT`, `pMAXDT` from `form_calendar` | `form9012.resolveDateWindow` |
| Raw `FROM` / `JOIN` data retrieval | `form9012.loadSourceRecords` repository-backed step |
| SQL `CASE` expressions for buyer/co-buyer field selection | `form9012.assembleCandidates` |
| Address concatenation and same-address detection | `form9012.assembleCandidates` |
| Required buyer field checks | `form9012.applyEligibility` |
| `NOT EXISTS forms_views.daily_forms` duplicate check | `form9012.applyEligibility` |
| SELECT-list defaults and derived fields | `form9012.populateRows` |
| Macro/view style output fields | top-level `rows` list using old field names |
| Final not-null quality gate | `form9012.validateRows` |

The JDBC repository now keeps SQL focused on source data retrieval. Procedure logic like `CASE`, address formatting, buyer/co-buyer branching, duplicate flag interpretation, defaults, and output derivation is handled by Java steps.
