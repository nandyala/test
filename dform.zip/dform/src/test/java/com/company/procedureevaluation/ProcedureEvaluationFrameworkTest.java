package com.company.procedureevaluation;

import static org.assertj.core.api.Assertions.assertThat;

import com.company.procedureevaluation.client.InputDataApiClient;
import com.company.procedureevaluation.core.ProcedureEvaluator;
import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootTest
class ProcedureEvaluationFrameworkTest {

    @Autowired
    private ProcedureEvaluator procedureEvaluator;

    @Autowired
    private InputDataApiClient inputDataApiClient;

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job procedureEvaluationJob;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    @SuppressWarnings("unchecked")
    void evaluatesForm9012FromApiInput() {
        EvaluationContext context = new EvaluationContext(
                "batch-api-1",
                "request-api-1",
                "FORM_9012",
                inputDataApiClient.demoForm9012Input()
        );

        EvaluationResult result = procedureEvaluator.evaluate(context);

        assertThat(result.status()).isEqualTo("SUCCESS");
        assertThat(result.errors()).isEmpty();
        assertThat(result.output().get("eligible")).isEqualTo(true);
        List<Map<String, Object>> rows = (List<Map<String, Object>>) result.output().get("rows");
        assertThat(rows).hasSize(2);
        assertThat(rows.get(0)).containsEntry("form_number", "9012");
        assertThat(rows.get(0)).containsEntry("buyr_full_name", "Anita Rao");
        assertThat(rows.get(1)).containsEntry("buyr_full_name", "Ravi Rao");

        Integer traceRows = jdbcTemplate.queryForObject(
                "select count(*) from EVALUATION_TRACE where request_id = ?",
                Integer.class,
                "request-api-1");
        assertThat(traceRows).isEqualTo(5);
    }

    @Test
    void runsForm9012ThroughSpringBatchAndPersistsOutput() throws Exception {
        JobParameters parameters = new JobParametersBuilder()
                .addString("batchId", "batch-job-1")
                .addString("requestId", "request-job-1")
                .addString("procedureCode", "FORM_9012")
                .addLong("requestTimestamp", System.currentTimeMillis())
                .toJobParameters();

        JobExecution execution = jobLauncher.run(procedureEvaluationJob, parameters);

        assertThat(execution.getStatus()).isEqualTo(BatchStatus.COMPLETED);
        assertThat(execution.getStepExecutions()).singleElement().satisfies(step -> {
            assertThat(step.getReadCount()).isEqualTo(1);
            assertThat(step.getWriteCount()).isEqualTo(1);
        });

        Integer outputRows = jdbcTemplate.queryForObject(
                "select count(*) from EVALUATION_OUTPUT where request_id = ?",
                Integer.class,
                "request-job-1");
        Integer traceRows = jdbcTemplate.queryForObject(
                "select count(*) from EVALUATION_TRACE where request_id = ?",
                Integer.class,
                "request-job-1");

        assertThat(outputRows).isEqualTo(1);
        assertThat(traceRows).isEqualTo(5);
    }
}
