package com.company.procedureevaluation.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class EvaluationResult {

    private final String requestId;
    private final String procedureCode;
    private final Map<String, Object> output = new LinkedHashMap<>();
    private final List<String> warnings = new ArrayList<>();
    private final List<String> errors = new ArrayList<>();
    private String status = "SUCCESS";

    public EvaluationResult(String requestId, String procedureCode) {
        this.requestId = requestId;
        this.procedureCode = procedureCode;
    }

    public String requestId() {
        return requestId;
    }

    public String procedureCode() {
        return procedureCode;
    }

    public Map<String, Object> output() {
        return output;
    }

    public List<String> warnings() {
        return warnings;
    }

    public List<String> errors() {
        return errors;
    }

    public String status() {
        return status;
    }

    public void status(String status) {
        this.status = status;
    }

    public Object outputValue(String field) {
        return output.get(field);
    }
}
