package com.company.procedureevaluation.exception;

public class EvaluationException extends RuntimeException {
    public EvaluationException(String message, Throwable cause) {
        super(message, cause);
    }
}
