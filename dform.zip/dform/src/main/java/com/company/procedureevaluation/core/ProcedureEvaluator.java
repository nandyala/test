package com.company.procedureevaluation.core;

import com.company.procedureevaluation.config.ProcedureConfigProperties;
import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import com.company.procedureevaluation.model.ProcedureDefinition;

public class ProcedureEvaluator {

    private final ProcedureConfigProperties procedureConfigProperties;
    private final ProcedureFlowExecutor flowExecutor;

    public ProcedureEvaluator(ProcedureConfigProperties procedureConfigProperties, ProcedureFlowExecutor flowExecutor) {
        this.procedureConfigProperties = procedureConfigProperties;
        this.flowExecutor = flowExecutor;
    }

    public EvaluationResult evaluate(EvaluationContext context) {
        ProcedureDefinition definition = procedureConfigProperties.getRequired(context.procedureCode());
        context.constants().putAll(definition.getConstants());
        EvaluationResult result = new EvaluationResult(context.requestId(), context.procedureCode());
        flowExecutor.execute(definition.getFlow(), context, result);
        if (!result.errors().isEmpty()) {
            result.status("FAILED");
        }
        return result;
    }
}
