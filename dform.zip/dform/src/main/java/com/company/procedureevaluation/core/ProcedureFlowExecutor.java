package com.company.procedureevaluation.core;

import com.company.procedureevaluation.audit.TraceService;
import com.company.procedureevaluation.audit.TraceStatus;
import com.company.procedureevaluation.block.LogicBlock;
import com.company.procedureevaluation.block.LogicBlockRegistry;
import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import com.company.procedureevaluation.model.FlowStep;
import java.util.List;

public class ProcedureFlowExecutor {

    private final ConditionEvaluator conditionEvaluator;
    private final LogicBlockRegistry logicBlockRegistry;
    private final TraceService traceService;

    public ProcedureFlowExecutor(ConditionEvaluator conditionEvaluator, LogicBlockRegistry logicBlockRegistry, TraceService traceService) {
        this.conditionEvaluator = conditionEvaluator;
        this.logicBlockRegistry = logicBlockRegistry;
        this.traceService = traceService;
    }

    public void execute(List<FlowStep> steps, EvaluationContext context, EvaluationResult result) {
        for (FlowStep step : steps) {
            executeStep(step, context, result);
        }
    }

    private void executeStep(FlowStep step, EvaluationContext context, EvaluationResult result) {
        String name = step.getBlock() != null ? step.getBlock() : step.getGroup();
        long start = System.nanoTime();
        if (!conditionEvaluator.matches(step.getWhen(), context, result)) {
            traceService.record(context, name, TraceStatus.SKIPPED, elapsedMs(start), "condition evaluated false", null);
            return;
        }
        if (step.getGroup() != null) {
            traceService.record(context, step.getGroup(), TraceStatus.SUCCESS, elapsedMs(start), null, null);
            execute(step.getSteps(), context, result);
            return;
        }
        try {
            LogicBlock block = logicBlockRegistry.getRequired(step.getBlock());
            block.evaluate(context, result);
            traceService.record(context, block.name(), TraceStatus.SUCCESS, elapsedMs(start), null, null);
        } catch (RuntimeException ex) {
            traceService.record(context, name, TraceStatus.FAILED, elapsedMs(start), null, ex.getMessage());
            throw ex;
        }
    }

    private long elapsedMs(long start) {
        return (System.nanoTime() - start) / 1_000_000;
    }
}
