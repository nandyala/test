package com.company.procedureevaluation.client;

import com.company.procedureevaluation.exception.InputDataApiException;
import com.company.procedureevaluation.model.ProcedureRequest;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestClient;

import static com.company.procedureevaluation.block.AddressFormattingSupport.mapOfParty;

public class InputDataApiClient {

    private static final Logger log = LoggerFactory.getLogger(InputDataApiClient.class);

    private final String inputApiBaseUrl;
    private final RestClient restClient;

    public InputDataApiClient(String inputApiBaseUrl) {
        this.inputApiBaseUrl = inputApiBaseUrl == null ? "" : inputApiBaseUrl.trim();
        this.restClient = RestClient.create();
    }

    public Map<String, Object> fetchInput(ProcedureRequest request) {
        if (!request.input().isEmpty()) {
            return request.input();
        }
        if (!inputApiBaseUrl.isBlank()) {
            return fetchFromApi(request);
        }
        return demoForm9012Input();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> fetchFromApi(ProcedureRequest request) {
        String uri = inputApiBaseUrl + "/procedure-input/"
                + request.procedureCode() + "/" + request.requestId();
        RuntimeException lastFailure = null;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                log.info("INPUT-DATA-API requestId={} procedureCode={} attempt={} uri={}",
                        request.requestId(), request.procedureCode(), attempt, uri);
                return restClient.get()
                        .uri(uri)
                        .retrieve()
                        .body(Map.class);
            } catch (RuntimeException ex) {
                lastFailure = ex;
                log.warn("INPUT-DATA-API-FAILED requestId={} procedureCode={} attempt={} message={}",
                        request.requestId(), request.procedureCode(), attempt, ex.getMessage());
            }
        }
        throw new InputDataApiException("Unable to fetch input data for request "
                + request.requestId() + " and procedure " + request.procedureCode(), lastFailure);
    }

    public Map<String, Object> demoForm9012Input() {
        Map<String, Object> input = new LinkedHashMap<>();
        input.put("run_date", LocalDate.of(2026, 6, 10).toString());
        input.put("bus_date", LocalDate.of(2026, 6, 9).toString());
        input.put("acct_nmbr", "1234567890");
        input.put("event_proc_cd", "48,000");
        input.put("event_reas_cd", "89,010");
        input.put("reas_desc", "Demo reason description");
        input.put("form_desc", "Demo FORM 9012 description");
        input.put("active_rl_account", true);
        input.put("duplicate_prior_form", false);
        input.put("buyer", mapOfParty("Anita Rao", "120 Main Street", "", "Boston", "MA", "021101234"));
        input.put("cobuyer", mapOfParty("Ravi Rao", "44 Side Street", "Apt 2", "Cambridge", "MA", "021391111"));
        input.put("vin", "1HGBH41JXMN109186");
        input.put("area_nmbr", "123");
        input.put("reg_nmbr", "456");
        input.put("zone_nmbr", "789");
        return input;
    }
}
