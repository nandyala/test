package com.company.procedureevaluation.core;

import com.company.procedureevaluation.exception.InvalidConditionException;
import com.company.procedureevaluation.model.Condition;
import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

public class ConditionEvaluator {

    public boolean matches(Condition condition, EvaluationContext context, EvaluationResult result) {
        if (condition == null) {
            return true;
        }
        Object actual = resolveActual(condition, context, result);
        if (condition.getEquals() != null) {
            return Objects.equals(String.valueOf(actual), String.valueOf(condition.getEquals()));
        }
        if (condition.getInConstant() != null) {
            Object configuredValues = context.constants().get(condition.getInConstant());
            if (!(configuredValues instanceof Collection<?> collection)) {
                throw new InvalidConditionException("Constant " + condition.getInConstant() + " is not a list");
            }
            return collection.stream().anyMatch(value -> Objects.equals(String.valueOf(value), String.valueOf(actual)));
        }
        if (!condition.getIn().isEmpty()) {
            return condition.getIn().stream().anyMatch(value -> Objects.equals(String.valueOf(value), String.valueOf(actual)));
        }
        throw new InvalidConditionException("Condition must contain equals, in, or inConstant");
    }

    private Object resolveActual(Condition condition, EvaluationContext context, EvaluationResult result) {
        if (condition.getField() != null) {
            return context.inputValue(condition.getField());
        }
        if (condition.getResultField() != null) {
            return result.outputValue(condition.getResultField());
        }
        throw new InvalidConditionException("Condition must contain field or resultField");
    }
}
