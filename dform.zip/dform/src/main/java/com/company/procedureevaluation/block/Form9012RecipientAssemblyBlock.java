package com.company.procedureevaluation.block;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form9012RecipientAssemblyBlock implements LogicBlock {

    private static final Logger log = LoggerFactory.getLogger(Form9012RecipientAssemblyBlock.class);

    @Override
    public String name() {
        return "form9012RecipientAssemblyBlock";
    }

    /*
     * Stored procedure conversion mapping:
     * procedure: forms_db.alc_form9012_hist
     * replaces sys_calendar row expansion and CASE logic for buyer/co-buyer recipient rows.
     */
    @Override
    @SuppressWarnings("unchecked")
    public void evaluate(EvaluationContext context, EvaluationResult result) {
        Map<String, Object> buyer = (Map<String, Object>) context.inputValue("buyer");
        Map<String, Object> cobuyer = (Map<String, Object>) context.inputValue("cobuyer");
        boolean hasCobuyer = AddressFormattingSupport.hasText(AddressFormattingSupport.value(cobuyer, "full_name"));
        boolean sameAddress = AddressFormattingSupport.sameAddress(buyer, cobuyer);

        List<Map<String, Object>> recipients = new ArrayList<>();
        recipients.add(recipient(0, buyer, AddressFormattingSupport.trimToEmpty(AddressFormattingSupport.value(cobuyer, "full_name")), sameAddress));
        if (hasCobuyer && !sameAddress) {
            recipients.add(recipient(1, cobuyer, "", sameAddress));
        }

        context.metadata().put("recipients", recipients);
        log.info("PROC-CONVERSION-CHECK batchId={} requestId={} procedureCode={} blockName={} hasCobuyer={} sameAddress={} generatedRows={}",
                context.batchId(), context.requestId(), context.procedureCode(), name(), hasCobuyer, sameAddress, recipients.size());
    }

    private Map<String, Object> recipient(int isCobuyer, Map<String, Object> party, String cobuyerFullName, boolean cobuyerHasBuyerAddress) {
        Map<String, Object> recipient = new LinkedHashMap<>();
        recipient.put("is_cobuyer", isCobuyer);
        recipient.put("party", party);
        recipient.put("cobuyr_full_name", cobuyerFullName);
        recipient.put("cobuyer_has_buyer_address", cobuyerHasBuyerAddress ? 1 : 0);
        return recipient;
    }
}
