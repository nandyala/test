package com.company.procedureevaluation.model;

import java.util.ArrayList;
import java.util.List;

public class FlowStep {
    private String block;
    private String group;
    private Condition when;
    private List<FlowStep> steps = new ArrayList<>();

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public Condition getWhen() {
        return when;
    }

    public void setWhen(Condition when) {
        this.when = when;
    }

    public List<FlowStep> getSteps() {
        return steps;
    }

    public void setSteps(List<FlowStep> steps) {
        this.steps = steps == null ? new ArrayList<>() : steps;
    }
}
