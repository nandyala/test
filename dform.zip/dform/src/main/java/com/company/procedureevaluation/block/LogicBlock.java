package com.company.procedureevaluation.block;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;

public interface LogicBlock {
    String name();

    void evaluate(EvaluationContext context, EvaluationResult result);
}
