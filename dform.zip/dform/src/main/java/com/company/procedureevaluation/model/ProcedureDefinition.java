package com.company.procedureevaluation.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ProcedureDefinition {
    private String code;
    private Map<String, Object> constants = new LinkedHashMap<>();
    private List<FlowStep> flow = new ArrayList<>();

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Map<String, Object> getConstants() {
        return constants;
    }

    public void setConstants(Map<String, Object> constants) {
        this.constants = constants == null ? new LinkedHashMap<>() : constants;
    }

    public List<FlowStep> getFlow() {
        return flow;
    }

    public void setFlow(List<FlowStep> flow) {
        this.flow = flow == null ? new ArrayList<>() : flow;
    }
}
