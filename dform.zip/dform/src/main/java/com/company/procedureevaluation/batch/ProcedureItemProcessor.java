package com.company.procedureevaluation.batch;

import com.company.procedureevaluation.client.InputDataApiClient;
import com.company.procedureevaluation.core.ProcedureEvaluator;
import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import com.company.procedureevaluation.model.ProcedureRequest;
import java.util.Map;
import org.springframework.batch.item.ItemProcessor;

public class ProcedureItemProcessor implements ItemProcessor<ProcedureRequest, ProcedureEvaluationItem> {

    private final InputDataApiClient inputDataApiClient;
    private final ProcedureEvaluator procedureEvaluator;

    public ProcedureItemProcessor(InputDataApiClient inputDataApiClient, ProcedureEvaluator procedureEvaluator) {
        this.inputDataApiClient = inputDataApiClient;
        this.procedureEvaluator = procedureEvaluator;
    }

    @Override
    public ProcedureEvaluationItem process(ProcedureRequest request) {
        Map<String, Object> input = inputDataApiClient.fetchInput(request);
        EvaluationContext context = new EvaluationContext(request.batchId(), request.requestId(), request.procedureCode(), input);
        EvaluationResult result = procedureEvaluator.evaluate(context);
        return new ProcedureEvaluationItem(context, result);
    }
}
