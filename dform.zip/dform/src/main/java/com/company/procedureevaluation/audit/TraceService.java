package com.company.procedureevaluation.audit;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.repository.TraceRepository;
import java.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TraceService {

    private static final Logger log = LoggerFactory.getLogger(TraceService.class);

    private final TraceRepository traceRepository;

    public TraceService(TraceRepository traceRepository) {
        this.traceRepository = traceRepository;
    }

    public void record(EvaluationContext context, String blockName, TraceStatus status, long durationMs, String skipReason, String errorMessage) {
        log.info("PROC-EVAL-TRACE batchId={} requestId={} procedureCode={} blockName={} status={} durationMs={} skipReason={} errorMessage={}",
                context.batchId(), context.requestId(), context.procedureCode(), blockName, status, durationMs, skipReason, errorMessage);
        traceRepository.save(new TraceEvent(
                context.batchId(),
                context.requestId(),
                context.procedureCode(),
                blockName,
                status,
                durationMs,
                skipReason,
                errorMessage,
                LocalDateTime.now()
        ));
    }
}
