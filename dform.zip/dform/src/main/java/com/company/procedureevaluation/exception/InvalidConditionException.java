package com.company.procedureevaluation.exception;

public class InvalidConditionException extends RuntimeException {
    public InvalidConditionException(String message) {
        super(message);
    }
}
