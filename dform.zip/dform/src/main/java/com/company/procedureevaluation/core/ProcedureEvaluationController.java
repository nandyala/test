package com.company.procedureevaluation.core;

import com.company.procedureevaluation.batch.ProcedureJobLaunchResponse;
import com.company.procedureevaluation.batch.ProcedureJobRequest;
import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import com.company.procedureevaluation.model.ProcedureRequest;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/procedure-evaluations")
public class ProcedureEvaluationController {

    private final ProcedureEvaluator procedureEvaluator;
    private final JobLauncher jobLauncher;
    private final Job procedureEvaluationJob;
    private final JobExplorer jobExplorer;

    public ProcedureEvaluationController(
            ProcedureEvaluator procedureEvaluator,
            JobLauncher jobLauncher,
            Job procedureEvaluationJob,
            JobExplorer jobExplorer
    ) {
        this.procedureEvaluator = procedureEvaluator;
        this.jobLauncher = jobLauncher;
        this.procedureEvaluationJob = procedureEvaluationJob;
        this.jobExplorer = jobExplorer;
    }

    @PostMapping("/evaluate")
    public EvaluationResult evaluate(@Valid @RequestBody ProcedureRequest request) {
        EvaluationContext context = new EvaluationContext(
                request.batchId(),
                request.requestId(),
                request.procedureCode(),
                request.input()
        );
        return procedureEvaluator.evaluate(context);
    }

    @PostMapping("/jobs")
    public ProcedureJobLaunchResponse launchJob(@Valid @RequestBody ProcedureJobRequest request) throws Exception {
        JobExecution execution = jobLauncher.run(procedureEvaluationJob, new JobParametersBuilder()
                .addString("batchId", request.batchId())
                .addString("requestId", request.requestId())
                .addString("procedureCode", request.procedureCode())
                .addLong("requestTimestamp", System.currentTimeMillis())
                .toJobParameters());
        return new ProcedureJobLaunchResponse(execution.getId(), execution.getJobInstance().getJobName(), execution.getStatus().name());
    }

    @GetMapping("/jobs/{executionId}")
    public ResponseEntity<Map<String, Object>> getJob(@PathVariable Long executionId) {
        JobExecution execution = jobExplorer.getJobExecution(executionId);
        if (execution == null) {
            return ResponseEntity.notFound().build();
        }
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("jobExecutionId", execution.getId());
        response.put("jobName", execution.getJobInstance().getJobName());
        response.put("status", execution.getStatus().name());
        response.put("parameters", execution.getJobParameters().getParameters());
        response.put("stepExecutions", execution.getStepExecutions().stream()
                .map(step -> Map.of(
                        "stepName", step.getStepName(),
                        "status", step.getStatus().name(),
                        "readCount", step.getReadCount(),
                        "writeCount", step.getWriteCount(),
                        "skipCount", step.getSkipCount()
                ))
                .toList());
        return ResponseEntity.ok(response);
    }
}
