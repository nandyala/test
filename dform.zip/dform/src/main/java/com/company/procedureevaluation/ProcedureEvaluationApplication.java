package com.company.procedureevaluation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource("classpath:batch/jobs/procedure-evaluation-job.xml")
public class ProcedureEvaluationApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProcedureEvaluationApplication.class, args);
    }
}
