package com.company.procedureevaluation.model;

import java.util.ArrayList;
import java.util.List;

public class Condition {
    private String field;
    private String resultField;
    private Object equals;
    private List<Object> in = new ArrayList<>();
    private String inConstant;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getResultField() {
        return resultField;
    }

    public void setResultField(String resultField) {
        this.resultField = resultField;
    }

    public Object getEquals() {
        return equals;
    }

    public void setEquals(Object equals) {
        this.equals = equals;
    }

    public List<Object> getIn() {
        return in;
    }

    public void setIn(List<Object> in) {
        this.in = in == null ? new ArrayList<>() : in;
    }

    public String getInConstant() {
        return inConstant;
    }

    public void setInConstant(String inConstant) {
        this.inConstant = inConstant;
    }
}
