package com.company.procedureevaluation.batch;

public record ProcedureJobLaunchResponse(long jobExecutionId, String jobName, String status) {
}
