package com.company.procedureevaluation.audit;

public enum TraceStatus {
    SUCCESS,
    FAILED,
    SKIPPED
}
