package com.company.procedureevaluation.block;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form9012OutputMappingBlock implements LogicBlock {

    private static final Logger log = LoggerFactory.getLogger(Form9012OutputMappingBlock.class);
    private static final DateTimeFormatter BARCODE_TS = DateTimeFormatter.ofPattern("yyyyMMddHHmm");

    @Override
    public String name() {
        return "form9012OutputMappingBlock";
    }

    /*
     * Stored procedure conversion mapping:
     * procedure: forms_db.alc_form9012_hist
     * replaces INSERT SELECT projection into forms_db.alc_form9012_hist_nppi.
     */
    @Override
    @SuppressWarnings("unchecked")
    public void evaluate(EvaluationContext context, EvaluationResult result) {
        List<Map<String, Object>> recipients = (List<Map<String, Object>>) context.metadata().get("recipients");
        List<Map<String, Object>> rows = new ArrayList<>();
        for (Map<String, Object> recipient : recipients) {
            rows.add(row(context, recipient));
        }
        result.output().put("rows", rows);
        log.info("PROC-CONVERSION-MAP batchId={} requestId={} procedureCode={} blockName={} rowCount={}",
                context.batchId(), context.requestId(), context.procedureCode(), name(), rows.size());
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> row(EvaluationContext context, Map<String, Object> recipient) {
        Map<String, Object> party = (Map<String, Object>) recipient.get("party");
        Map<String, Object> row = new LinkedHashMap<>();
        put(row, "run_date", context.inputValue("run_date"), "pRUNDT", context);
        put(row, "bus_date", context.inputValue("bus_date"), "pBUSDT", context);
        put(row, "acct_nmbr", context.inputValue("acct_nmbr"), "faw_ev.acct_nmbr", context);
        put(row, "buyr_full_name", AddressFormattingSupport.trim(AddressFormattingSupport.value(party, "full_name")), "CASE buyer/cobuyer full_name", context);
        put(row, "buyr_addr_line_1", AddressFormattingSupport.line1(party), "CASE buyer/cobuyer address line", context);
        put(row, "buyr_city_name", AddressFormattingSupport.city(party), "CASE buyer/cobuyer city_name", context);
        put(row, "buyr_state_cd", AddressFormattingSupport.state(party), "CASE buyer/cobuyer upper state", context);
        put(row, "buyr_postl_cd", AddressFormattingSupport.postal(party), "CASE buyer/cobuyer ZIP+4", context);
        put(row, "buyr_csz", AddressFormattingSupport.csz(party), "city || state || postal", context);
        put(row, "cobuyr_full_name", recipient.get("cobuyr_full_name"), "CASE co-buyer full name", context);
        put(row, "cobuyr_addr_line_1", "", "constant empty", context);
        put(row, "cobuyr_city_name", "", "constant empty", context);
        put(row, "cobuyr_state_cd", "", "constant empty", context);
        put(row, "cobuyr_postl_cd", "", "constant empty", context);
        put(row, "cobuyr_csz", "", "constant empty", context);
        put(row, "cobuyer_has_buyer_address", recipient.get("cobuyer_has_buyer_address"), "address comparison", context);
        put(row, "event_proc_cd", context.inputValue("event_proc_cd"), "faw_ev.Event_Proc_Cd", context);
        put(row, "event_reas_cd", context.inputValue("event_reas_cd"), "faw_ev.Event_Reas_Cd", context);
        put(row, "reas_desc", context.inputValue("reas_desc"), "faw_reas.reas_desc", context);
        put(row, "form_desc", context.inputValue("form_desc"), "faw_re9012.reas_desc", context);
        put(row, "form_number", context.constants().get("formNumber"), "constant form number", context);
        put(row, "barcode", context.inputValue("acct_nmbr") + LocalDateTime.now().format(BARCODE_TS), "acct_nmbr || timestamp", context);
        put(row, "is_cobuyer", recipient.get("is_cobuyer"), "generated recipient row flag", context);
        put(row, "vin", context.inputValue("vin"), "pavh.vin", context);
        put(row, "loctn_cd", "0" + context.inputValue("area_nmbr") + context.inputValue("reg_nmbr") + context.inputValue("zone_nmbr"), "orh location", context);
        Map<String, Object> defaults = (Map<String, Object>) context.constants().get("defaults");
        defaults.forEach(row::putIfAbsent);
        return row;
    }

    private void put(Map<String, Object> row, String field, Object value, String legacySource, EvaluationContext context) {
        row.put(field, value);
        log.info("PROC-CONVERSION-FIELD batchId={} requestId={} procedureCode={} blockName={} field={} legacySource={} value={}",
                context.batchId(), context.requestId(), context.procedureCode(), name(), field, legacySource, value);
    }
}
