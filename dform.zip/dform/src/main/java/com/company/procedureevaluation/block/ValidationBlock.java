package com.company.procedureevaluation.block;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import java.util.List;
import java.util.Map;

public class ValidationBlock implements LogicBlock {

    @Override
    public String name() {
        return "validationBlock";
    }

    @Override
    @SuppressWarnings("unchecked")
    public void evaluate(EvaluationContext context, EvaluationResult result) {
        List<String> requiredFields = (List<String>) context.constants().get("requiredFields");
        List<Map<String, Object>> rows = (List<Map<String, Object>>) result.output().get("rows");
        for (Map<String, Object> row : rows) {
            for (String requiredField : requiredFields) {
                Object value = row.get(requiredField);
                if (value == null || String.valueOf(value).isBlank()) {
                    result.errors().add("Missing required field " + requiredField + " for account " + row.get("acct_nmbr"));
                }
            }
        }
    }
}
