package com.company.procedureevaluation.block;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;

public class NoOpLogicBlock implements LogicBlock {

    private final String name;

    public NoOpLogicBlock(String name) {
        this.name = name;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public void evaluate(EvaluationContext context, EvaluationResult result) {
        result.warnings().add("No-op block executed: " + name);
    }
}
