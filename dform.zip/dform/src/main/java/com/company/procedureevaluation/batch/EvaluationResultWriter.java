package com.company.procedureevaluation.batch;

import com.company.procedureevaluation.repository.EvaluationOutputRepository;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;

public class EvaluationResultWriter implements ItemWriter<ProcedureEvaluationItem> {

    private final EvaluationOutputRepository evaluationOutputRepository;

    public EvaluationResultWriter(EvaluationOutputRepository evaluationOutputRepository) {
        this.evaluationOutputRepository = evaluationOutputRepository;
    }

    @Override
    public void write(Chunk<? extends ProcedureEvaluationItem> chunk) {
        for (ProcedureEvaluationItem item : chunk) {
            evaluationOutputRepository.save(item.context(), item.result());
        }
    }
}
