package com.company.procedureevaluation.batch;

import com.company.procedureevaluation.model.ProcedureRequest;
import java.util.List;
import org.springframework.batch.item.ItemReader;

public class ProcedureItemReader implements ItemReader<ProcedureRequest> {

    private final List<ProcedureRequest> requests;
    private int index;

    public ProcedureItemReader(String batchId, String requestId, String procedureCode) {
        this.requests = List.of(new ProcedureRequest(batchId, requestId, procedureCode, null));
    }

    @Override
    public ProcedureRequest read() {
        if (index >= requests.size()) {
            return null;
        }
        return requests.get(index++);
    }
}
