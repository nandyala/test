package com.company.procedureevaluation.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class EvaluationContext {

    private final String batchId;
    private final String requestId;
    private final String procedureCode;
    private final Map<String, Object> input;
    private final Map<String, Object> constants = new LinkedHashMap<>();
    private final Map<String, Object> metadata = new LinkedHashMap<>();

    public EvaluationContext(String batchId, String requestId, String procedureCode, Map<String, Object> input) {
        this.batchId = batchId;
        this.requestId = requestId;
        this.procedureCode = procedureCode;
        this.input = input == null ? new LinkedHashMap<>() : new LinkedHashMap<>(input);
    }

    public String batchId() {
        return batchId;
    }

    public String requestId() {
        return requestId;
    }

    public String procedureCode() {
        return procedureCode;
    }

    public Map<String, Object> input() {
        return input;
    }

    public Map<String, Object> constants() {
        return constants;
    }

    public Map<String, Object> metadata() {
        return metadata;
    }

    public Object inputValue(String field) {
        return input.get(field);
    }
}
