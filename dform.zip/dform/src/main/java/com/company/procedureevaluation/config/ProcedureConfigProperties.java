package com.company.procedureevaluation.config;

import com.company.procedureevaluation.exception.MissingProcedureConfigException;
import com.company.procedureevaluation.model.Condition;
import com.company.procedureevaluation.model.FlowStep;
import com.company.procedureevaluation.model.ProcedureDefinition;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.core.io.ClassPathResource;
import org.yaml.snakeyaml.Yaml;

public class ProcedureConfigProperties {

    private static final String CONFIG_RESOURCE = "procedures/procedures.yml";

    private final Map<String, ProcedureDefinition> procedures = new LinkedHashMap<>();

    public ProcedureConfigProperties() {
        load();
    }

    public ProcedureDefinition getRequired(String procedureCode) {
        ProcedureDefinition definition = procedures.get(procedureCode);
        if (definition == null) {
            throw new MissingProcedureConfigException("No procedure configuration found for " + procedureCode);
        }
        return definition;
    }

    public Map<String, ProcedureDefinition> procedures() {
        return procedures;
    }

    @SuppressWarnings("unchecked")
    private void load() {
        try (InputStream inputStream = new ClassPathResource(CONFIG_RESOURCE).getInputStream()) {
            Map<String, Object> root = new Yaml().load(inputStream);
            Map<String, Object> procedureMap = (Map<String, Object>) root.get("procedures");
            if (procedureMap == null || procedureMap.isEmpty()) {
                throw new MissingProcedureConfigException("No procedures configured in " + CONFIG_RESOURCE);
            }
            for (Map.Entry<String, Object> entry : procedureMap.entrySet()) {
                String code = entry.getKey();
                Map<String, Object> body = (Map<String, Object>) entry.getValue();
                ProcedureDefinition definition = new ProcedureDefinition();
                definition.setCode(code);
                definition.setConstants((Map<String, Object>) body.getOrDefault("constants", Map.of()));
                definition.setFlow(mapFlow((List<Map<String, Object>>) body.getOrDefault("flow", List.of())));
                if (definition.getFlow().isEmpty()) {
                    throw new MissingProcedureConfigException("Procedure " + code + " has no flow configured");
                }
                procedures.put(code, definition);
            }
        } catch (MissingProcedureConfigException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to load procedure configuration from " + CONFIG_RESOURCE, ex);
        }
    }

    @SuppressWarnings("unchecked")
    private List<FlowStep> mapFlow(List<Map<String, Object>> configuredSteps) {
        List<FlowStep> steps = new ArrayList<>();
        for (Map<String, Object> configuredStep : configuredSteps) {
            FlowStep step = new FlowStep();
            step.setBlock((String) configuredStep.get("block"));
            step.setGroup((String) configuredStep.get("group"));
            if (configuredStep.containsKey("when")) {
                step.setWhen(mapCondition((Map<String, Object>) configuredStep.get("when")));
            }
            if (configuredStep.containsKey("steps")) {
                step.setSteps(mapFlow((List<Map<String, Object>>) configuredStep.get("steps")));
            }
            steps.add(step);
        }
        return steps;
    }

    private Condition mapCondition(Map<String, Object> configuredCondition) {
        Condition condition = new Condition();
        condition.setField((String) configuredCondition.get("field"));
        condition.setResultField((String) configuredCondition.get("resultField"));
        condition.setEquals(configuredCondition.get("equals"));
        condition.setIn((List<Object>) configuredCondition.getOrDefault("in", List.of()));
        condition.setInConstant((String) configuredCondition.get("inConstant"));
        return condition;
    }
}
