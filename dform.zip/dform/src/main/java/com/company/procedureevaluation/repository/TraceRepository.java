package com.company.procedureevaluation.repository;

import com.company.procedureevaluation.audit.TraceEvent;
import org.springframework.jdbc.core.JdbcTemplate;

public class TraceRepository {

    private final JdbcTemplate jdbcTemplate;

    public TraceRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void save(TraceEvent event) {
        jdbcTemplate.update("""
                insert into EVALUATION_TRACE (
                    batch_id,
                    request_id,
                    procedure_code,
                    block_name,
                    status,
                    duration_ms,
                    skip_reason,
                    error_message,
                    created_at
                ) values (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                event.batchId(),
                event.requestId(),
                event.procedureCode(),
                event.blockName(),
                event.status().name(),
                event.durationMs(),
                event.skipReason(),
                event.errorMessage(),
                event.createdAt());
    }
}
