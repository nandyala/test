package com.company.procedureevaluation.block;

import com.company.procedureevaluation.exception.MissingLogicBlockException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class LogicBlockRegistry {

    private final Map<String, LogicBlock> blocks = new LinkedHashMap<>();

    public LogicBlockRegistry(List<LogicBlock> logicBlocks) {
        for (LogicBlock logicBlock : logicBlocks) {
            blocks.put(logicBlock.name(), logicBlock);
        }
    }

    public LogicBlock getRequired(String name) {
        LogicBlock block = blocks.get(name);
        if (block == null) {
            throw new MissingLogicBlockException("No LogicBlock registered with name " + name);
        }
        return block;
    }
}
