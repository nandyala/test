package com.company.procedureevaluation.audit;

import java.time.LocalDateTime;

public record TraceEvent(
        String batchId,
        String requestId,
        String procedureCode,
        String blockName,
        TraceStatus status,
        long durationMs,
        String skipReason,
        String errorMessage,
        LocalDateTime createdAt
) {
}
