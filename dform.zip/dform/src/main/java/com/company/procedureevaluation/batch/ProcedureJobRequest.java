package com.company.procedureevaluation.batch;

import jakarta.validation.constraints.NotBlank;

public record ProcedureJobRequest(
        @NotBlank String batchId,
        @NotBlank String requestId,
        @NotBlank String procedureCode
) {
}
