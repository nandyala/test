package com.company.procedureevaluation.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

public class ProcedureStepExecutionListener implements StepExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(ProcedureStepExecutionListener.class);

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info("BATCH-STEP-START stepExecutionId={} stepName={}", stepExecution.getId(), stepExecution.getStepName());
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        log.info("BATCH-STEP-END stepExecutionId={} stepName={} status={} readCount={} writeCount={} filterCount={} skipCount={}",
                stepExecution.getId(), stepExecution.getStepName(), stepExecution.getStatus(),
                stepExecution.getReadCount(), stepExecution.getWriteCount(), stepExecution.getFilterCount(), stepExecution.getSkipCount());
        return stepExecution.getExitStatus();
    }
}
