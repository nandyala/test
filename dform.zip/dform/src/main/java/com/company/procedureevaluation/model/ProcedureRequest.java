package com.company.procedureevaluation.model;

import jakarta.validation.constraints.NotBlank;
import java.util.LinkedHashMap;
import java.util.Map;

public record ProcedureRequest(
        @NotBlank String batchId,
        @NotBlank String requestId,
        @NotBlank String procedureCode,
        Map<String, Object> input
) {
    public ProcedureRequest {
        input = input == null ? new LinkedHashMap<>() : new LinkedHashMap<>(input);
    }
}
