package com.company.procedureevaluation.block;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import java.util.Collection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form9012EventEligibilityBlock implements LogicBlock {

    private static final Logger log = LoggerFactory.getLogger(Form9012EventEligibilityBlock.class);

    @Override
    public String name() {
        return "form9012EventEligibilityBlock";
    }

    /*
     * Stored procedure conversion mapping:
     * procedure: forms_db.alc_form9012_hist
     * replaces WHERE filters for Event_Proc_Cd, Event_Reas_Cd, duplicate daily_forms suppression,
     * active RL account, and required source eligibility.
     */
    @Override
    public void evaluate(EvaluationContext context, EvaluationResult result) {
        String eventProcessCode = string(context.inputValue("event_proc_cd"));
        String eventReasonCode = string(context.inputValue("event_reas_cd"));
        boolean duplicatePriorForm = Boolean.parseBoolean(string(context.inputValue("duplicate_prior_form")));
        boolean activeRlAccount = Boolean.parseBoolean(string(context.input().getOrDefault("active_rl_account", true)));

        boolean processMatches = String.valueOf(context.constants().get("eventProcessCode")).equals(eventProcessCode);
        boolean reasonAllowed = ((Collection<?>) context.constants().get("allowedEventReasonCodes"))
                .stream()
                .anyMatch(value -> String.valueOf(value).equals(eventReasonCode));
        boolean eligible = processMatches && reasonAllowed && !duplicatePriorForm && activeRlAccount;

        result.output().put("eligible", eligible);
        log.info("PROC-CONVERSION-CHECK batchId={} requestId={} procedureCode={} blockName={} processMatches={} reasonAllowed={} duplicatePriorForm={} activeRlAccount={} eligible={}",
                context.batchId(), context.requestId(), context.procedureCode(), name(), processMatches, reasonAllowed,
                duplicatePriorForm, activeRlAccount, eligible);
        if (!eligible) {
            result.warnings().add("FORM_9012 source record is not eligible");
        }
    }

    private String string(Object value) {
        return value == null ? null : String.valueOf(value);
    }
}
