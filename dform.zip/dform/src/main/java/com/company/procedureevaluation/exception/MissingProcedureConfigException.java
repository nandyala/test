package com.company.procedureevaluation.exception;

public class MissingProcedureConfigException extends RuntimeException {
    public MissingProcedureConfigException(String message) {
        super(message);
    }
}
