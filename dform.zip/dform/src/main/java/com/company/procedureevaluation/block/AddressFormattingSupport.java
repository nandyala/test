package com.company.procedureevaluation.block;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public final class AddressFormattingSupport {

    private AddressFormattingSupport() {
    }

    static String line1(Map<String, Object> party) {
        String line1 = trim(value(party, "addr_line_1"));
        String line2 = trim(value(party, "addr_line_2"));
        return hasText(line2) ? line1 + ", " + line2 : line1;
    }

    static String city(Map<String, Object> party) {
        return trim(value(party, "city_name"));
    }

    static String state(Map<String, Object> party) {
        String state = trim(value(party, "state_cd"));
        return state == null ? null : state.toUpperCase();
    }

    static String postal(Map<String, Object> party) {
        String postal = trim(value(party, "postl_cd"));
        if (postal != null && postal.length() == 9 && !postal.contains("-")) {
            return postal.substring(0, 5) + "-" + postal.substring(5);
        }
        return postal;
    }

    static String csz(Map<String, Object> party) {
        return city(party) + ", " + state(party) + " " + postal(party);
    }

    static boolean sameAddress(Map<String, Object> left, Map<String, Object> right) {
        return Objects.equals(trimToEmpty(value(left, "addr_line_1")), trimToEmpty(value(right, "addr_line_1")))
                && Objects.equals(trimToEmpty(value(left, "addr_line_2")), trimToEmpty(value(right, "addr_line_2")))
                && Objects.equals(trimToEmpty(value(left, "city_name")), trimToEmpty(value(right, "city_name")))
                && Objects.equals(trimToEmpty(value(left, "state_cd")), trimToEmpty(value(right, "state_cd")));
    }

    public static Map<String, Object> mapOfParty(String fullName, String line1, String line2, String city, String state, String postal) {
        Map<String, Object> party = new LinkedHashMap<>();
        party.put("full_name", fullName);
        party.put("addr_line_1", line1);
        party.put("addr_line_2", line2);
        party.put("city_name", city);
        party.put("state_cd", state);
        party.put("postl_cd", postal);
        return party;
    }

    static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    static String value(Map<String, Object> map, String key) {
        Object value = map == null ? null : map.get(key);
        return value == null ? null : String.valueOf(value);
    }

    static String trim(String value) {
        return value == null ? null : value.trim();
    }

    static String trimToEmpty(String value) {
        return value == null ? "" : value.trim();
    }
}
