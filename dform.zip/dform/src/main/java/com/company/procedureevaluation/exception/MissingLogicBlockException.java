package com.company.procedureevaluation.exception;

public class MissingLogicBlockException extends RuntimeException {
    public MissingLogicBlockException(String message) {
        super(message);
    }
}
