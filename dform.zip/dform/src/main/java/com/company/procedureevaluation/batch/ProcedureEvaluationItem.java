package com.company.procedureevaluation.batch;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;

public record ProcedureEvaluationItem(EvaluationContext context, EvaluationResult result) {
}
