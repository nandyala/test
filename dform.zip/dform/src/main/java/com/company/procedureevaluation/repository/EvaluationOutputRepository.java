package com.company.procedureevaluation.repository;

import com.company.procedureevaluation.model.EvaluationContext;
import com.company.procedureevaluation.model.EvaluationResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import org.springframework.jdbc.core.JdbcTemplate;

public class EvaluationOutputRepository {

    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public EvaluationOutputRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void save(EvaluationContext context, EvaluationResult result) {
        jdbcTemplate.update("""
                insert into EVALUATION_OUTPUT (
                    batch_id,
                    request_id,
                    procedure_code,
                    output_payload_json,
                    status,
                    created_at
                ) values (?, ?, ?, ?, ?, ?)
                """,
                context.batchId(),
                result.requestId(),
                result.procedureCode(),
                toJson(result.output()),
                result.status(),
                LocalDateTime.now());
    }

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Unable to serialize evaluation output", ex);
        }
    }
}
