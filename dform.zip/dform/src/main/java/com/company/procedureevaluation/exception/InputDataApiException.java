package com.company.procedureevaluation.exception;

public class InputDataApiException extends RuntimeException {
    public InputDataApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
