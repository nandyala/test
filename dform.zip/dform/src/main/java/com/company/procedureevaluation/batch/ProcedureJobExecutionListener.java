package com.company.procedureevaluation.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

public class ProcedureJobExecutionListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(ProcedureJobExecutionListener.class);

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("BATCH-JOB-START jobExecutionId={} jobName={} parameters={}",
                jobExecution.getId(), jobExecution.getJobInstance().getJobName(), jobExecution.getJobParameters());
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("BATCH-JOB-END jobExecutionId={} status={} exitStatus={}",
                jobExecution.getId(), jobExecution.getStatus(), jobExecution.getExitStatus().getExitCode());
    }
}
