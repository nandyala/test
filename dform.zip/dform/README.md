# Procedure Evaluation Batch Framework

This project is a Spring Boot and Spring Batch framework for migrating large stored procedures used for letter/form data generation. The main goal is to remove direct dependency on the data warehouse from the batch logic while keeping the migrated business rules traceable, testable, and regulator-friendly.

The important design decision is separation of responsibility:

- API owns data access and source abstraction.
- Spring Batch owns orchestration, restartability, and high-volume processing.
- Evaluation Engine owns the migrated stored-procedure business logic.
- Audit tables own visibility into what was evaluated, resolved, skipped, failed, and written.

## Architecture

Open the editable Draw.io diagram here:

[docs/procedure-evaluation-architecture.drawio](/Users/ds/Documents/dform/docs/procedure-evaluation-architecture.drawio)

High-level flow:

```text
Shell Script / Scheduler / Control-M
   |
   v
Spring Batch Job
   |
   +--> Step 1: Candidate Discovery
   |       |
   |       +--> Candidate API
   |       |       |
   |       |       +--> Data Warehouse today
   |       |       +--> Future source tomorrow
   |       |
   |       +--> PROCEDURE_CANDIDATE staging table
   |
   +--> Step 2: Candidate Evaluation
           |
           +--> Read staged candidates
           +--> Input Data API fetches full account/form data profile
           +--> Evaluation Engine executes migrated procedure logic
           +--> Write final output and audit
```

## Why Two API Calls?

The batch should not start by fetching full data for every account. It should first discover possible candidates, then fetch full data only for those candidates.

Use two API responsibilities:

```text
Candidate API = who should be processed?
Input Data API = what data is needed to evaluate one account?
```

This keeps the expensive data profile call focused and makes the job restartable account by account.

## Candidate Discovery

Candidate Discovery performs first-level filtering. These filters should be simple and source-friendly because the API may talk to the data warehouse today and another source tomorrow.

Examples:

- business date
- procedure code
- product family
- account status
- event date range
- event process code

Example candidate API:

```http
GET /procedure-candidates?procedureCode=FORM_9012&businessDate=2026-06-23&page=0&size=500
```

Example response:

```json
{
  "procedureCode": "FORM_9012",
  "businessDate": "2026-06-23",
  "page": 0,
  "size": 500,
  "hasNext": true,
  "candidates": [
    {
      "accountNumber": "1234567890",
      "customerId": "C10001",
      "eventProcessCode": "48,000",
      "eventReasonCode": "89,010"
    }
  ]
}
```

## Full Input Data Fetch

For each staged candidate, the batch fetches the full data profile needed by the migrated procedure logic.

Example input API:

```http
GET /procedure-input/FORM_9012/accounts/1234567890?businessDate=2026-06-23
```

Example response:

```json
{
  "run_date": "2026-06-23",
  "bus_date": "2026-06-23",
  "acct_nmbr": "1234567890",
  "event_proc_cd": "48,000",
  "event_reas_cd": "89,010",
  "active_rl_account": true,
  "duplicate_prior_form": false,
  "buyer": {
    "full_name": "Anita Rao",
    "addr_line_1": "120 Main Street",
    "addr_line_2": "",
    "city_name": "Boston",
    "state_cd": "MA",
    "postl_cd": "021101234"
  },
  "cobuyer": {
    "full_name": "Ravi Rao",
    "addr_line_1": "44 Side Street",
    "addr_line_2": "Apt 2",
    "city_name": "Cambridge",
    "state_cd": "MA",
    "postl_cd": "021391111"
  },
  "vin": "1HGBH41JXMN109186",
  "area_nmbr": "123",
  "reg_nmbr": "456",
  "zone_nmbr": "789"
}
```

## Where Stored Procedure Logic Goes

Do not move all stored procedure logic into the API. That only hides the same problem in a new place.

Split the old procedure logic like this:

| Procedure Logic Type | Target Owner |
| --- | --- |
| Simple source filters | Candidate API |
| Full account/customer/form data retrieval | Input Data API |
| Business eligibility checks | Java Evaluation Engine blocks |
| IF/ELSE, CASE, EXISTS decisions | Java Evaluation Engine blocks |
| Repeated address, buyer/co-buyer, validation logic | Common blocks |
| Procedure-specific output mapping | Procedure blocks |
| Hardcoded form values and allowed code lists | YAML configuration |
| Final result persistence | Writer/repository |
| Debug/regulatory visibility | Trace and resolved-value tables |

## Evaluation Engine

The Evaluation Engine evaluates one candidate at a time.

```text
EvaluationContext
   |
   v
ProcedureEvaluator
   |
   v
Configured flow from YAML
   |
   +--> Common Blocks
   +--> Configurable Rules
   +--> Procedure Blocks
   |
   v
EvaluationResult
```

Common blocks should be reused across many procedures:

- address formatting
- buyer/co-buyer recipient assembly
- duplicate suppression
- default values
- validation
- date calculations
- output field normalization

Procedure blocks should only contain logic unique to that form/procedure:

- FORM_9012 event reason eligibility
- FORM_9012-specific output mapping
- any special rule that does not belong in common logic

## Configuration

Procedure configuration belongs in YAML so that form constants and flow ordering are not hardcoded in Java.

Example:

```yaml
procedures:
  FORM_9012:
    constants:
      legacyProcedure: forms_db.alc_form9012_hist
      formNumber: "9012"
      eventProcessCode: "48,000"
      allowedEventReasonCodes:
        - "89,010"
        - "89,020"
    flow:
      - block: form9012EventEligibilityBlock
      - block: form9012RecipientAssemblyBlock
      - group: recipientRows
        when:
          resultField: eligible
          equals: true
        steps:
          - block: form9012OutputMappingBlock
          - block: validationBlock
```

## Batch Execution Model

For 50 procedures, use one generic runtime and pass the procedure code as a parameter.

Example shell calls:

```bash
java -jar procedure-evaluation.jar procedureCode=FORM_9012 businessDate=2026-06-23
java -jar procedure-evaluation.jar procedureCode=FORM_9013 businessDate=2026-06-23
java -jar procedure-evaluation.jar procedureCode=FORM_9014 businessDate=2026-06-23
```

This supports the current model where shell scripts trigger procedures one by one, while still allowing future schedulers or APIs to trigger the same job.

## Tables

Recommended operational tables:

```text
PROCEDURE_RUN
- run_id
- procedure_code
- business_date
- status
- started_at
- ended_at
- triggered_by
```

```text
PROCEDURE_CANDIDATE
- candidate_id
- run_id
- procedure_code
- account_number
- business_date
- candidate_status
- source_filter_reason
- candidate_payload_json
- created_at
- updated_at
```

```text
LETTER_CHANNEL_RESULT
- result_id
- run_id
- procedure_code
- account_number
- request_id
- output_payload_json
- status
- export_status
- created_at
```

```text
EVALUATION_TRACE
- trace_id
- run_id
- procedure_code
- account_number
- block_name
- legacy_sql_section
- decision
- status
- duration_ms
- message
- created_at
```

```text
EVALUATION_RESOLVED_VALUE
- value_id
- run_id
- procedure_code
- account_number
- field_name
- field_value
- source_name
- source_field
- rule_name
- legacy_mapping
- created_at
```

## Migration Method For Each Procedure

For every stored procedure, create one migration inventory before coding:

1. Identify procedure inputs and shell parameters.
2. List all tables, views, functions, and other procedures used.
3. Separate first-level candidate filters from business eligibility logic.
4. Define the candidate API fields required for discovery.
5. Define the full input data profile required for evaluation.
6. Classify logic into common blocks, configurable rules, and procedure-specific blocks.
7. Move hardcoded values into YAML constants.
8. Convert each logical section into a small Java block.
9. Add comments and logs referencing the old procedure section.
10. Write comparison tests using old stored procedure output versus new Java output.
11. Store final output, trace rows, and resolved values.
12. Repeat for the next procedure.

## Current Implementation Direction

The current project already contains the core building blocks for the framework:

- Spring Boot application
- XML-based Spring Batch job configuration
- procedure configuration YAML
- procedure evaluator
- flow executor
- logic block registry
- FORM_9012 sample migrated blocks from `procedures/one.sql`
- output persistence
- trace persistence

The next implementation milestone should be adding the formal two-step batch model:

1. `candidateDiscoveryStep`
2. `candidateEvaluationStep`

That change will align the runtime exactly with the architecture in the Draw.io diagram.
