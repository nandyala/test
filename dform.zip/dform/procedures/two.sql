----------------------------------------------------------------
----------------------- STORED PROCEDURE -----------------------
----------------------------------------------------------------

replace procedure forms_db.
alc_form8722_hist

(in prundt char(10))

begin
delete from forms_db.alc_form8722_hist_nppi where run_date = :prundt and bus_date is not null;
insert into forms_db.alc_form8722_hist_nppi
(
    run_date,
    bus_date,
    acct_nmbr,
    is_cobuyer,
    buyr_full_name,
    buyr_addr_line_1,
    buyr_city_name,
    buyr_state_cd,
    buyr_postl_cd,
    buyr_csz,
    cobuyr_full_name,
    cobuyr_addr_line_1,
    cobuyr_city_name,
    cobuyr_state_cd,
    cobuyr_postl_cd,
    cobuyr_csz,
    cobuyer_has_buyer_address,
    repo_dt,
    trmtn_typ_cd,
    Ctrct_Stat_Dt,
    fraud_typ_cd,
    cease_desist_cd,
    xcptn_typ_cd,
    delqy_catgy_cd,
    worklist_que_cd,
    days_past_due_qty,
    payment_due_date,
    payment_amount,
    days_past_due_1_date,
    lob_cd,
    first_class,
    certified,
    mail_type,
    license_reqd,
    send_to,
    vhcl_make,
    vhcl_modl,
    vhcl_my,
    vin,
    loctn_cd,
    barcode,
    company_name,
    company_address,
    company_phone,
    rejected_brd,
    rejected_brd_reason,
    rejected_data,
    rejected_data_reason,
    rejected_final_reason,
    create_pdf,
    form_number,
    paper_size,
    num_sides,
    is_pending,
    pending_group
)
select
    fc0.cal_date as run_date,
    fc0.prior_business_day as bus_date,
    adh.acct_nmbr as acct_nmbr,
    ic.is_cobuyer as is_cobuyer,
    case
        when ic.is_cobuyer = 0 then trim(ctrct_buyr.full_name) else trim(ctrct_cobuyr.full_name)
        end as buyr_full_name,
    case
        when ic.is_cobuyer = 0 then
            case
                when trim(coalesce(ctrct_buyr.addr_line_2, '')) <> '' then trim(ctrct_buyr.addr_line_1) || ', ' || trim(ctrct_buyr.addr_line_2)
                else trim(ctrct_buyr.addr_line_1)
                end
        else
            case
                when trim(coalesce(ctrct_cobuyr.addr_line_2, '')) <> '' then trim(ctrct_cobuyr.addr_line_1) || ', ' || trim(ctrct_cobuyr.addr_line_2)
                else trim(ctrct_cobuyr.addr_line_1)
                end
        end as buyr_addr_line_1,
    case
        when ic.is_cobuyer = 0 then trim(ctrct_buyr.city_name) else trim(ctrct_cobuyr.city_name)
        end as buyr_city_name,
    case
        when ic.is_cobuyer = 0 then trim(upper(ctrct_buyr.state_cd)) else trim(upper(ctrct_cobuyr.state_cd))
        end as buyr_state_cd,
    case
        when ic.is_cobuyer = 0 then
            case
                when
                    character_length(trim(ctrct_buyr.postl_cd)) = 9 and position('-' in ctrct_buyr.postl_cd) = 0
                    then substr(ctrct_buyr.postl_cd, 1, 5) || '-' || substr(ctrct_buyr.postl_cd, 6, 4)
                else trim(ctrct_buyr.postl_cd)
                end
        else
            case
                when
                    character_length(trim(ctrct_cobuyr.postl_cd)) = 9 and position('-' in ctrct_cobuyr.postl_cd) = 0
                    then substr(ctrct_cobuyr.postl_cd, 1, 5) || '-' || substr(ctrct_cobuyr.postl_cd, 6, 4)
                else trim(ctrct_cobuyr.postl_cd)
                end
        end as buyr_postl_cd,
    buyr_city_name || ', ' || buyr_state_cd || ' ' || buyr_postl_cd as buyr_csz,
    case
        when ic.is_cobuyer = 0 then trim(coalesce(ctrct_cobuyr.full_name, ''))
        else ''
        end as cobuyr_full_name,
    '' as cobuyr_addr_line_1,
    '' as cobuyr_city_name,
    '' as cobuyr_state_cd,
    '' as cobuyr_postl_cd,
    '' as cobuyr_csz,
    case
        when
            trim(coalesce(ctrct_buyr.addr_line_1, '')) = trim(coalesce(ctrct_cobuyr.addr_line_1, ''))
                and trim(coalesce(ctrct_buyr.addr_line_2, '')) = trim(coalesce(ctrct_cobuyr.addr_line_2, ''))
                and trim(coalesce(ctrct_buyr.city_name, '')) = trim(coalesce(ctrct_buyr.city_name, ''))
                and trim(coalesce(ctrct_buyr.state_cd, '')) = trim(coalesce(ctrct_cobuyr.state_cd, ''))
            then 1
        else 0
        end as cobuyer_has_buyer_address,
    paeh.repo_dt as repo_dt,
    paeh.trmtn_typ_cd as trmtn_typ_cd,
    pah.ctrct_stat_dt as Ctrct_Stat_Dt,
    pah.fraud_typ_cd as fraud_typ_cd,

    '' as cease_desist_cd,
    pah.xcptn_typ_cd as xcptn_typ_cd,
    adh.delqy_catgy_cd as delqy_catgy_cd,
    adh.worklist_que_cd as worklist_que_cd,
    adh.days_past_due_qty as days_past_due_qty,
    adh.Next_Paymt_Due_Dt as payment_due_date,
    adh.Curr_Paymt_Due_Amt as payment_amount,
    fc.cal_date as days_past_due_1_date,
    pah.lob_cd as lob_cd,
    1 as first_class,
    0 as certified,
    case
        when first_class = 1 and certified = 1 then 'X'
        when certified = 1 then 'C'
        else 'R'
        end as mail_type,
    case
        when (buyr_state_cd = 'NC') or (cobuyr_state_cd = 'NC') then 'visible' else 'hidden'
        end as license_reqd,
    'B' as send_to,
    pavh.vhcl_make as vhcl_make,
    pavh.vhcl_modl as vhcl_modl,
    pavh.vhcl_my as vhcl_my,
    pavh.vin as vin,
    '0' || orh.area_nmbr || orh.reg_nmbr || orh.zone_nmbr as loctn_cd,
    adh.acct_nmbr || cast((current_timestamp (format 'yyyymmddhhmi')) as character(12)) as barcode,
    '' as company_name,
    '' as company_address,
    '' as company_phone,
    case
        when rejected_brd_reason <> '' then 1 else 0
        end as rejected_brd,
    case
        when f.is_active = 0 then 'This form is no longer active'
        WHEN pah.Fraud_Typ_Cd IN ('CI','DI') THEN TRIM(pah.fraud_typ_cd) || ': Confirmed Identity Theft'
        WHEN pah.Fraud_Typ_Cd IN ('CF','DF') THEN TRIM(pah.fraud_typ_cd) || ': Confirmed Fraud'
        WHEN pah.Fraud_Typ_Cd IN ('CY') THEN TRIM(pah.fraud_typ_cd) || ': Confirmed Synthetic Identity Theft'
        WHEN pah.xcptn_typ_cd IN ('A','AA') THEN TRIM(pah.xcptn_typ_cd) || ': In Bankruptcy, Chapter 7'
        WHEN pah.xcptn_typ_cd = ('AB') THEN TRIM(pah.xcptn_typ_cd) || ': In BK - Discharged Non-Reaffirmed'
        WHEN pah.xcptn_typ_cd = ('AE') THEN TRIM(pah.xcptn_typ_cd) || ': All parties filed (includes single ownership) Petition 7'
        WHEN pah.xcptn_typ_cd = ('AF') THEN TRIM(pah.xcptn_typ_cd) || ': All parties filed (includes single ownership) Discharged Non Reaffirmed 7'
        WHEN pah.xcptn_typ_cd = ('AI') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Petition 7'
        WHEN pah.xcptn_typ_cd = ('AJ') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Discharged Non Reaffirmed 7'
        WHEN pah.xcptn_typ_cd IN ('O','Q','R','S','X','Y') THEN TRIM(pah.xcptn_typ_cd) || ': N/A'
        WHEN pah.xcptn_typ_cd = ('QA') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Primary filed Petition 11'
        WHEN pah.xcptn_typ_cd = ('QB') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Primary filed Discharged Non Reaffirmed 11'
        WHEN pah.xcptn_typ_cd = ('QE') THEN TRIM(pah.xcptn_typ_cd) || ': All parties filed (includes single ownership) Petition 11'
        WHEN pah.xcptn_typ_cd = ('QF') THEN TRIM(pah.xcptn_typ_cd) || ': All parties filed (includes single ownership) Discharged Non Reaffirmed 11'
        WHEN pah.xcptn_typ_cd = ('QI') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Petition 11'
        WHEN pah.xcptn_typ_cd = ('QJ') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Discharged Non Reaffirmed 11'
        WHEN pah.xcptn_typ_cd = ('RA') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Primary filed Petition 12'
        WHEN pah.xcptn_typ_cd = ('RB') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Primary filed Discharged Non Reaffirmed 12'
        WHEN pah.xcptn_typ_cd = ('RE') THEN TRIM(pah.xcptn_typ_cd) || ': All parties filed (includes single ownership) Petition 12'
        WHEN pah.xcptn_typ_cd = ('RF') THEN TRIM(pah.xcptn_typ_cd) || ': All parties filed (includes single ownership) Discharged Non Reaffirmed 12'
        WHEN pah.xcptn_typ_cd = ('RI') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Petition 12'
        WHEN pah.xcptn_typ_cd = ('RJ') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Discharged Non Reaffirmed 12'
        WHEN pah.xcptn_typ_cd = ('SA') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Petition 13'
        WHEN pah.xcptn_typ_cd = ('SB') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Primary filed Discharged Non Reaffirmed 13'
        WHEN pah.xcptn_typ_cd = ('SE') THEN TRIM(pah.xcptn_typ_cd) || ': All parties filed (includes single ownership) Petition 13'
        WHEN pah.xcptn_typ_cd = ('SF') THEN TRIM(pah.xcptn_typ_cd) || ': All parties filed (includes single ownership) Discharged Non Reaffirmed 13'
        WHEN pah.xcptn_typ_cd = ('SI') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Petition 13'
        WHEN pah.xcptn_typ_cd = ('SJ') THEN TRIM(pah.xcptn_typ_cd) || ': Joint Acct Cobuyer filed Discharged Non Reaffirmed 13'
        else ''
        end as rejected_brd_reason,
    case
        when rejected_data_reason <> '' then 1 else 0
        end as rejected_data,
    case
        when fx.form_xcptn <> '0' then fx.form_xcptn_reason
        else ''
        end as rejected_data_reason,
    case
        when rejected_brd = 1 then rejected_brd_reason
        when rejected_data = 1 then rejected_data_reason
        else ''
        end as rejected_final_reason,
    case
        when rejected_brd = 0 and is_pending = 0 then 1
        else 0
        end as create_pdf,
    '8722' as form_number,
    f.paper_size as paper_size,
    f.num_sides as num_sides,
    case
        when rejected_brd = 0 and rejected_data = 1 then 1
        else 0
        end as is_pending,
    '' as pending_group
from
    forms_views.form_calendar as fc0
        inner join
    forms_views.form_calendar as fc
    on
        fc.us_forms_data_dt = fc0.prior_business_day
            and fc.forms_run_day='1'
        inner join
    forms_views.acct_delqy_hist as adh
    on
        adh.acct_delq_hist_strt_dt = fc0.prior_business_day
            and coalesce(adh.days_past_due_qty, 0) between 31 and 41
            + cast(fc0.prior_business_day - fc.cal_date as integer)
--            and coalesce(adh.days_past_due_qty, 0) >1 + cast(fc0.prior_business_day - fc.cal_date as integer)
        inner join
    forms_views.pfolio_acct_hist as pah
    on
        pah.acct_nmbr = adh.acct_nmbr
            and fc0.prior_business_day between pah.pfolio_acct_hist_strt_dt and pah.pfolio_acct_hist_end_dt
            and pah.ctrct_stat_hist_name = 'ACTIVE'
            and pah.lob_cd = 'RL'
        inner join
    forms_views.acct_cust_nppi as ctrct_buyr
    on
        ctrct_buyr.acct_nmbr = pah.acct_nmbr
            and ctrct_buyr.relshp_typ_cd = '1'
            and fc0.prior_business_day between ctrct_buyr.acct_cust_strt_dt and ctrct_buyr.acct_cust_end_dt
            and ctrct_buyr.cust_nmbr = pah.cust_nmbr
            and ctrct_buyr.addr_nmbr = pah.cust_addr_nmbr
            and ctrct_buyr.state_cd = 'MA'
        inner join
    forms_views.pfolio_acct_vhcl_hist as pavh
    on
        pavh.acct_nmbr = adh.acct_nmbr
            and fc.prior_business_day between pavh.pfolio_acct_vhcl_hist_strt_dt and pavh.pfolio_acct_vhcl_hist_end_dt
        inner join
    forms_views.orh as orh
    on
        orh.zone_nmbr = pah.zone_nmbr
            and orh.cntry_cd = 'us'
            and fc0.prior_business_day between orh.orh_strt_dt and orh.orh_end_dt
        inner join
    forms_views.forms as f
    on
        f.form = '8722'
            and (f.lob_cd = pah.lob_cd or coalesce(f.lob_cd, '') = '')
--            and pao.acct_ctrct_dt between f.forms_strt_dt and f.forms_end_dt
        inner join
    (
        select row_number() over(order by calendar_date) - 1 as is_cobuyer
        from sys_calendar.calendar
        where calendar_date between date-1 and date
    ) as ic
    on
        1 = 1
        left join
    forms_views.acct_cust_nppi as ctrct_cobuyr
    on
        ctrct_cobuyr.acct_nmbr = pah.acct_nmbr
            and fc0.prior_business_day between ctrct_cobuyr.acct_cust_strt_dt and ctrct_cobuyr.acct_cust_end_dt
            and ctrct_cobuyr.cust_nmbr = pah.rlatd_cust_nmbr_1
            and ctrct_cobuyr.addr_nmbr = pah.rlatd_cust_addr_nmbr_1
            and ctrct_cobuyr.relshp_typ_cd = pah.rlatd_cust_relshp_typ_1
            and ctrct_cobuyr.state_cd = 'MA'
        left join
    forms_views.pfolio_acct_eot_hist as paeh
    on
        paeh.acct_nmbr = pah.acct_nmbr
            and fc0.prior_business_day between paeh.pfolio_acct_eot_hist_strt_dt and paeh.pfolio_acct_eot_hist_end_dt

        left outer join forms_db.form_xcptn as fx
                        on fx.form_num = '8722'
                            and fx.form_xcptn =
                                (
                                    case
                                        when ctrct_buyr.full_name = ctrct_cobuyr.full_name then '1' else '0'
                                        end
                                    )

where
    fc0.cal_date = :prundt
  and coalesce(paeh.trmtn_typ_cd, '') = ''
  and ( (paeh.repo_dt is null) or not (paeh.repo_dt is not null and adh.delqy_catgy_cd = 'R' and adh.worklist_que_cd = 60) )
  and ( (ic.is_cobuyer = 0) or (ic.is_cobuyer = 1 and buyr_full_name is not null and cobuyer_has_buyer_address = 0) )
  and NOT EXISTS
    (SELECT 1
     FROM forms_views.daily_forms df
     WHERE df.AccountNum = adh.Acct_Nmbr
       AND df.FormNum = '8722'
       AND df.Status = 'P'
       AND df.CCHStatus = 'Q'
       AND df.ProcessedDate >= pah.ctrct_stat_dt)
;
end;
-----------------------------------------------------
----------------------- MACRO -----------------------
-----------------------------------------------------

replace macro forms_db.alc_form8722
(
    prundt char(10)
) as (
select
    run_date,
    bus_date,
    acct_nmbr,
    is_cobuyer,
    buyr_full_name,
    buyr_addr_line_1,
    buyr_city_name,
    buyr_state_cd,
    buyr_postl_cd,
    buyr_csz,
    cobuyr_full_name,
    cobuyr_addr_line_1,
    cobuyr_city_name,
    cobuyr_state_cd,
    cobuyr_postl_cd,
    cobuyr_csz,
    cobuyer_has_buyer_address,
    repo_dt,
    trmtn_typ_cd,
    fraud_typ_cd,
    xcptn_typ_cd,
    delqy_catgy_cd,
    worklist_que_cd,
    days_past_due_qty,
    days_past_due_1_date,
    payment_due_date,
    payment_amount,
    lob_cd,
    first_class,
    certified,
    mail_type,
    license_reqd,
    send_to,
    Ctrct_Stat_Dt,
    vhcl_make,
    vhcl_modl,
    vhcl_my,
    vin,
    loctn_cd,
    barcode,
    company_name,
    company_address,
    company_phone,
    rejected_brd,
    rejected_brd_reason,
    rejected_data,
    rejected_data_reason,
    rejected_final_reason,
    create_pdf,
    form_number,
    paper_size,
    num_sides,
    is_pending,
    pending_group,
    cease_desist_cd
from
    forms_views.alc_form8722_hist_nppi
where
    run_date = :prundt
    and bus_date is not null
order by
    acct_nmbr, is_cobuyer
;
);

-------------------------------------------
replace macro forms_db.alc_form8722_acct_nmbr
(
    prundt char(10),
    pacct_nmbr char(10),
    pis_cobuyer integer
) as (
select
    run_date,
    bus_date,
    acct_nmbr,
    is_cobuyer,
    buyr_full_name,
    buyr_addr_line_1,
    buyr_city_name,
    buyr_state_cd,
    buyr_postl_cd,
    buyr_csz,
    cobuyr_full_name,
    cobuyr_addr_line_1,
    cobuyr_city_name,
    cobuyr_state_cd,
    cobuyr_postl_cd,
    cobuyr_csz,
    cobuyer_has_buyer_address,
    repo_dt,
    trmtn_typ_cd,
    fraud_typ_cd,
	xcptn_typ_cd,
    delqy_catgy_cd,
    worklist_que_cd,
    days_past_due_qty,
    days_past_due_1_date,
	payment_due_date,
	payment_amount,
    lob_cd,
    first_class,
    certified,
    mail_type,
    license_reqd,
    send_to,
	Ctrct_Stat_Dt,
	vhcl_make,
    vhcl_modl,
    vhcl_my,
    vin,
    loctn_cd,
    barcode,
    company_name,
    company_address,
    company_phone,
    rejected_brd,
    rejected_brd_reason,
    rejected_data,
    rejected_data_reason,
    rejected_final_reason,
    create_pdf,
    form_number,
    paper_size,
    num_sides,
    is_pending,
    pending_group,
	cease_desist_cd
from
    forms_views.alc_form8722_hist_nppi
where
    run_date = :prundt
    and bus_date is not null
    and acct_nmbr = :pacct_nmbr
    and is_cobuyer = :pis_cobuyer
order by
    acct_nmbr, is_cobuyer
;
);

----------------------------------------------------
----------------------- VIEW -----------------------
----------------------------------------------------

replace view forms_views.alc_form8722_hist_nppi
as
locking row for access
select
    run_date,
    bus_date,
    acct_nmbr,
    is_cobuyer,
    buyr_full_name,
    buyr_addr_line_1,
    buyr_city_name,
    buyr_state_cd,
    buyr_postl_cd,
    buyr_csz,
    cobuyr_full_name,
    cobuyr_addr_line_1,
    cobuyr_city_name,
    cobuyr_state_cd,
    cobuyr_postl_cd,
    cobuyr_csz,
    cobuyer_has_buyer_address,
    repo_dt,
    trmtn_typ_cd,
    fraud_typ_cd,
    xcptn_typ_cd,
    delqy_catgy_cd,
    worklist_que_cd,
    days_past_due_qty,
    days_past_due_1_date,
    payment_due_date,
    payment_amount,
    lob_cd,
    first_class,
    certified,
    mail_type,
    license_reqd,
    send_to,
    Ctrct_Stat_Dt,
    vhcl_make,
    vhcl_modl,
    vhcl_my,
    vin,
    loctn_cd,
    barcode,
    company_name,
    company_address,
    company_phone,
    rejected_brd,
    rejected_brd_reason,
    rejected_data,
    rejected_data_reason,
    rejected_final_reason,
    create_pdf,
    form_number,
    paper_size,
    num_sides,
    is_pending,
    pending_group,
    cease_desist_cd
from
    forms_db.alc_form8722_hist_nppi;