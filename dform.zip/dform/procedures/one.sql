----------------------------------------------------------------
----------------------- STORED PROCEDURE -----------------------
----------------------------------------------------------------

REPLACE PROCEDURE forms_db.
alc_form9012_hist

(IN pRUNDT DATE)

BEGIN
DECLARE pBUSDT DATE;
DECLARE pMINDT DATE;
DECLARE pMAXDT DATE;

DELETE FROM forms_db.alc_form9012_hist_nppi
WHERE run_date = :pRUNDT and bus_date IS NOT NULL;

SELECT
    prior_business_day
FROM
    FORMS_views.form_calendar
WHERE
    cal_date = :pRUNDT
    INTO
  :pBUSDT;

SELECT
    MIN(cal_date) AS min_date, MAX(cal_date) AS max_date
FROM
    forms_views.form_calendar
WHERE
    us_forms_data_dt =:pBUSDT
    INTO
    :pMINDT, :pMAXDT;

INSERT INTO forms_db.alc_form9012_hist_nppi
SELECT
    :pRUNDT AS run_Date,  :pBUSDT AS bus_date, faw_ev.acct_nmbr as acct_nmbr,
    case
        when ic.is_cobuyer = 0 then
            trim(ctrct_buyr.full_name)
        else
            trim(ctrct_cobuyr.full_name)
        end as buyr_full_name,
    case
        when ic.is_cobuyer = 0 then
            case
                when trim(coalesce(ctrct_buyr.addr_line_2, '')) <> '' then trim(ctrct_buyr.addr_line_1) || ', ' || trim(ctrct_buyr.addr_line_2)
                else trim(ctrct_buyr.addr_line_1)
                end
        else
            case
                when trim(coalesce(ctrct_cobuyr.addr_line_2, '')) <> '' then trim(ctrct_cobuyr.addr_line_1) || ', ' || trim(ctrct_cobuyr.addr_line_2)
                else trim(ctrct_cobuyr.addr_line_1)
                end
        end as buyr_addr_line_1,
    case
        when ic.is_cobuyer = 0 then trim(ctrct_buyr.city_name)
        else trim(ctrct_cobuyr.city_name)
        end as buyr_city_name,
    case
        when ic.is_cobuyer = 0 then trim(upper(ctrct_buyr.state_cd))
        else trim(upper(ctrct_cobuyr.state_cd))
        end as buyr_state_cd,
    case
        when ic.is_cobuyer = 0 then
            case
                when
                    character_length(trim(ctrct_buyr.postl_cd)) = 9
                        and position('-' in ctrct_buyr.postl_cd) = 0
                    then substr(ctrct_buyr.postl_cd, 1, 5) || '-' || substr(ctrct_buyr.postl_cd, 6, 4)
                else trim(ctrct_buyr.postl_cd)
                end
        else
            case
                when
                    character_length(trim(ctrct_cobuyr.postl_cd)) = 9
                        and position('-' in ctrct_cobuyr.postl_cd) = 0
                    then substr(ctrct_cobuyr.postl_cd, 1, 5) || '-' || substr(ctrct_cobuyr.postl_cd, 6, 4)
                else trim(ctrct_cobuyr.postl_cd)
                end
        end as buyr_postl_cd,
    buyr_city_name || ', ' || buyr_state_cd || ' ' || buyr_postl_cd as buyr_csz,
    case
        when ic.is_cobuyer = 0 then trim(coalesce(ctrct_cobuyr.full_name, ''))
        else ''
        end as cobuyr_full_name,
    '' as cobuyr_addr_line_1,
    '' as cobuyr_city_name,
    '' as cobuyr_state_cd,
    '' as cobuyr_postl_cd,
    '' as cobuyr_csz,
    case
        when
            trim(coalesce(ctrct_buyr.addr_line_1, '')) = trim(coalesce(ctrct_cobuyr.addr_line_1, ''))
                and trim(coalesce(ctrct_buyr.addr_line_2, '')) = trim(coalesce(ctrct_cobuyr.addr_line_2, ''))
                and trim(coalesce(ctrct_buyr.city_name, '')) = trim(coalesce(ctrct_buyr.city_name, ''))
                and trim(coalesce(ctrct_buyr.state_cd, '')) = trim(coalesce(ctrct_cobuyr.state_cd, ''))
            then 1
        else 0
        end as cobuyer_has_buyer_address,
    faw_ev.Event_Proc_Cd as  event_proc_cd,
    faw_ev.Event_Reas_Cd as event_reas_cd,
    faw_reas.reas_desc,
    faw_re9012.reas_desc as form_desc,
    1 as create_pdf,
    '9012' as form_number,
    null as paper_size,
    'RL' as lob_cd,
    'R' as mail_type,
    1 as first_class,
    0 as certified,
    'B' as send_to,
    faw_ev.acct_nmbr || cast((current_timestamp (format 'yyyymmddhhmi')) as character(12)) as barcode,
    ic.is_cobuyer as is_cobuyer,
    0 as is_pending,
    null as pending_group,
    0 as days_in_pending,
    1 as num_sides,
    TRIM(pavh.vin) AS vin,
    '0' || orh.area_nmbr || orh.reg_nmbr || orh.zone_nmbr as loctn_cd

FROM
    SPOT_BVAL.faw_event as faw_ev

        left join
    forms_db.faw_reas_descform9012 as faw_re9012
    on
        faw_re9012.event_proc_Cd='48,000'
            and faw_re9012.event_reas_Cd=faw_ev.Event_Reas_Cd

        inner join
    forms_views.pfolio_acct_hist as pah
    on
        pah.acct_nmbr = faw_ev.acct_nmbr
            and :pBUSDT between pah.pfolio_acct_hist_strt_dt and pah.pfolio_acct_hist_end_dt
            and pah.ctrct_stat_hist_name = 'ACTIVE'
            and pah.lob_cd = 'RL'

        inner join
    forms_views.acct_cust_nppi as ctrct_buyr
    on
        ctrct_buyr.acct_nmbr = pah.acct_nmbr
            and ctrct_buyr.relshp_typ_cd = '1'
            and :pBUSDT between ctrct_buyr.acct_cust_strt_dt and ctrct_buyr.acct_cust_end_dt
            and ctrct_buyr.cust_nmbr = pah.cust_nmbr
            and ctrct_buyr.addr_nmbr = pah.cust_addr_nmbr

        inner join
    (
        select
            row_number() over(order by calendar_date) - 1 as is_cobuyer
        from
            sys_calendar.calendar
        where
            calendar_date between date-1 and date
    ) as ic
    on
        1 = 1
        INNER JOIN
    forms_views.pfolio_acct_vhcl_hist AS pavh
    ON
        pavh.acct_nmbr = pah.acct_nmbr
            AND :pBUSDT BETWEEN pavh.pfolio_acct_vhcl_hist_strt_dt AND pavh.pfolio_acct_vhcl_hist_end_dt
        left join
    forms_views.acct_cust_nppi as ctrct_cobuyr
    on
        ctrct_cobuyr.acct_nmbr = pah.acct_nmbr
            and :pBUSDT between ctrct_cobuyr.acct_cust_strt_dt and ctrct_cobuyr.acct_cust_end_dt
            and ctrct_cobuyr.cust_nmbr = pah.rlatd_cust_nmbr_1
            and ctrct_cobuyr.addr_nmbr = pah.rlatd_cust_addr_nmbr_1
            and ctrct_cobuyr.relshp_typ_cd = pah.rlatd_cust_relshp_typ_1

        LEFT OUTER JOIN
    forms_views.orh AS orh
    ON
        orh.zone_nmbr = pah.zone_nmbr
            AND orh.zone_nmbr BETWEEN '200' AND '323'
            AND orh.zone_nmbr <> '318'
            AND :pBUSDT BETWEEN orh.orh_strt_dt AND orh.orh_end_dt

        left join
    SPOT_BVAL.faw_reas as faw_reas
    on
        faw_reas.Proc_Cd='48,000' and faw_reas.Reas_Cd=faw_ev.Event_Reas_Cd
    QUALIFY ROW_NUMBER() OVER (PARTITION BY faw_ev.Acct_Nmbr, is_cobuyer ORDER BY Event_last_Updated DESC) = 1

WHERE
    faw_ev.Event_Reas_Cd in ('89,010','89,020','89,030','89,040','89,050','89,060','89,070','89,080','89,090')
  and faw_ev.Event_Proc_Cd='48,000'
  and faw_ev.Event_last_updated between :pMINDT  and :pMAXDT
  and buyr_full_name is not null
  and buyr_addr_line_1 is not null
  and buyr_city_name is not null
  and buyr_state_cd is not null
  and buyr_postl_cd is not null
  and buyr_csz is not null
  and NOT EXISTS
    (SELECT 1 --, AccountNum, ProcessedDate
    FROM forms_views.daily_forms df
    WHERE df.AccountNum = faw_ev.acct_nmbr AND df.FormNum = '9012' AND df.Status = 'P'
  AND df.WolverineStatus = 'S' AND df.ProcessedDate >= (:pRunDt - 1)
    )
;
END;

-----------------------------------------------------
----------------------- MACRO -----------------------
-----------------------------------------------------

replace macro forms_db.alc_form9012
(prundt char(10)) as (
select
    run_date,
    bus_date,
	acct_nmbr,
    buyr_full_name,
    buyr_addr_line_1,
    buyr_city_name,
    buyr_state_cd,
    buyr_postl_cd,
    buyr_csz,
    cobuyr_full_name,
    cobuyr_addr_line_1,
    cobuyr_city_name,
    cobuyr_state_cd,
    cobuyr_postl_cd,
    cobuyr_csz,
    cobuyer_has_buyer_address,
    event_proc_cd,
    event_reas_cd ,
    reas_desc,
    form_desc,
	create_pdf,
    form_number,
    paper_size,
	lob_cd,
	mail_type,
	send_to,
	barcode,
	is_cobuyer,
	is_pending,
	pending_group,
    days_in_pending,
    num_sides,
	vin,
	loctn_cd
from
    forms_views.alc_form9012_hist_nppi
where
    run_date = :prundt
    and bus_date is not null
order by
    acct_nmbr;
);
-------------------------------------------
replace macro forms_db.alc_form9012_acct_nmbr
(
	prundt char(10),
    pacct_nmbr char(10)
) as (
select
    run_date,
    bus_date,
	acct_nmbr,
    buyr_full_name,
    buyr_addr_line_1,
    buyr_city_name,
    buyr_state_cd,
    buyr_postl_cd,
    buyr_csz,
    cobuyr_full_name,
    cobuyr_addr_line_1,
    cobuyr_city_name,
    cobuyr_state_cd,
    cobuyr_postl_cd,
    cobuyr_csz,
    cobuyer_has_buyer_address,
    event_proc_cd,
    event_reas_cd ,
    reas_desc,
    form_desc,
	create_pdf,
    form_number,
    paper_size,
	lob_cd,
	mail_type,
	send_to,
	barcode,
	is_cobuyer,
	is_pending,
    pending_group,
    days_in_pending,
    num_sides,
	vin,
	loctn_cd
from
    forms_views.alc_form9012_hist_nppi
where
    run_date = :prundt
    and bus_date is not null
	and acct_nmbr = :pacct_nmbr
order by
    acct_nmbr;
);

----------------------------------------------------
----------------------- VIEW -----------------------
----------------------------------------------------

replace view FORMS_VIEWS.alc_form9012_hist_nppi
as
locking row for access
select
    run_date,
    bus_date,
    acct_nmbr,
    buyr_full_name,
    buyr_addr_line_1,
    buyr_city_name,
    buyr_state_cd,
    buyr_postl_cd,
    buyr_csz,
    cobuyr_full_name,
    cobuyr_addr_line_1,
    cobuyr_city_name,
    cobuyr_state_cd,
    cobuyr_postl_cd,
    cobuyr_csz,
    cobuyer_has_buyer_address,
    event_proc_cd,
    event_reas_cd ,
    reas_desc,
    form_desc,
    create_pdf,
    form_number,
    paper_size,
    lob_cd,
    mail_type,
    send_to,
    barcode,
    is_cobuyer,
    is_pending,
    pending_group,
    days_in_pending,
    num_sides,
    vin,
    loctn_cd
from
    forms_db.alc_form9012_hist_nppi;