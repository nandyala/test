@echo off
REM Compiles AiWriter with the C# compiler that ships with Windows (no install needed).
setlocal
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" (
  echo Could not find csc.exe under %WINDIR%\Microsoft.NET\
  exit /b 1
)

if not exist bin mkdir bin
"%CSC%" /nologo /target:winexe /out:bin\AiWriter.exe ^
  /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll ^
  /r:System.Net.Http.dll /r:System.Web.Extensions.dll ^
  Program.cs
if errorlevel 1 (
  echo BUILD FAILED
  exit /b 1
)

if not exist bin\config.json copy /y config.json bin\config.json >nul
echo.
echo Built: bin\AiWriter.exe   (edit bin\config.json to configure providers)
endlocal
