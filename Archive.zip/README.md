# AI Writer

A tiny Windows desktop tool (single C# file, no dependencies) for writing emails, refining text and converting
text to Confluence wiki markup, using **Azure OpenAI (GPT)** or **Claude** — chosen from a dropdown, defined in `config.json`.

## Build (no install required)

Windows includes the C# compiler with .NET Framework 4.x. Double-click or run:

    build.bat

Output: `bin\AiWriter.exe` plus `bin\config.json`. Run the exe directly - nothing is installed.
(If your policy blocks running unsigned exes from some folders, build to a folder you're allowed to run from.)

Manual compile equivalent:

    %WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe /target:winexe /out:AiWriter.exe ^
      /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Net.Http.dll /r:System.Web.Extensions.dll Program.cs

## Configure (`bin\config.json`)

Edit it any time - restart the app to reload. You can pass a different path as the first argument: `AiWriter.exe C:\path\my.json`.

### Providers
| field | applies to | notes |
|---|---|---|
| `name` | all | shown in dropdown |
| `type` | all | `azure-openai` or `anthropic` |
| `endpoint` | all | Azure: `https://<resource>.openai.azure.com`. Claude: `https://api.anthropic.com` (or your Anthropic-compatible gateway, e.g. Azure-hosted Claude endpoint) |
| `deployment` | azure-openai | your deployment name |
| `apiVersion` | azure-openai | e.g. `2024-10-21` |
| `model` | anthropic | e.g. `claude-sonnet-4-5` - use whatever model ID your account has |
| `apiKeyEnv` | all | name of an environment variable holding the key (preferred) |
| `apiKey` | all | key in plain text (fallback - keep the file private) |
| `maxTokens` | all | default 4096 |
| `tokenParam` | azure-openai | set to `max_completion_tokens` for newer models (o-series / GPT-5) that reject `max_tokens` |
| `temperature` | all | optional; omit for models that don't support it |

Set a key without admin rights: `setx ANTHROPIC_API_KEY "sk-ant-..."` (then restart the app).

### Actions (prompts)
Each action is `{ "name": ..., "system": ... }`. Add your own (e.g. "Reply politely", "Translate to German",
"Jira markup") by adding another entry - no recompile needed.

## Use
1. Pick provider + action, paste text in **Input**, optional extra instruction (e.g. "friendly tone, under 100 words").
2. **Ctrl+Enter** or *Run*. Result appears in **Output** (editable). *Copy output*, or *Output -> Input* to chain actions.

## Notes
- Uses your Windows proxy settings and login automatically (typical corporate proxy).
- Errors from the API (bad key, wrong deployment, 429) are shown in the Output box verbatim.
- Code is C# 5 (what the built-in compiler supports) - avoid `$""` strings and `?.` when editing, or use a newer compiler.
- Your text is sent to the configured API - follow your organisation's data policy.
