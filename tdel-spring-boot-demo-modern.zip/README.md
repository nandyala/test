# Td EL + Spring Boot Demo (modernized)

- Spring Boot 3.3.x, Java 17
- H2 + Spring Data JPA
- **ANTLR 4.5.3** (to match legacy API in the grammar / impl)
- **Thread-safe** expression evaluations via per-request `ResolverContext`
- **Shared parse-tree cache** using Caffeine (5000 entries, 30m idle TTL)
- **Per-context result/variable cache** inside the legacy resolver (Ehcache TTL 300s)

## Run
```bash
./mvnw spring-boot:run
# open http://localhost:8080
```

## Thread safety
- A new `ResolverContext` is created per request (no shared mutable state).
- The ANTLR parse tree is cached and shared read-only across threads.
- The EL `EvalVisitor` is created per evaluation.
