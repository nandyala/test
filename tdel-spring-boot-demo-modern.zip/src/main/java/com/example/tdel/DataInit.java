package com.example.tdel;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.math.BigDecimal;
import java.time.LocalDate;

@Configuration
public class DataInit {
    @Bean
    CommandLineRunner seed(CustomerRepository customers, AccountDetailRepository accounts) {
        return args -> {
            Customer a = new Customer();
            a.setFirstName("Ada"); a.setLastName("Lovelace");
            a.setEmail("ada@example.com"); a.setAge(28);
            a.setCreatedAt(LocalDate.of(2024, 1, 15));

            AccountDetail ad = new AccountDetail();
            ad.setAccountDetailCode("A-1001");
            ad.setAccountAge(4);
            ad.setBalance(new BigDecimal("12345.67"));
            ad.setOpenedAt(LocalDate.of(2021, 6, 1));
            ad.setCustomer(a);
            a.setAccountDetail(ad);
            customers.save(a);

            Customer b = new Customer();
            b.setFirstName("Grace"); b.setLastName("Hopper");
            b.setEmail("grace@example.com"); b.setAge(37);
            b.setCreatedAt(LocalDate.of(2023, 8, 20));

            AccountDetail bd = new AccountDetail();
            bd.setAccountDetailCode("A-1002");
            bd.setAccountAge(2);
            bd.setBalance(new BigDecimal("9876.54"));
            bd.setOpenedAt(LocalDate.of(2022, 9, 15));
            bd.setCustomer(b);
            b.setAccountDetail(bd);
            customers.save(b);
        };
    }
}
