package com.example.tdel;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final CustomerRepository customers;
    private final ElEvaluationService evaluator;

    public ApiController(CustomerRepository customers, ElEvaluationService evaluator) {
        this.customers = customers;
        this.evaluator = evaluator;
    }

    @GetMapping("/customers")
    public List<Customer> listCustomers() {
        return customers.findAll();
    }

    @PostMapping("/evaluate")
    public ResponseEntity<?> evaluate(@RequestBody EvaluateRequest req) {
        Customer c = customers.findById(req.customerId).orElse(null);
        if (c == null) { return ResponseEntity.badRequest().body("Unknown customerId: " + req.customerId); }
        try {
            Object result = evaluator.evaluateForCustomer(c, req.expression);
            return ResponseEntity.ok(new EvaluateResponse(result));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body("Evaluation error: " + ex.getMessage());
        }
    }

    static class EvaluateResponse {
        public Object result;
        public String resultType;
        public EvaluateResponse(Object result) {
            this.result = result;
            this.resultType = (result == null)? "null" : result.getClass().getName();
        }
    }
}
