package com.example.tdel;
public class EvaluateRequest {
    public Long customerId;
    public String expression;
}
