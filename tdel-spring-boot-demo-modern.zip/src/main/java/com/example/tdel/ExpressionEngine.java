package com.example.tdel;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.tdstrategy.el.antlr.TdElLexer;
import com.tdstrategy.el.antlr.TdElParser;
import com.tdstrategy.el.impl.EvalVisitor;
import com.tdstrategy.el.impl.ResolverContext;
import com.tdstrategy.el.impl.TdElValue;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Objects;

/**
 * Thread-safe expression engine with a shared parse-tree cache.
 * Each evaluation builds a fresh ResolverContext so per-request variables
 * are isolated across threads.
 */
@Component
public class ExpressionEngine {

    private final Cache<String, ParseTree> parseCache = Caffeine.newBuilder()
            .maximumSize(5000)
            .expireAfterAccess(Duration.ofMinutes(30))
            .build();

    public TdElValue evaluate(ResolverContext ctx, String expression) {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(expression, "expression");

        // Lazily parse or reuse the cached parse tree (thread-safe)
        ParseTree tree = parseCache.get(expression, expr -> {
            CharStream input = new ANTLRInputStream(expr);
            TdElLexer lexer = new TdElLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            TdElParser parser = new TdElParser(tokens);
            lexer.removeErrorListeners();
            parser.removeErrorListeners();
            return parser.entry();
        });

        EvalVisitor visitor = new EvalVisitor();
        visitor.setResolvers(ctx);
        return visitor.visit(tree);
    }
}
