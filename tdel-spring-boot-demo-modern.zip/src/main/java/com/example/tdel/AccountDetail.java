package com.example.tdel;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class AccountDetail {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountDetailCode;
    private Integer accountAge;
    private BigDecimal balance;
    private LocalDate openedAt;

    @OneToOne
    @JoinColumn(name = "customer_id")
    @JsonBackReference
    private Customer customer;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getAccountDetailCode() { return accountDetailCode; }
    public void setAccountDetailCode(String accountDetailCode) { this.accountDetailCode = accountDetailCode; }
    public Integer getAccountAge() { return accountAge; }
    public void setAccountAge(Integer accountAge) { this.accountAge = accountAge; }
    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }
    public LocalDate getOpenedAt() { return openedAt; }
    public void setOpenedAt(LocalDate openedAt) { this.openedAt = openedAt; }
    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer customer) { this.customer = customer; }
}
