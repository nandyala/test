package com.example.tdel;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AccountDetailRepository extends JpaRepository<AccountDetail, Long> { }