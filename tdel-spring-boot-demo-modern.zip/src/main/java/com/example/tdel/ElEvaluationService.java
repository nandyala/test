package com.example.tdel;

import org.springframework.stereotype.Service;
import com.tdstrategy.el.impl.ResolverContext;
import com.tdstrategy.el.impl.TdElValue;

@Service
public class ElEvaluationService {

    private final ExpressionEngine engine;

    public ElEvaluationService(ExpressionEngine engine) {
        this.engine = engine;
    }

    public Object evaluateForCustomer(Customer customer, String expression) {
        ResolverContext ctx = new ResolverContext();
        // Enable internal variable/expression cache per context (TTL 300s)
        ctx.enableCache(300);
        ctx.addValue("customer", customer);
        if (customer.getAccountDetail() != null) {
            ctx.addValue("accountDetail", customer.getAccountDetail());
            ctx.addValue("account", customer);
        }
        TdElValue val = engine.evaluate(ctx, expression);
        return (val == null) ? null : val.getValue();
    }
}
