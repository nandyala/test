package com.tdstrategy.el.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.*;

import java.math.BigDecimal;
import java.math.BigInteger;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tdstrategy.el.annotation.TdContextParam;
import com.tdstrategy.el.exception.NotSupportException;
import com.tdstrategy.el.impl.TdElValue;


/**
 * Created with IntelliJ IDEA. User: rojer Date: 6/19/13 Time: 3:37 PM To change this template use File | Settings |
 * File Templates.
 *
 * @author   Rojer Luo
 * @version  $Revision$, $Date$
 */
public class FunctionUtil {
  //~ Static fields/initializers ---------------------------------------------------------------------------------------

  private static Logger                                                logger     = LoggerFactory.getLogger(
      FunctionUtil.class);
  private static ConcurrentHashMap<Class, NoCaseHashMap<List<Method>>> classCache =
    new ConcurrentHashMap<Class, NoCaseHashMap<List<Method>>>();

  //~ Methods ----------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   fromClazz  DOCUMENT ME!
   * @param   toClazz    DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public static boolean canCastTo(Class fromClazz, Class toClazz) {
    if ((fromClazz == null) || toClazz.equals(fromClazz) || fromClazz.isAssignableFrom(toClazz)) {
      return true;
    } else {
      if (toClazz.equals(BigDecimal.class)) {
        if (fromClazz.equals(BigInteger.class)
              || fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)
              || fromClazz.equals(Double.class)
              || fromClazz.equals(double.class)
              || fromClazz.equals(Float.class)
              || fromClazz.equals(float.class)) {
          return true;
        }
      } else if (toClazz.equals(BigInteger.class)) {
        if (fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)) {
          return true;
        }
      } else if (toClazz.equals(Long.class) || toClazz.equals(long.class)) {
        if (fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)) {
          return true;
        }
      } else if (toClazz.equals(Integer.class) || toClazz.equals(int.class)) {
        if (fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)) {
          return true;
        } else if (fromClazz.equals(Long.class) || fromClazz.equals(long.class)) {
          // add support for force casting
          return true;
        }
      } else if (toClazz.equals(Double.class) || toClazz.equals(double.class)) {
        if (fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)
              || fromClazz.equals(Float.class)
              || fromClazz.equals(float.class)
              || fromClazz.equals(Double.class)
              || fromClazz.equals(double.class)) {
          return true;
        }
      } else if (toClazz.equals(Float.class) || toClazz.equals(float.class)) {
        if (fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)
              || fromClazz.equals(Float.class)
              || fromClazz.equals(float.class)
              || fromClazz.equals(Double.class)
              || fromClazz.equals(double.class)) {
          return true;
        }
      } else if (toClazz.equals(Boolean.class) || toClazz.equals(boolean.class)) {
        if (fromClazz.equals(Boolean.class) || fromClazz.equals(boolean.class)) {
          return true;
        }
      } else if (toClazz.equals(String.class) || toClazz.equals(Object.class)) {
        return true;
      } // end if-else

    } // end if-else

    return false;
  } // end method canCastTo

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   formalParams  DOCUMENT ME!
   * @param   actualParams  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public static int checkParams(Class[] formalParams, Class[] actualParams) {
    if ((formalParams == null) && (actualParams == null)) {
      return 0;
    }

    if ((formalParams == null) && (actualParams != null)) {
      return 9999;
    }

    if ((formalParams != null) && (actualParams == null)) {
      return 9999;
    }

    int matchPoint = 0;

    // to check if the formal Params are array
    if ((formalParams != null) && (formalParams.length == 1) && formalParams[0].isArray()) {
      String clsName = formalParams[0].getName();

      Class requireCls = getClassFromArrayName(clsName);

      if (requireCls == null) {
        return 9999;
      }

      for (int i = 0; i < actualParams.length; i++) {
        if (requireCls.equals(actualParams[i])) {
          continue;
        } else if (canCastTo(actualParams[i], requireCls)) {
          matchPoint += getMatchPoint(actualParams[i], requireCls);
        } else {
          return 9999;
        }
      }

      return matchPoint;
    } // end if


    if ((formalParams != null) && (formalParams.length == 0) && (actualParams.length == 0)) {
      return 0;
    } else if ((formalParams != null) && (formalParams.length != actualParams.length)) {
      if ((formalParams.length > 0) && (formalParams.length < actualParams.length)) {
        if (formalParams[formalParams.length - 1].isArray()) {
          // the last param is array, matching the leading param
          for (int i = 0; i < (formalParams.length - 1); i++) {
            Class requireCls = formalParams[i];

            if (requireCls == null) {
              return 9999;
            }

            if (requireCls.equals(actualParams[i])) {
              continue;
            } else if (canCastTo(actualParams[i], requireCls)) {
              matchPoint += getMatchPoint(actualParams[i], requireCls);
            } else {
              return 9999;
            }
          }

          // matching for array
          int    aryPos  = formalParams.length - 1;
          String clsName = formalParams[aryPos].getName();

          Class requireCls = getClassFromArrayName(clsName);

          if (requireCls == null) {
            return 9999;
          }

          for (int i = aryPos; i < actualParams.length; i++) {
            if (requireCls.equals(actualParams[i])) {
              continue;
            } else if (canCastTo(actualParams[i], requireCls)) {
              matchPoint += getMatchPoint(actualParams[i], requireCls);
            } else {
              return 9999;
            }
          }

          return matchPoint;
        } // end if
      }   // end if

      return 9999;
    } // end if-else

    int j = 0;

    while (j < formalParams.length) {
      if (formalParams[j].equals(actualParams[j])) {
        j++;
      } else if (canCastTo(actualParams[j], formalParams[j])) {
        matchPoint += getMatchPoint(actualParams[j], formalParams[j]);
        j++;
      } else {
        return 9999;
      }
    }

    if (j != formalParams.length) {
      return 9999;
    }

    return matchPoint;
  } // end method checkParams

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   fromObject  DOCUMENT ME!
   * @param   toClazz     DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public static Object doCastTo(Object fromObject, Class toClazz) {
    Object toObject = null;

    if (fromObject != null) {
      if (toClazz.equals(fromObject.getClass()) || toClazz.isAssignableFrom(fromObject.getClass())) {
        toObject = fromObject;
      } else {
        if (toClazz.isArray() && fromObject.getClass().isArray()) {
          Class    componentClass  = toClazz.getComponentType();
          Object[] fromObjectArray = (Object[]) fromObject;
          int      size            = fromObjectArray.length;
          toObject = Array.newInstance(toClazz.getComponentType(), size);

          for (int i = 0; i < size; i++) {
            Array.set(toObject, i, doObjectCast(fromObjectArray[i], componentClass));
          }
        } else if (toClazz.isArray() && fromObject.getClass().equals(ArrayList.class)) {
          Class     componentClass = toClazz.getComponentType();
          ArrayList fromObjectList = (ArrayList) fromObject;
          int       size           = fromObjectList.size();
          toObject = Array.newInstance(toClazz.getComponentType(), size);

          for (int i = 0; i < size; i++) {
            Array.set(toObject, i, doObjectCast(((TdElValue) fromObjectList.get(i)).getValue(), componentClass));
          }
        } else {
          toObject = doObjectCast(fromObject, toClazz);
        } // end if-else
        // end if-else
      }   // end if-else

    } // end if

    return toObject;
  } // end method doCastTo

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   clazz      DOCUMENT ME!
   * @param   fieldName  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NoSuchFieldException  DOCUMENT ME!
   */
  public static Field findField(Class clazz, String fieldName) throws NoSuchFieldException {
    if (clazz == null) {
      logger.error("Class is null.");
      throw new NoSuchFieldException("No class");
    }

    if ((fieldName == null) || fieldName.trim().equals("")) {
      logger.error("Field name is null.");
      throw new NoSuchFieldException("No method name");
    }

    Field field = clazz.getDeclaredField(fieldName);

    return field;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   clazz       DOCUMENT ME!
   * @param   methodName  DOCUMENT ME!
   * @param   args        DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NoSuchMethodException  DOCUMENT ME!
   */
  public static Method findMethod(Class clazz, String methodName, Class[] args) throws NoSuchMethodException {
    return findMethod(clazz, methodName, args, true);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   clazz             DOCUMENT ME!
   * @param   methodName        DOCUMENT ME!
   * @param   args              DOCUMENT ME!
   * @param   checkInheritance  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NoSuchMethodException  DOCUMENT ME!
   */
  public static Method findMethod(Class clazz, String methodName, Class[] args, boolean checkInheritance)
    throws NoSuchMethodException {
    if (clazz == null) {
      logger.error("Class is null.");
      throw new NoSuchMethodException("No class");
    }

    if ((methodName == null) || methodName.trim().equals("")) {
      logger.error("Method name is null.");
      throw new NoSuchMethodException("No method name");
    }

    int    matchedPoint  = Integer.MIN_VALUE;
    Method matchedMethod = null;

    List<Method> methods = getMethodsByName(clazz, methodName);

    if (methods != null) {
      for (Method method : methods) {
        ArrayList<Class> lookupArgs = new ArrayList<Class>();

        if ((args != null) && (args.length > 0)) {
          for (Class arg : args) {
            lookupArgs.add(arg);
          }
        }

        Annotation[][] parameterAnnotations = method.getParameterAnnotations();
        Class[]        parameterTypes       = method.getParameterTypes();

        int i = 0;

        for (Annotation[] annotations : parameterAnnotations) {
          Class parameterType = parameterTypes[i];

          for (Annotation annotation : annotations) {
            if (annotation instanceof TdContextParam) {
              if (i <= lookupArgs.size()) {
                lookupArgs.add(i, parameterType);
              }
            }
          }

          i++;
        }

        int matchPoint = checkParams(method.getParameterTypes(),
            (lookupArgs.size() > 0) ? lookupArgs.toArray(new Class[lookupArgs.size()]) : new Class[] {});

        if (matchPoint == 0) {
          // perfect match, break
          matchedMethod = method;

          break;
        } else if ((matchPoint < 0) && (matchedPoint < matchPoint)) {
          matchedPoint  = matchPoint;
          matchedMethod = method;
        }
      } // end for
    }   // end if

    if (logger.isDebugEnabled() && (matchedMethod != null)) {
      logger.debug("Found method:" + matchedMethod);
    }

    return matchedMethod;
  } // end method findMethod

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   clazz  DOCUMENT ME!
   * @param   field  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NoSuchFieldException  DOCUMENT ME!
   */
  public static Method getGetterMethod(Class clazz, String field) throws NoSuchFieldException {
    // first, looking for the "getXXX"
    try {
      for (Method method : getMethodsByName(clazz, "get" + field)) {
        if (method.getParameterTypes().length == 0) {
          return method;
        }
      }

      // no found, then looking for the "isXXX"
      for (Method method : getMethodsByName(clazz, "is" + field)) {
        if (method.getParameterTypes().length == 0) {
          return method;
        }
      }
    } catch (Exception e) {
      if (logger.isDebugEnabled()) {
        logger.debug(e.getMessage());
      }
    }

    throw new NoSuchFieldException("'" + field + "' not found...");
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   fromClazz  DOCUMENT ME!
   * @param   toClazz    DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public static int getMatchPoint(Class fromClazz, Class toClazz) {
    if ((fromClazz == null) || toClazz.equals(fromClazz) || fromClazz.isAssignableFrom(toClazz)) {
      return 0;
    } else {
      if (toClazz.equals(Boolean.class) || toClazz.equals(boolean.class)) {
        if (fromClazz.equals(Boolean.class) || fromClazz.equals(boolean.class)) {
          return -100;
        }
      } else if (toClazz.equals(BigDecimal.class)) {
        if (fromClazz.equals(BigInteger.class)
              || fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)
              || fromClazz.equals(Double.class)
              || fromClazz.equals(double.class)
              || fromClazz.equals(Float.class)
              || fromClazz.equals(float.class)) {
          return -100;
        }
      } else if (toClazz.equals(BigInteger.class)) {
        if (fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)) {
          return -100;
        }
      } else if (toClazz.equals(Long.class) || toClazz.equals(long.class)) {
        if (fromClazz.equals(Long.class) || fromClazz.equals(long.class)) {
          return 0;
        } else if (fromClazz.equals(Integer.class) || fromClazz.equals(int.class)) {
          return -100;
        }
      } else if (toClazz.equals(Integer.class) || toClazz.equals(int.class)) {
        if (fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)) {
          return 0;
        } else if (fromClazz.equals(Long.class) || fromClazz.equals(long.class)) {
          return -1000;
        }
      } else if (toClazz.equals(Double.class) || toClazz.equals(double.class)) {
        if (fromClazz.equals(Double.class) || fromClazz.equals(double.class)) {
          return 0;
        } else if (fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)
              || fromClazz.equals(Float.class)
              || fromClazz.equals(float.class)) {
          return -100;
        }
      } else if (toClazz.equals(Float.class) || toClazz.equals(float.class)) {
        if (fromClazz.equals(Double.class) || fromClazz.equals(double.class)) {
          return 0;
        }

        if (fromClazz.equals(Long.class)
              || fromClazz.equals(long.class)
              || fromClazz.equals(Integer.class)
              || fromClazz.equals(int.class)
              || fromClazz.equals(Float.class)
              || fromClazz.equals(float.class)) {
          return -100;
        }
      } else if (toClazz.equals(String.class)) {
        return -100;
      } else if (toClazz.equals(Object.class)) {
        return 0;
      } // end if-else

    } // end if-else

    return 9999999;
  } // end method getMatchPoint

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   object  clazz DOCUMENT ME!
   * @param   method  DOCUMENT ME!
   * @param   args    DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  InvocationTargetException  DOCUMENT ME!
   * @throws  IllegalAccessException     DOCUMENT ME!
   * @throws  NoSuchMethodException      DOCUMENT ME!
   * @throws  NotSupportException        DOCUMENT ME!
   */
  public static Object invokeMethod(Object object, Method method, Object[] args) throws InvocationTargetException,
    IllegalAccessException {
    if ((args == null) || (args.length == 0)) {
      return method.invoke(object, new Object[] {});
    } else {
      int size = args.length;

      Class[] clsParamTypes = method.getParameterTypes();

      if ((clsParamTypes.length == 1) && (clsParamTypes[0].isArray())) {
        try {
          Class requireClass = getClassFromArrayName(clsParamTypes[0].getName());

          Object params = Array.newInstance(requireClass, size);

          for (int i = 0; i < size; i++) {
            Array.set(params, i, getSafeParamValue(requireClass, args[i]));
          }

          return doMethodInvoke(method, object, new Object[] { params });
        } catch (IllegalAccessException ex) { }
        catch (InvocationTargetException ex) { } // end try-catch
      }                                          // end if
      else if ((clsParamTypes.length > 1) && (clsParamTypes[clsParamTypes.length - 1].isArray())) {
        try {
          Object[] params = new Object[clsParamTypes.length];

          Class requireClass;
          int   j = 0;

          // handle leading match
          for (int i = 0; i < (clsParamTypes.length - 1); i++, j++) {
            requireClass = clsParamTypes[i];
            params[i]    = getSafeParamValue(requireClass, args[i]);
          }

          requireClass = getClassFromArrayName(clsParamTypes[clsParamTypes.length - 1].getName());

          // handle array
          int    arrayParamSize = size - clsParamTypes.length + 1;
          Object arrayParam     = Array.newInstance(Object.class, arrayParamSize);

          for (int i = 0; i < arrayParamSize; i++, j++) {
            Array.set(arrayParam, i, getSafeParamValue(requireClass, args[j]));
          }

          Array.set(params, clsParamTypes.length - 1, arrayParam);
// return method.invoke(object, new Object[] { params });
          return doMethodInvoke(method, object, params);
        } catch (IllegalAccessException ex) { }
        catch (InvocationTargetException ex) { } // end try-catch
      }                                          // end if
      else {
        return doMethodInvoke(method, object, args);
      }                                          // end if-else
    }                                            // end if-else

    throw new NotSupportException("Method Call is not supported.");
  } // end method invokeMethod

  private static Object getSafeParamValue(Class requireClass, Object paramValue) {
    if (paramValue == null) {
      return null;
    }

    return requireClass.equals(paramValue.getClass()) ? paramValue : doCastTo(paramValue, requireClass);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   pack    DOCUMENT ME!
   * @param   member  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public static boolean isInheritable(Package pack, Member member) {
    if (pack == null) {
      return false;
    }

    if (member == null) {
      return false;
    }

    int modifiers = member.getModifiers();

    if (Modifier.isPublic(modifiers)) {
      return true;
    }

    if (Modifier.isProtected(modifiers)) {
      return true;
    }

    if (!Modifier.isPrivate(modifiers) && pack.equals(member.getDeclaringClass().getPackage())) {
      return true;
    }

    return false;
  } // end method isInheritable

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   formalType  DOCUMENT ME!
   * @param   actualType  DOCUMENT ME!
   * @param   strict      DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public static boolean isTypeCompatible(Class formalType, Class actualType, boolean strict) {
    if ((formalType == null) && (actualType == null)) {
      return true;
    } else if ((formalType != null) && (actualType != null)) {
      if (strict) {
        return formalType.equals(actualType);
      } else {
        return formalType.isAssignableFrom(actualType);
      }
    } else {
      return false;
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   aryName  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  protected static Class getClassFromArrayName(String aryName) {
    if (aryName.startsWith("[L")) {
      aryName = aryName.substring(2, aryName.length() - 1);

      try {
        return Class.forName(aryName);
      } catch (ClassNotFoundException e) { }
    }

    return null;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   clazz       DOCUMENT ME!
   * @param   methodName  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  protected static List<Method> getMethodsByName(Class clazz, String methodName) {
    NoCaseHashMap<List<Method>> classMethods = classCache.get(clazz);

    if (classMethods == null) {
      synchronized (classCache) {
        classMethods = new NoCaseHashMap<List<Method>>();

        // no cached before, do scan and build this list
        for (Method method : clazz.getMethods()) {
          String       name    = method.getName();
          List<Method> methods = classMethods.get(name);

          if (methods == null) {
            // create a list
            methods = new ArrayList<Method>();
            classMethods.put(name, methods);
          }

          methods.add(method);
        }

        classCache.put(clazz, classMethods);
      }
    }

    return classMethods.get(methodName);
  } // end method getMethodsByName

  //~ ------------------------------------------------------------------------------------------------------------------

  private static Object doMethodInvoke(Method method, Object object, Object[] args) throws InvocationTargetException,
    IllegalAccessException {
    Class[]  clsParamTypes = method.getParameterTypes();
    Object[] invokeArgs    = new Object[args.length];

    for (int i = 0; i < args.length; i++) {
      invokeArgs[i] = doCastTo(args[i], clsParamTypes[i]);
    }

    return method.invoke(object, invokeArgs);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  private static Object doObjectCast(Object fromObject, Class toClazz) {
    Object toObject  = null;
    Class  fromClazz = fromObject.getClass();

    if (fromObject.getClass().equals(toClazz)) {
      toObject = fromObject;
    } else if (toClazz.equals(BigDecimal.class)) {
      if (fromClazz.equals(BigInteger.class)
            || fromClazz.equals(Long.class)
            || fromClazz.equals(long.class)
            || fromClazz.equals(Integer.class)
            || fromClazz.equals(int.class)
            || fromClazz.equals(Double.class)
            || fromClazz.equals(double.class)
            || fromClazz.equals(Float.class)
            || fromClazz.equals(float.class)) {
        toObject = new BigDecimal(fromObject.toString());
      }
    } else if (toClazz.equals(BigInteger.class)) {
      if (fromClazz.equals(Long.class)
            || fromClazz.equals(long.class)
            || fromClazz.equals(Integer.class)
            || fromClazz.equals(int.class)) {
        toObject = new BigInteger(fromObject.toString());
      }
    } else if (toClazz.equals(Long.class) || toClazz.equals(long.class)) {
      if (fromClazz.equals(Long.class)
            || fromClazz.equals(long.class)
            || fromClazz.equals(Integer.class)
            || fromClazz.equals(int.class)) {
        toObject = Long.valueOf(fromObject.toString());
      }
    } else if (toClazz.equals(Integer.class) || toClazz.equals(int.class)) {
      if (fromClazz.equals(Integer.class)
            || fromClazz.equals(int.class)
            || fromClazz.equals(Long.class)
            || fromClazz.equals(long.class)) {
        toObject = Integer.valueOf(fromObject.toString());
      }
    } else if (toClazz.equals(Double.class) || toClazz.equals(double.class)) {
      if (fromClazz.equals(Long.class)
            || fromClazz.equals(long.class)
            || fromClazz.equals(Integer.class)
            || fromClazz.equals(int.class)
            || fromClazz.equals(Float.class)
            || fromClazz.equals(float.class)
            || fromClazz.equals(Double.class)
            || fromClazz.equals(double.class)) {
        toObject = new Double(fromObject.toString());
      }
    } else if (toClazz.equals(Float.class) || toClazz.equals(float.class)) {
      if (fromClazz.equals(Long.class)
            || fromClazz.equals(long.class)
            || fromClazz.equals(Integer.class)
            || fromClazz.equals(int.class)
            || fromClazz.equals(Float.class)
            || fromClazz.equals(float.class)
            || fromClazz.equals(Double.class)
            || fromClazz.equals(double.class)) {
        toObject = new Float(fromObject.toString());
      }
    } else if (toClazz.equals(Boolean.class) || toClazz.equals(boolean.class)) {
      toObject = new Boolean(fromObject.toString());
    } else if (toClazz.equals(String.class)) {
      toObject = fromObject.toString();
    } // end if-else

    return toObject;
  } // end method doObjectCast
} // end class FunctionUtil
