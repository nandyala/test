package com.tdstrategy.el.exception;


import com.tdstrategy.el.impl.TdElValue;


/**
 * DOCUMENT ME!
 *
 * @author   Rojer Luo
 * @version  $Revision$, $Date$
 */
public class ReturnException extends RuntimeException {
  //~ Instance fields --------------------------------------------------------------------------------------------------

  /** DOCUMENT ME! */
  TdElValue retValue = null;

  //~ Constructors -----------------------------------------------------------------------------------------------------

  /**
   * Creates a new NotSupportException object.
   *
   * @param  retValue  DOCUMENT ME!
   */
  public ReturnException(TdElValue retValue) {
    this.retValue = retValue;
  }

  //~ Methods ----------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public TdElValue getRetValue() {
    return retValue;
  }
} // end class ReturnException
