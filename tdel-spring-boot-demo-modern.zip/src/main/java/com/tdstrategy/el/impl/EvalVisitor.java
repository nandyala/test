package com.tdstrategy.el.impl;

/**
 * Created with IntelliJ IDEA.
 * User: rojer
 * Date: 5/24/13
 * Time: 4:32 PM
 * To change this template use File | Settings | File Templates.
 */

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tdstrategy.el.annotation.TdCacheable;
import com.tdstrategy.el.annotation.TdContextParam;
import com.tdstrategy.el.antlr.TdElBaseVisitor;
import com.tdstrategy.el.antlr.TdElParser;
import com.tdstrategy.el.exception.NotSupportException;
import com.tdstrategy.el.exception.ReturnException;
import com.tdstrategy.el.util.CalculateUtil;
import com.tdstrategy.el.util.CompareUtil;
import com.tdstrategy.el.util.FunctionUtil;
import com.tdstrategy.el.util.NoCaseHashSet;


/**
 * DOCUMENT ME!
 *
 * @author   Rojer Luo
 * @version  $Revision$, $Date$
 */
public class EvalVisitor extends TdElBaseVisitor<TdElValue> {
  //~ Instance fields --------------------------------------------------------------------------------------------------

  /** Resolver Context. */
  protected ResolverContext resolvers = null;

  /** Variables that supported by context. */
  protected NoCaseHashSet supportedVariables = new NoCaseHashSet();

  /** Unknown Variables in the context. */
  protected NoCaseHashSet unknownVariables = new NoCaseHashSet();

  /** Variables used in the expression. */
  protected NoCaseHashSet usedVariables = new NoCaseHashSet();

  /** Cache for functionCall parent context TdElValue. */
  private ConcurrentHashMap<TdElParser.ExpressionContext, TdElValue> contextValues = new ConcurrentHashMap();

  private Logger          logger        = LoggerFactory.getLogger(this.getClass());

  /** silent mode: its silent when reach exception, no exception will be thrown.*/
  private boolean         silent      = false;
  //~ Constructors -----------------------------------------------------------------------------------------------------

  /**
   * Creates a new EvalVisitor object.
   */
  public EvalVisitor() { }

  /**
   * Creates a new EvalVisitor object.
   *
   * @param  silent  boolean
   */
  public EvalVisitor(boolean silent) {
    this.silent = silent;
  }

  //~ Methods ----------------------------------------------------------------------------------------------------------

  /**
   * Get all unknown variables.
   *
   * @return  unknown variables
   */
  public NoCaseHashSet getUnknownVariables() {
    return unknownVariables;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * Get all used variables.
   *
   * @return  used variables
   */
  public NoCaseHashSet getUsedVariables() {
    return usedVariables;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * Has unknown variables.
   *
   * @return  DOCUMENT ME!
   */
  public boolean hasUnknownVariables() {
    return (unknownVariables.size() > 0);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * Inject resolvers.
   *
   * @param  resolvers  resolvers
   */
  public void setResolvers(ResolverContext resolvers) {
    this.resolvers = resolvers;

    for (String name : resolvers.getNames()) {
      supportedVariables.add(name);
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * * | expression LBRACK expression RBRACK #AccessElement.
   *
   * @param   ctx  $param.type$
   *
   * @return  | expression LBRACK expression RBRACK #AccessElement.
   */
  @Override public TdElValue visitAccessElement(TdElParser.AccessElementContext ctx) {
    TdElValue arrayElValue = visit(ctx.expression(0));

    TdElValue indexElValue = visit(ctx.expression(1));

    String elementName = ctx.expression(0).getText();

    if (!indexElValue.isIntegerValue()) {
      logger.error("'" + elementName + "' is not a Integer value.");
    } else {
      Integer index = indexElValue.getIntegerValue();

      Object[] arrayValue = null;

      if (arrayElValue.isListValue()) {
        arrayValue = arrayElValue.getListValueInArray();
      } else if (arrayElValue.isObjectValue()) {
        Class  clazz    = arrayElValue.getClazz();
        Object objValue = arrayElValue.getValue();

        if (Collection.class.isAssignableFrom(clazz)) {
          arrayValue = ((Collection) objValue).toArray();
        } else if (clazz.isArray()) {
          arrayValue = ((Object[]) objValue);
        }
      }

      if ((arrayValue != null) && (arrayValue.length > index)) {
        return TdElValue.createTdElValue(arrayValue[index]).setResult(true);
      }
    }

    return new TdElValue();
  } // end method visitAccessElement

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression DOT ID #AccessProperty.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */

  @Override public TdElValue visitAccessProperty(TdElParser.AccessPropertyContext ctx) {
    TdElParser.ExpressionContext instanceContext = ctx.expression(0);
    TdElValue instanceElValue = visit(instanceContext);

    TdElParser.ExpressionContext propertyContext = ctx.expression(1);

    if (propertyContext instanceof TdElParser.CallFunctionContext) {
      contextValues.put(instanceContext, instanceElValue);
      return visit(ctx.expression(1));
    } else {
      String propertyName  = ctx.expression(1).getText();
      Object instanceValue = null;
      String instanceName  = null;

      if (instanceElValue.isMapValue()) {
        Map<String, Object> mapValue = instanceElValue.getMapValue();
        Object propertyValue = mapValue.get(propertyName);
        return TdElValue.createTdElValue(propertyValue).setResult(true);
      } else if (instanceElValue.isObjectValue()) {
        instanceValue = instanceElValue.getValue();
      } else {
        // It is a variable name
        instanceName  = instanceElValue.hasName() ? instanceElValue.getName() : instanceElValue.getStringValue();
        instanceValue = resolvers.getObjectValue(instanceName);
      }

      if (instanceValue != null) {
        Class[]  argTypes = {};
        Object[] args     = {};

        Method method     = null;
        String methodName = propertyName;

        try {
          if (argTypes.length == 0) {
            methodName = "get" + propertyName;
            method     = FunctionUtil.findMethod(instanceValue.getClass(), methodName, argTypes);

            if (method == null) {
              methodName = "is" + propertyName;
              method     = FunctionUtil.findMethod(instanceValue.getClass(), methodName, argTypes);
            }
          }

          if (method == null) {
            method = FunctionUtil.findMethod(instanceValue.getClass(), propertyName, argTypes);
          }

          if (method != null) {
            ArrayList<Object> callArgs = new ArrayList<Object>();

            if ((args != null) && (args.length > 0)) {
              for (Object arg : args) {
                callArgs.add(arg);
              }
            }

            Annotation[][] parameterAnnotations = method.getParameterAnnotations();

            int i = 0;

            for (Annotation[] annotations : parameterAnnotations) {
              for (Annotation annotation : annotations) {
                if (annotation instanceof TdContextParam) {
                  TdContextParam tdParam = (TdContextParam) annotation;

                  if (i <= callArgs.size()) {
                    callArgs.add(i, resolvers.getObjectValue(tdParam.value()));
                  }
                }

                i++;
              }
            }

            Object retValue = FunctionUtil.invokeMethod(instanceValue, method,
                    (callArgs.size() > 0) ? callArgs.toArray() : new Object[] {});

            return TdElValue.createTdElValue(retValue).setResult(true);
          }
        } catch (NoSuchMethodException e) {
          if (logger.isDebugEnabled()) {
            logger.debug(e.getMessage(), e);
          }
        } catch (IllegalAccessException e) {
          if (logger.isDebugEnabled()) {
            logger.debug(e.getMessage(), e);
          }
        } catch (InvocationTargetException e) {
          if (logger.isDebugEnabled()) {
            logger.debug(e.getMessage(), e);
          }
        } catch (NullPointerException e) {
          if (logger.isDebugEnabled()) {
            logger.debug(e.getMessage(), e);
          }
        } // end try-catch
      } else {
        if (!silent) {
          logger.error("'" + instanceName + "' is null.");
        }
      }   // end if-else
    }     // end if-else

    return new TdElValue();
  } // end method visitAccessProperty

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression op=(PLUS | MINUS) expression #AddSub.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitAddSub(TdElParser.AddSubContext ctx) {
    TdElValue leftSide  = visit(ctx.expression(0));
    TdElValue rightSide = visit(ctx.expression(1));

    if ((leftSide != null) && leftSide.isBooleanValue()) {
      if (logger.isDebugEnabled()) {
        logger.debug("Boolean value '" + leftSide.strValue + "'can not do math calculation.");
      }

      return new TdElValue();
    }

    if ((rightSide != null) && rightSide.isBooleanValue()) {
      if (logger.isDebugEnabled()) {
        logger.debug("Boolean value '" + rightSide.strValue + "'can not be math calculation.");
      }

      return new TdElValue();
    }

    if (((leftSide == null) || leftSide.isNullValue()) || ((rightSide == null) || (rightSide.isNullValue()))) {
      return new TdElValue();
    }

    if (leftSide.isDecimalCompatibleValue()) {
      // only allow decimal expression
      if (rightSide.isDecimalCompatibleValue()) {
        try {
          if (ctx.op.getType() == TdElParser.PLUS) {
            if (leftSide.isDecimalValue() || rightSide.isDecimalValue()) {
              return new TdElValue(leftSide.getDecimalValue().add(rightSide.getDecimalValue()));
            } else if (leftSide.isLongValue() || rightSide.isLongValue()) {
              return new TdElValue(leftSide.getLongValue() + rightSide.getLongValue());
            } else if (leftSide.isIntegerValue() || rightSide.isIntegerValue()) {
              return new TdElValue(leftSide.getIntegerValue() + rightSide.getIntegerValue());
            }
          } else if (ctx.op.getType() == TdElParser.MINUS) {
            if (leftSide.isDecimalValue() || rightSide.isDecimalValue()) {
              return new TdElValue(leftSide.getDecimalValue().subtract(rightSide.getDecimalValue()));

            } else if (leftSide.isLongValue() || rightSide.isLongValue()) {
              return new TdElValue(leftSide.getLongValue() - rightSide.getLongValue());

            } else if (leftSide.isIntegerValue() || rightSide.isIntegerValue()) {
              return new TdElValue(leftSide.getIntegerValue() - rightSide.getIntegerValue());
            }

            if (logger.isDebugEnabled()) {
              logger.debug("'" + rightSide.getStrValue() + "' - Decimal value needed.");
            }
          } // end if-else
        } catch (Exception e) {
          if (logger.isDebugEnabled()) {
            logger.debug(e.getLocalizedMessage());
          }
        }   // end try-catch
      }     // end if
      else if ((ctx.op.getType() == TdElParser.PLUS)) {
        return new TdElValue("" + leftSide.getDecimalValue() + rightSide.getStrValue());
      }     // end if-else

      if (logger.isDebugEnabled()) {
        logger.debug("'" + rightSide.getStrValue() + "' - Decimal value needed.");
      }
    } // end for
    else if (leftSide.isDateValue()) {
      // only allow Date +/- num & Date - Date
      if (rightSide.isIntegerValue()) {
        try {
          if (ctx.op.getType() == TdElParser.PLUS) {
            return new TdElValue(CalculateUtil.addDays(leftSide.getDateValue(), rightSide.getIntegerValue()));

          } else if (ctx.op.getType() == TdElParser.MINUS) {
            return new TdElValue(CalculateUtil.minusDays(leftSide.getDateValue(), rightSide.getIntegerValue()));

          } // end if-else
        } catch (Exception e) {
          if (logger.isDebugEnabled()) {
            logger.debug(e.getLocalizedMessage());
          }
        }   // end try-catch
      }     // end if
      else if (rightSide.isDateValue()) {
        if (ctx.op.getType() == TdElParser.MINUS) {
          return new TdElValue(CalculateUtil.getDayDifference(leftSide.getDateValue(),
                rightSide.getDateValue()));
        }   // en
      }     // end if-else

      if (logger.isDebugEnabled()) {
        logger.debug("'" + rightSide.getStrValue() + "' - Integer Value or Date Value needed.");
      }
    } else if ((ctx.op.getType() == TdElParser.PLUS)) {
      return new TdElValue(leftSide.getStrValue() + rightSide.getValue().toString());

      // end for
    } // end if-else

    if (logger.isDebugEnabled()) {
      logger.debug("'" + leftSide.getStrValue() + "' - Decimal or Date value needed.");
    }

    return new TdElValue();
  } // end method visitAddSub

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression AND expression #And.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitAnd(TdElParser.AndContext ctx) {
    TdElValue leftSide  = visit(ctx.expression(0));
    TdElValue rightSide = visit(ctx.expression(1));

    if (leftSide.isBooleanValue()) {
      boolean bLeft = leftSide.getBooleanValue();

      if ((rightSide == null) || rightSide.isNullValue() || rightSide.isBooleanValue()) {
        if (!bLeft) {
          return new TdElValue(Boolean.FALSE);
        } else {
          if ((rightSide == null) || rightSide.isNullValue()) {
            return new TdElValue();
          } else {
            return new TdElValue(rightSide.getBooleanValue());
          }
        }
      } else if (rightSide.isStringValue()) {
        if (rightSide.getStrValue().equalsIgnoreCase("true") || rightSide.getStrValue().equalsIgnoreCase("'true'")) {
          return leftSide;
        } else if (rightSide.getStrValue().equalsIgnoreCase("false")
              || rightSide.getStrValue().equalsIgnoreCase("'false'")) {
          return new TdElValue(Boolean.FALSE);
        }
      } else {
        if (logger.isDebugEnabled()) {
          logger.debug("'" + rightSide.strValue + "' - Needed to be Boolean value.");
        }
      }
    } else {
      if (logger.isDebugEnabled()) {
        logger.debug("'" + leftSide.strValue + "' - Needed to be Boolean value.");
      }
    } // end if-else

    return new TdElValue();
  } // end method visitAnd

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | LBRACK expressionList? RBRACK #ArrayPrimary.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  | LBRACK expression RBRACK #ArrayPrimary.
   *
   * @see     com.tdstrategy.el.antlr.TdElBaseVisitor#visitArrayPrimary(com.tdstrategy.el.antlr.TdElParser.ArrayPrimaryContext)
   */
  @Override public TdElValue visitArrayPrimary(TdElParser.ArrayPrimaryContext ctx) {
    if (ctx.expressionList() != null) {
      return visit(ctx.expressionList());
    }

    return new TdElValue();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitAssignmentExpr(com.tdstrategy.el.antlr.TdElParser.AssignmentExprContext)
   */
  @Override public TdElValue visitAssignmentExpr(TdElParser.AssignmentExprContext ctx) {
    String    variableName = ctx.variable().getText();
    TdElValue exprValue    = visit(ctx.expression());

    switch (ctx.op.getType()) {
      case TdElParser.ASSIGN: {
        resolvers.addValue(variableName, exprValue);

        if (logger.isDebugEnabled()) {
          logger.debug("Assignment: " + variableName + "=" + exprValue);
        }

        return exprValue;
      }

      case TdElParser.PLUSEQUAL: {
        TdElValue varValue = resolvers.getValue(variableName);

        if (varValue.isDecimalValue() || exprValue.isDecimalValue()) {
          varValue = new TdElValue(varValue.getDecimalValue().add(exprValue.getDecimalValue()));
        } else if (varValue.isLongValue() || exprValue.isLongValue()) {
          varValue = new TdElValue(varValue.getLongValue() + exprValue.getLongValue());
        } else if (varValue.isIntegerValue() || exprValue.isIntegerValue()) {
          varValue = new TdElValue(varValue.getIntegerValue() + exprValue.getIntegerValue());
        } else {
          return null;
        }

        resolvers.addValue(variableName, varValue);

        if (logger.isDebugEnabled()) {
          logger.debug("Assignment: " + variableName + "=" + varValue);
        }

        return varValue;
      }

      case TdElParser.MINUSEQUAL: {
        TdElValue varValue = resolvers.getValue(variableName);

        if (varValue.isDecimalValue() || exprValue.isDecimalValue()) {
          varValue = new TdElValue(varValue.getDecimalValue().subtract(exprValue.getDecimalValue()));
        } else if (varValue.isLongValue() || exprValue.isLongValue()) {
          varValue = new TdElValue(varValue.getLongValue() - exprValue.getLongValue());
        } else if (varValue.isIntegerValue() || exprValue.isIntegerValue()) {
          varValue = new TdElValue(varValue.getIntegerValue() - exprValue.getIntegerValue());
        } else {
          return null;
        }

        resolvers.addValue(variableName, varValue);

        if (logger.isDebugEnabled()) {
          logger.debug("Assignment: " + variableName + "=" + varValue);
        }

        return varValue;
      }

      case TdElParser.STAREQUAL: {
        TdElValue varValue = resolvers.getValue(variableName);

        if (varValue.isDecimalValue() || exprValue.isDecimalValue()) {
          varValue = new TdElValue(varValue.getDecimalValue().multiply(exprValue.getDecimalValue()));
        } else if (varValue.isLongValue() || exprValue.isLongValue()) {
          varValue = new TdElValue(varValue.getLongValue() * exprValue.getLongValue());
        } else if (varValue.isIntegerValue() || exprValue.isIntegerValue()) {
          varValue = new TdElValue(varValue.getIntegerValue() * exprValue.getIntegerValue());
        } else {
          return null;
        }

        resolvers.addValue(variableName, varValue);

        if (logger.isDebugEnabled()) {
          logger.debug("Assignment: " + variableName + "=" + varValue);
        }

        return varValue;
      }

      case TdElParser.SLASHEQUAL: {
        TdElValue varValue = resolvers.getValue(variableName);

        if (varValue.isDecimalValue() || exprValue.isDecimalValue()) {
          varValue = new TdElValue(varValue.getDecimalValue().divide(exprValue.getDecimalValue(), 8,
                BigDecimal.ROUND_HALF_EVEN));
        } else if (varValue.isLongValue() || exprValue.isLongValue()) {
          varValue = new TdElValue(varValue.getLongValue() / exprValue.getLongValue());
        } else if (varValue.isIntegerValue() || exprValue.isIntegerValue()) {
          varValue = new TdElValue(varValue.getIntegerValue() / exprValue.getIntegerValue());
        } else {
          return null;
        }

        resolvers.addValue(variableName, varValue);

        if (logger.isDebugEnabled()) {
          logger.debug("Assignment: " + variableName + "=" + varValue);
        }

        return varValue;
      }

      case TdElParser.MODEQUAL: {
        TdElValue varValue = resolvers.getValue(variableName);

        if (varValue.isLongValue() || exprValue.isLongValue()) {
          varValue = new TdElValue(varValue.getLongValue() % exprValue.getLongValue());
        } else if (varValue.isIntegerValue() || exprValue.isIntegerValue()) {
          varValue = new TdElValue(varValue.getIntegerValue() % exprValue.getIntegerValue());
        } else {
          return null;
        }

        resolvers.addValue(variableName, varValue);

        if (logger.isDebugEnabled()) {
          logger.debug("Assignment: " + variableName + "=" + varValue);
        }

        return varValue;
      }

      default:
    } // end switch

    return null;
  } // end method visitAssignmentExpr

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : statement (SEMI statement)*
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitBlock(TdElParser.BlockContext ctx) {
    TdElValue retValue = null;

    for (int i = 0; i < ctx.statement().size(); i++) {
      TdElValue value = visit(ctx.statement(i));

      if (value.isSkipValue()) {
        // skip the empty statement
        continue;
      }

      retValue = value;
    }

    return retValue;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : LCURLY block RCURLY
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitBlockStatement(TdElParser.BlockStatementContext ctx) {
    return visit(ctx.block());
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitBoolValue(com.tdstrategy.el.antlr.TdElParser.BoolValueContext)
   */
  @Override public TdElValue visitBoolValue(TdElParser.BoolValueContext ctx) {
    return super.visitBoolValue(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression LPAREN expressionList? RPAREN #CallFunction
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */

  @Override public TdElValue visitCallFunction(TdElParser.CallFunctionContext ctx) {
    String functionName = ctx.ID().getText();

    Class    methodClass = null;
    String   methodName  = functionName;
    Class[]  argTypes    = {};
    Object[] args        = {};

    Object instanceValue = null;

    TdElValue params = (ctx.expressionList() == null) ? null : visit(ctx.expressionList());

    if ((params != null) && (params.isListValue())) {
      List<TdElValue> list = params.getListValue();
      int             size = list.size();
      argTypes = new Class[size];
      args     = new Object[size];

      for (int i = 0; i < size; i++) {
        TdElValue param = list.get(i);

        if (param != null) {
          argTypes[i] = param.getValueType();
          args[i]     = param.getValue();
        } else {
          argTypes[i] = null;
          args[i]     = null;
        }
      }
    }

    if (ctx.getParent() instanceof TdElParser.AccessPropertyContext) {
      TdElParser.AccessPropertyContext propertyContext = (TdElParser.AccessPropertyContext) ctx.getParent();
      TdElParser.ExpressionContext     expressionBase  = propertyContext.expression(0);

      if (expressionBase != ctx) {
        TdElValue instanceElValue = contextValues.get(expressionBase);

        if(instanceElValue == null) {
          instanceElValue = visit(expressionBase);
        }

        methodClass   = instanceElValue.getClazz();
        instanceValue = instanceElValue.getValue();
      }
    }

    if (methodClass == null) {
      // look for overwrite method first
      ExposedMethod overrideMethod = resolvers.getRuntimeMethod(methodName);

      if (overrideMethod != null) {
        if (overrideMethod instanceof RuntimeMethod) {
          instanceValue = resolvers.getValue(((RuntimeMethod) overrideMethod).getInstanceName()).getValue();
        }

        methodClass = overrideMethod.getMethodClass();
        methodName  = overrideMethod.getMethodName();
      } else {
        // look for the exposed methods
        ExposedMethod exposedMethod = resolvers.getExposedMethod(methodName);

        if (exposedMethod != null) {
          methodClass = exposedMethod.getMethodClass();
          methodName  = exposedMethod.getMethodName();
        }
      }
    } // end if-else

    if ((methodName != null) && (methodClass != null)) {
      Method method = null;

      try {
        method = FunctionUtil.findMethod(methodClass, methodName, argTypes);

        boolean cacheable = method.isAnnotationPresent(TdCacheable.class);

        if (method != null) {
          if (logger.isDebugEnabled()) {
            logger.debug("Found Method:" + method.toString());
            logger.debug("Method return:" + method.getReturnType());
          }

          ArrayList<Object> callArgs = new ArrayList<Object>();

          if ((args != null) && (args.length > 0)) {
            for (Object arg : args) {
              callArgs.add(arg);
            }
          }

          Annotation[][] parameterAnnotations = method.getParameterAnnotations();

          int i = 0;

          for (Annotation[] annotations : parameterAnnotations) {
            for (Annotation annotation : annotations) {
              if (annotation instanceof TdContextParam) {
                TdContextParam tdParam = (TdContextParam) annotation;

                if (i <= callArgs.size()) {
                  callArgs.add(i, resolvers.getObjectValue(tdParam.value()));
                }
              }

              i++;
            }
          }

          Object retValue = FunctionUtil.invokeMethod(instanceValue, method,
              (callArgs.size() > 0) ? callArgs.toArray() : new Object[] {});

          return TdElValue.createTdElValue(retValue).allowCache(cacheable);
        } // end if

        throw new NotSupportException("Function '" + methodName + "' is not supported.");
      } catch (NoSuchMethodException e) {
        if (!silent) {
          logger.error(e.getMessage(), e);
        }
      } catch (IllegalAccessException e) {
        if (!silent) {
          logger.error(e.getMessage(), e);
        }
      } catch (InvocationTargetException e) {
        if (e.getTargetException() instanceof NullPointerException) {
          return null;
        }

        if (!silent) {
          logger.error(e.getMessage(), e);
        }
      } catch (NullPointerException e) {
        if (!silent) {
          logger.error(e.getMessage(), e);
        }
      } // end try-catch
    }   // end if

    return new TdElValue();
// if (functionName != null) {
// ExposedMethod exposedMethod = resolvers.getExposedMethod(functionName);
//
// if (exposedMethod != null) {
// TdElValue params = (ctx.expressionList() == null) ? null : visit(ctx.expressionList());
//
// Class[]  argTypes = {};
// Object[] args     = {};
//
// if ((params != null) && (params.isListValue())) {
// List<TdElValue> list = params.getListValue();
// int             size = list.size();
// argTypes = new Class[size];
// args     = new Object[size];
//
// for (int i = 0; i < size; i++) {
// TdElValue param = list.get(i);
//
// argTypes[i] = param.getValueType();
// args[i]     = param.getValue();
// }
// }
//
// Method method = null;
//
// try {
// method = FunctionUtil.findMethod(exposedMethod.getMethodClass(), exposedMethod.getMethodName(), argTypes);
//
// if (method != null) {
// ArrayList<Object> callArgs = new ArrayList<Object>();
//
// if ((args != null) && (args.length > 0)) {
// for (Object arg : args) {
// callArgs.add(arg);
// }
// }
//
// Annotation[][] parameterAnnotations = method.getParameterAnnotations();
//
// int i = 0;
//
// for (Annotation[] annotations : parameterAnnotations) {
// for (Annotation annotation : annotations) {
// if (annotation instanceof TdContextParam) {
// TdContextParam tdParam = (TdContextParam) annotation;
//
// if (i <= callArgs.size()) {
// callArgs.add(i, resolvers.getObjectValue(tdParam.name()));
// }
// }
//
// i++;
// }
// }
//
// Object retValue = FunctionUtil.invokeMethod(exposedMethod.getMethodClass(), method,
// (callArgs.size() > 0) ? callArgs.toArray() : new Object[] {});
//
// return TdElValue.createTdElValue(retValue);
// } // end if
// } catch (NoSuchMethodException e) {
// logger.error(e.getMessage(), e);
// } catch (IllegalAccessException e) {
// logger.error(e.getMessage(), e);
// } catch (InvocationTargetException e) {
// if (e.getTargetException() instanceof NullPointerException) {
// return null;
// }
//
// logger.error(e.getMessage(), e);
// } catch (NullPointerException e) {
// logger.error(e.getMessage(), e);
//
// return null;
// } // end try-catch
// }   // end if
// else {
// // try eval string
// if (resolvers.contains(functionName)) {
// return resolvers.callFunction(functionName,
// (ctx.expressionList() == null) ? null : ctx.expressionList().getText());
// }
// } // end if-else
// }   // end if
//
// TdElValue function = visit(ctx.ID());
//
// return function;
  } // end method visitCallFunction

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression op=(LE | GE | GT | LT | IN) expression #Compare.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitCompare(TdElParser.CompareContext ctx) {
    TdElValue leftSide  = visit(ctx.expression(0));
    TdElValue rightSide = visit(ctx.expression(1));

    if ((leftSide != null) && leftSide.isBooleanValue()) {
      if (logger.isDebugEnabled()) {
        logger.debug("Boolean value '" + leftSide.strValue + "'can not be compared.");
      }

      return new TdElValue();
    }

    if ((rightSide != null) && rightSide.isBooleanValue()) {
      if (logger.isDebugEnabled()) {
        logger.debug("Boolean value '" + rightSide.strValue + "'can not be compared.");
      }

      return new TdElValue();
    }

    if (((leftSide == null) || leftSide.isNullValue()) || ((rightSide == null) || rightSide.isNullValue())) {
      return new TdElValue(false);
    }

    int type = ctx.op.getType();

    switch (type) {
      case TdElParser.LT: {
        return new TdElValue(CompareUtil.lessThan(leftSide.getValue(), rightSide.getValue()));
      }

      case TdElParser.LE: {
        return new TdElValue(CompareUtil.lessThanOrEqualsTo(leftSide.getValue(), rightSide.getValue()));
      }

      case TdElParser.GT: {
        return new TdElValue(CompareUtil.greaterThan(leftSide.getValue(), rightSide.getValue()));
      }

      case TdElParser.GE: {
        return new TdElValue(CompareUtil.greaterThanOrEqualsTo(leftSide.getValue(), rightSide.getValue()));
      }

      case TdElParser.IN: {
        if (rightSide.isListValue()) {
          List<TdElValue> list  = rightSide.getListValue();
          boolean         found = false;

// StopWatch stopWatch = new StopWatch();
//
// stopWatch.start("Using HashSet.");
//
// Set<Object> objectSet = new HashSet<Object>();
//
// for (TdElValue elValue : list) {
// objectSet.add(elValue.getValue());
// }
//
// found = objectSet.contains(leftSide.getValue());
// stopWatch.stop();
//
// stopWatch.start("Using Arrays.Sort");
//
          int      size  = list.size();
          Object[] array = new Object[size];

          for (int i = 0; i < size; i++) {
            array[i] = list.get(i).getValue();
          }

//
// Arrays.sort(array);
// found = Arrays.binarySearch(array, leftSide.getValue()) != -1;
// stopWatch.stop();
//
// stopWatch.start("Using Loop");
//
          found = CompareUtil.in(leftSide.getValue(), array);

// stopWatch.stop();
// logger.info(stopWatch.prettyPrint());
          return new TdElValue(found);
        } // end if
      }
    }     // end switch

    if (logger.isDebugEnabled()) {
      logger.debug("'" + leftSide.strValue + "' or '" + rightSide.strValue
        + "' need be matched for comparison.");
    }

    return new TdElValue();
  } // end method visitCompare

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitConstantExpression(com.tdstrategy.el.antlr.TdElParser.ConstantExpressionContext)
   */
  @Override public TdElValue visitConstantExpression(TdElParser.ConstantExpressionContext ctx) {
    return super.visitConstantExpression(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitEntry(com.tdstrategy.el.antlr.TdElParser.EntryContext)
   */
  @Override public TdElValue visitEntry(TdElParser.EntryContext ctx) {
    return visit(ctx.program());
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression (EQUAL | NOT_EQUAL) expression #Equal.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitEqual(TdElParser.EqualContext ctx) {
    TdElValue leftSide  = visit(ctx.expression(0));
    TdElValue rightSide = visit(ctx.expression(1));

    if (ctx.op.getType() == TdElParser.EQUAL) {
      if (((leftSide == null) || leftSide.isNullValue()) && ((rightSide == null) || rightSide.isNullValue())) {
        return new TdElValue(true);
      } else if ((leftSide == null) || leftSide.isNullValue()) {
        return new TdElValue(false);
      } else if ((rightSide == null) || rightSide.isNullValue()) {
        return new TdElValue(false);
      } else if (leftSide.isBooleanValue()) {
        if (rightSide.isBooleanValue()) {
          Boolean bRight = rightSide.getBooleanValue();

          if (Boolean.TRUE.equals(bRight)) {
            return leftSide;
          } else if (Boolean.FALSE.equals(bRight)) {
            return new TdElValue(!leftSide.getBooleanValue().booleanValue());
          }
        } else if (rightSide.isStringValue()) {
          if (rightSide.getStrValue().equalsIgnoreCase("true") || rightSide.getStrValue().equalsIgnoreCase("'true'")) {
            return leftSide;
          } else if (rightSide.getStrValue().equalsIgnoreCase("false")
                || rightSide.getStrValue().equalsIgnoreCase("'false'")) {
            return new TdElValue(!leftSide.getBooleanValue().booleanValue());
          }
        }

        if (logger.isDebugEnabled()) {
          logger.debug("'" + rightSide.getStrValue() + "' needed to be boolean value.");
        }

        return new TdElValue();
      } // end if-else
      else if (leftSide.isDecimalCompatibleValue() && rightSide.isBooleanValue()) {
        if (logger.isDebugEnabled()) {
          logger.debug("'" + rightSide.getStrValue() + "' needed to be decimal value.");
        }

        return new TdElValue();
      } // end if-else

      return new TdElValue(CompareUtil.equalsTo(leftSide.getValue(), rightSide.getValue()));
    } else if (ctx.op.getType() == TdElParser.NOT_EQUAL) {
      if (((leftSide == null) || leftSide.isNullValue()) && ((rightSide == null) || rightSide.isNullValue())) {
        return new TdElValue(false);
      } else if ((leftSide == null) || leftSide.isNullValue()) {
        return new TdElValue(true);
      } else if ((rightSide == null) || rightSide.isNullValue()) {
        return new TdElValue(true);
      } else if (leftSide.isBooleanValue()) {
        if (rightSide.isBooleanValue()) {
          Boolean bRight = rightSide.getBooleanValue();

          if (Boolean.FALSE.equals(bRight)) {
            return leftSide;
          } else if (Boolean.TRUE.equals(bRight)) {
            return new TdElValue(!leftSide.getBooleanValue());
          }
        } else if (rightSide.isStringValue()) {
          if (rightSide.getStrValue().equalsIgnoreCase("false")
                || rightSide.getStrValue().equalsIgnoreCase("'false'")) {
            return leftSide;
          } else if (rightSide.getStrValue().equalsIgnoreCase("true")
                || rightSide.getStrValue().equalsIgnoreCase("'true'")) {
            return new TdElValue(!leftSide.getBooleanValue());
          }
        }

        if (logger.isDebugEnabled()) {
          logger.debug("'" + rightSide.getStrValue() + "' needed to be boolean value.");
        }

        return new TdElValue();
      } // end if-else
      else if (leftSide.isDecimalCompatibleValue() && rightSide.isBooleanValue()) {
        if (logger.isDebugEnabled()) {
          logger.debug("'" + rightSide.getStrValue() + "' needed to be decimal value.");
        }

        return new TdElValue();
      } // end if-else

      return new TdElValue(CompareUtil.notEqualsTo(leftSide.getValue(), rightSide.getValue()));
    } else {
      if (logger.isDebugEnabled()) {
        logger.debug("Value type must be matched for comparison.");
      }
    } // end if-else

    return new TdElValue();
  } // end method visitEqual

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : expression (COMMA expression)*
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitExpressionList(TdElParser.ExpressionListContext ctx) {
    List<TdElValue> list = new ArrayList<TdElValue>();

    for (int i = 0; i < ctx.expression().size(); i++) {
      list.add(visit(ctx.expression(i)));
    }

    return new TdElValue(list);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : LPAREN expression RPAREN #ExprPrimary
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitExprPrimary(TdElParser.ExprPrimaryContext ctx) {
    // Just return
    return visit(ctx.expression());
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | FALSE #FalseValue.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitFalseValue(TdElParser.FalseValueContext ctx) {
    return new TdElValue(Boolean.FALSE);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitForeachControl(com.tdstrategy.el.antlr.TdElParser.ForeachControlContext)
   */
  @Override public TdElValue visitForeachControl(TdElParser.ForeachControlContext ctx) {
    String    variableName = ctx.variable().getText();
    TdElValue expr         = visit(ctx.expression());

    List<Object> list = new ArrayList<Object>();

    Object value = expr.getValue();

    if (value instanceof Collection) {
      for (Object object : (Collection) value) {
        if (object instanceof TdElValue) {
          list.add(object);
        } else {
          list.add(new TdElValue(object));
        }
      }
    } else {
      if (value instanceof TdElValue) {
        list.add(value);
      } else {
        list.add(new TdElValue(value));
      }
    }

    return new TdElValue(variableName, list);
  } // end method visitForeachControl

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitForInit(com.tdstrategy.el.antlr.TdElParser.ForInitContext)
   */
  @Override public TdElValue visitForInit(TdElParser.ForInitContext ctx) {
    return super.visitForInit(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitForUpdate(com.tdstrategy.el.antlr.TdElParser.ForUpdateContext)
   */
  @Override public TdElValue visitForUpdate(TdElParser.ForUpdateContext ctx) {
    return super.visitForUpdate(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | ID #IdentParimary.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */

  @Override public TdElValue visitIdentPrimary(TdElParser.IdentPrimaryContext ctx) {
    String    name     = ctx.getText();
    TdElValue retValue = resolvers.getValue(name);

    if (!resolvers.contains(name.toLowerCase())) {
      if (!unknownVariables.contains(name)) {
        unknownVariables.add(name);

        if (logger.isDebugEnabled()) {
          logger.debug("Unknown :'" + name + "' found...");
        }
      }
    } else {
      if (!usedVariables.contains(name)) {
        usedVariables.add(name);

        if (logger.isDebugEnabled()) {
          logger.debug("Found :'" + name + "'...");
        }
      }
    }

    return retValue;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : INT #IntValue
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitIntValue(TdElParser.IntValueContext ctx) {
    String strValue = ctx.IntegerLiteral().getText();

    try {
      Integer intValue = Integer.parseInt(strValue);

      return new TdElValue(intValue);
    } catch (NumberFormatException e) {
      // Can not convert to Integer
      try {
        Long longValue = Long.parseLong(strValue);

        return new TdElValue(longValue);
      } catch (NumberFormatException e1) {
        // Can not convert to Long
        BigDecimal decimalValue = new BigDecimal(strValue);

        return new TdElValue(decimalValue);
      }
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | literal #LiteralPrimary.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitLiteralPrimary(TdElParser.LiteralPrimaryContext ctx) {
    // Just return
    return super.visitLiteralPrimary(ctx);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression (STAR | SLASH | MOD) expression #MulDiv.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitMulDiv(TdElParser.MulDivContext ctx) {
    TdElValue leftSide  = visit(ctx.expression(0));
    TdElValue rightSide = visit(ctx.expression(1));

    if ((leftSide != null) && leftSide.isBooleanValue()) {
      if (logger.isDebugEnabled()) {
        logger.debug("Boolean value '" + leftSide.strValue + "'can not do math calculation.");
      }

      return new TdElValue();
    }

    if ((rightSide != null) && rightSide.isBooleanValue()) {
      if (logger.isDebugEnabled()) {
        logger.debug("Boolean value '" + rightSide.strValue + "'can not be math calculation.");
      }

      return new TdElValue();
    }

    if (((leftSide == null) || leftSide.isNullValue()) || ((rightSide == null) || (rightSide.isNullValue()))) {
      return new TdElValue();
    }

    if (leftSide.isDecimalCompatibleValue()) {
      // only allow decimal expression
      if (rightSide.isDecimalCompatibleValue()) {
        try {
          if (ctx.op.getType() == TdElParser.STAR) {
            if (leftSide.isDecimalValue() || rightSide.isDecimalValue()) {
              return new TdElValue(leftSide.getDecimalValue().multiply(rightSide.getDecimalValue()));
            } else if (leftSide.isLongValue() || rightSide.isLongValue()) {
              return new TdElValue(leftSide.getLongValue() * rightSide.getLongValue());
            } else if (leftSide.isIntegerValue() || rightSide.isIntegerValue()) {
              return new TdElValue(leftSide.getIntegerValue() * rightSide.getIntegerValue());
            }
          } else if (ctx.op.getType() == TdElParser.SLASH) {
            if (leftSide.isDecimalCompatibleValue() || rightSide.isDecimalCompatibleValue()) {
              return new TdElValue(leftSide.getDecimalValue().divide(rightSide.getDecimalValue(), 8,
                    BigDecimal.ROUND_HALF_EVEN));
            }
          } else if (ctx.op.getType() == TdElParser.MOD) {
            if (leftSide.isLongCompatibleValue()) {
              if (rightSide.isLongCompatibleValue()) {
                return new TdElValue(leftSide.getLongValue() % rightSide.getLongValue());
              } else {
                if (logger.isDebugEnabled()) {
                  logger.debug("'" + rightSide.getStrValue() + "' - Long value needed.");
                }
              }
            } else {
              if (logger.isDebugEnabled()) {
                logger.debug("'" + leftSide.getStrValue() + "' - Long value needed.");
              }
            }
          } // end if-else

          if (logger.isDebugEnabled()) {
            logger.debug("Operation not support.");
          }
        } catch (Exception e) {
          if (logger.isDebugEnabled()) {
            logger.debug(e.getLocalizedMessage());
          }
        } // end try-catch
      }   // end if
      else {
        if (logger.isDebugEnabled()) {
          logger.debug("'" + rightSide.getStrValue() + "' - Decimal value needed.");
        }
      }   // end if-else
    }     // end for
    else {
      if (logger.isDebugEnabled()) {
        logger.debug("'" + leftSide.strValue + "' - Decimal value needed.");
      }
    }     // end if-else

    return new TdElValue();
  } // end method visitMulDiv

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitNewExpr(com.tdstrategy.el.antlr.TdElParser.NewExprContext)
   */
  @Override public TdElValue visitNewExpr(TdElParser.NewExprContext ctx) {
    String strValue = ctx.IntegerLiteral().getText();

    if (ctx.LONG() != null) {
      Long longValue = Long.parseLong(strValue);

      return new TdElValue(longValue);
    } else if (ctx.INTEGER() != null) {
      Integer intValue = Integer.parseInt(strValue);

      return new TdElValue(intValue);
    }

    return visit(ctx.IntegerLiteral());
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | NOT expression #NotExpression.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitNotExpression(TdElParser.NotExpressionContext ctx) {
    TdElValue rightSide = visit(ctx.expression());

    if (rightSide.isBooleanValue()) {
      return new TdElValue(!rightSide.getBooleanValue());
    }

    if (logger.isDebugEnabled()) {
      logger.debug("'" + rightSide.getStrValue() + "' needed to be boolean value.");
    }

    return new TdElValue();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | NULL #NullValue.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitNullValue(TdElParser.NullValueContext ctx) {
    return new TdElValue();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression OR expression #Or.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitOr(TdElParser.OrContext ctx) {
    TdElValue leftSide  = visit(ctx.expression(0));
    TdElValue rightSide = visit(ctx.expression(1));

    if (leftSide.isBooleanValue()) {
      if ((rightSide == null) || rightSide.isNullValue() || rightSide.isBooleanValue()) {
        boolean bLeft = leftSide.getBooleanValue();

        if (bLeft) {
          return new TdElValue(Boolean.TRUE);
        } else {
          if ((rightSide == null) || rightSide.isNullValue()) {
            return new TdElValue();
          } else {
            return new TdElValue(rightSide.getBooleanValue());
          }
        }
      } else if (rightSide.isStringValue()) {
        if (rightSide.getStrValue().equalsIgnoreCase("true") || rightSide.getStrValue().equalsIgnoreCase("'true'")) {
          return new TdElValue(Boolean.TRUE);
        } else if (rightSide.getStrValue().equalsIgnoreCase("false")
              || rightSide.getStrValue().equalsIgnoreCase("'false'")) {
          return leftSide;
        }
      } else {
        if (logger.isDebugEnabled()) {
          logger.debug("'" + rightSide.strValue + "' - Needed to be Boolean value.");
        }
      }
    } else {
      if (logger.isDebugEnabled()) {
        logger.debug("'" + leftSide.strValue + "' - Needed to be Boolean value.");
      }
    } // end if-else

    return new TdElValue();
  } // end method visitOr

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : LPAREN expression RPAREN
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */

  @Override public TdElValue visitParExpression(TdElParser.ParExpressionContext ctx) {
    return visit(ctx.expression());
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitPostfixOp(com.tdstrategy.el.antlr.TdElParser.PostfixOpContext)
   */
  @Override public TdElValue visitPostfixOp(TdElParser.PostfixOpContext ctx) {
    String    variableName = ctx.variable().getText();
    TdElValue elValue      = resolvers.getValue(variableName);

    if (elValue.isDecimalCompatibleValue()) {
      TdElValue retValue = elValue;

      if (elValue.isIntegerValue()) {
        if (ctx.MINUSMINUS() != null) {
          // do --
          resolvers.addValue(variableName, elValue.getIntegerValue() - 1);
        } else if (ctx.PLUSPLUS() != null) {
          // do ++
          resolvers.addValue(variableName, elValue.getIntegerValue() + 1);
        }
      } else if (elValue.isLongValue()) {
        if (ctx.MINUSMINUS() != null) {
          // do --
          resolvers.addValue(variableName, elValue.getLongValue() - 1);
        } else if (ctx.PLUSPLUS() != null) {
          // do ++
          resolvers.addValue(variableName, elValue.getLongValue() + 1);
        }
      } else if (elValue.isDecimalValue()) {
        BigDecimal bgValue = elValue.getDecimalValue();

        if (ctx.MINUSMINUS() != null) {
          // do --
          resolvers.addValue(variableName, bgValue.subtract(new BigDecimal("1.0")));
        } else if (ctx.PLUSPLUS() != null) {
          // do ++
          resolvers.addValue(variableName, bgValue.add(new BigDecimal("1.0")));
        }
      } // end if-else

      // return original value
      return retValue;
    } // end if

    return new TdElValue();
  } // end method visitPostfixOp

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitPrefixOp(com.tdstrategy.el.antlr.TdElParser.PrefixOpContext)
   */
  @Override public TdElValue visitPrefixOp(TdElParser.PrefixOpContext ctx) {
    String    variableName = ctx.variable().getText();
    TdElValue elValue      = resolvers.getValue(variableName);
    TdElValue retValue     = new TdElValue();

    if (elValue.isDecimalCompatibleValue()) {
      if (elValue.isIntegerValue()) {
        if (ctx.MINUSMINUS() != null) {
          // do --
          retValue = new TdElValue(variableName, elValue.getIntegerValue() - 1);
          resolvers.addValue(retValue.getName(), retValue);
        } else if (ctx.PLUSPLUS() != null) {
          // do ++
          retValue = new TdElValue(variableName, elValue.getIntegerValue() + 1);
          resolvers.addValue(retValue.getName(), retValue);
        }
      } else if (elValue.isLongValue()) {
        if (ctx.MINUSMINUS() != null) {
          // do --
          retValue = new TdElValue(variableName, elValue.getLongValue() - 1);
          resolvers.addValue(retValue.getName(), retValue);
        } else if (ctx.PLUSPLUS() != null) {
          // do ++
          retValue = new TdElValue(variableName, elValue.getLongValue() + 1);
          resolvers.addValue(retValue.getName(), retValue);
        }
      } else if (elValue.isDecimalValue()) {
        BigDecimal bgValue = elValue.getDecimalValue();

        if (ctx.MINUSMINUS() != null) {
          // do --
          retValue = new TdElValue(variableName, bgValue.subtract(new BigDecimal("1.0")));
          resolvers.addValue(retValue.getName(), retValue);
        } else if (ctx.PLUSPLUS() != null) {
          // do ++
          retValue = new TdElValue(variableName, bgValue.add(new BigDecimal("1.0")));
          resolvers.addValue(retValue.getName(), retValue);
        }
      } // end if-else
    }   // end if

    return retValue;
  } // end method visitPrefixOp

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : primary #PriExpr
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitPriExpr(TdElParser.PriExprContext ctx) {
    return visit(ctx.primary());
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : block EOF
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitProgram(TdElParser.ProgramContext ctx) {
    try {
      if (ctx.expression() != null) {
        return visit(ctx.expression());
      } else if (ctx.block() != null) {
        return visit(ctx.block());
      } else if (ctx.programStatement() != null) {
        List<Object> results = new ArrayList<Object>();

        for (TdElParser.ProgramStatementContext programStatementContext : ctx.programStatement()) {
          TdElValue result = visit(programStatementContext);
          results.add((result != null) ? result.getValue() : null);
        }

        return new TdElValue(results);
      }
    } catch (ReturnException re) {
      return re.getRetValue();
    }

    return null;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitProgramStatement(com.tdstrategy.el.antlr.TdElParser.ProgramStatementContext)
   */
  @Override public TdElValue visitProgramStatement(TdElParser.ProgramStatementContext ctx) {
    if (ctx.expression() != null) {
      return visit(ctx.expression());
    } else if (ctx.block() != null) {
      return visit(ctx.block());
    }

    return null;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | REAL #RealValue.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitRealValue(TdElParser.RealValueContext ctx) {
    return new TdElValue(new BigDecimal(ctx.RealLiteral().getText()));
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitReturnStatement(com.tdstrategy.el.antlr.TdElParser.ReturnStatementContext)
   */
  @Override public TdElValue visitReturnStatement(TdElParser.ReturnStatementContext ctx) {
    throw new ReturnException(visit(ctx.expression()));
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | expression QUESTION expression COLON expression #Select.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitSelect(TdElParser.SelectContext ctx) {
    TdElValue condValue = visit(ctx.expression(0));

    if (condValue.isBooleanValue()) {
      if (Boolean.TRUE.equals(condValue.getBooleanValue())) {
        return visit(ctx.expression(1));
      } else {
        return visit(ctx.expression(2));
      }
    }

    if (logger.isDebugEnabled()) {
      logger.debug("'" + condValue.getStrValue() + "' needed to be boolean value.");
    }

    return new TdElValue();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitStatementBlock(com.tdstrategy.el.antlr.TdElParser.StatementBlockContext)
   */
  @Override public TdElValue visitStatementBlock(TdElParser.StatementBlockContext ctx) {
    return super.visitStatementBlock(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitStatementDo(com.tdstrategy.el.antlr.TdElParser.StatementDoContext)
   */
  @Override public TdElValue visitStatementDo(TdElParser.StatementDoContext ctx) {
    TdElValue retValue;

    while (true) {
      // do for body
      retValue = visit(ctx.statement());

      // while parExpression
      TdElValue loopValue = visit(ctx.parExpression());

      if (loopValue.getBooleanValue().equals(Boolean.FALSE)) {
        break;
      }
    }

    return retValue;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | SEMI #StatementEmpty.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitStatementEmpty(TdElParser.StatementEmptyContext ctx) {
    return new TdElValue(TdElValue.SUPPORT_TYPE.SKIP, "Skip", "");
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitStatementExpr(com.tdstrategy.el.antlr.TdElParser.StatementExprContext)
   */
  @Override public TdElValue visitStatementExpr(TdElParser.StatementExprContext ctx) {
    return super.visitStatementExpr(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : expression
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitStatementExpression(TdElParser.StatementExpressionContext ctx) {
    return visit(ctx.expression());
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | FOR LPAREN forControl RPAREN statement #StatementFor.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitStatementFor(TdElParser.StatementForContext ctx) {
    TdElValue                    retValue          = new TdElValue();
    TdElParser.ForControlContext forControlContext = ctx.forControl();
    TdElParser.ForInitContext    forInitContext    = forControlContext.forInit();
    TdElParser.ExpressionContext expressionContext = forControlContext.expression();
    TdElParser.ForUpdateContext  forUpdateContext  = forControlContext.forUpdate();

    // init For
    if (forInitContext != null) {
      visit(forInitContext);
    }

    // loop until expression evaluate to true
    while (true) {
      if (expressionContext != null) {
        TdElValue loopValue = visit(expressionContext);

        if (loopValue.getBooleanValue().equals(Boolean.FALSE)) {
          break;
        }
      }

      // do for body
      retValue = visit(ctx.statement());

      // for update
      if (forUpdateContext != null) {
        visit(forUpdateContext);
      }
    }

    return retValue;
  } // end method visitStatementFor

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitStatementForeach(com.tdstrategy.el.antlr.TdElParser.StatementForeachContext)
   */
  @Override public TdElValue visitStatementForeach(TdElParser.StatementForeachContext ctx) {
    TdElValue retValue  = new TdElValue();
    TdElValue listValue = visit(ctx.foreachControl());

    String variableName = listValue.getName();

    for (TdElValue value : listValue.getListValue()) {
      resolvers.addValue(variableName, value);
      retValue = visit(ctx.statement());
    }

    return retValue;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | IF parExpression statement (ELSE statement)? #StatementIf
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   *
   * @throws  NotSupportException  DOCUMENT ME!
   */
  @Override public TdElValue visitStatementIf(TdElParser.StatementIfContext ctx) {
    TdElValue exprValue = visit(ctx.parExpression());
    int       size      = ctx.statement().size();

    if (exprValue.isBooleanValue()) {
      if (Boolean.TRUE.equals(exprValue.getBooleanValue())) {
        return visit(ctx.statement(0));
      } else if (Boolean.FALSE.equals(exprValue.getBooleanValue())) {
        if (size == 2) {
          return visit(ctx.statement(1));
        } else {
          return new TdElValue();
        }
      }
    }

    return new TdElValue();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitStatementReturn(com.tdstrategy.el.antlr.TdElParser.StatementReturnContext)
   */
  @Override public TdElValue visitStatementReturn(TdElParser.StatementReturnContext ctx) {
    // TODO
    return super.visitStatementReturn(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitStatementSwitch(com.tdstrategy.el.antlr.TdElParser.StatementSwitchContext)
   */
  @Override public TdElValue visitStatementSwitch(TdElParser.StatementSwitchContext ctx) {
    return super.visitStatementSwitch(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitStatementWhile(com.tdstrategy.el.antlr.TdElParser.StatementWhileContext)
   */
  @Override public TdElValue visitStatementWhile(TdElParser.StatementWhileContext ctx) {
    TdElValue retValue = new TdElValue();

    while (true) {
      // while parExpression
      TdElValue loopValue = visit(ctx.parExpression());

      if (loopValue.getBooleanValue().equals(Boolean.FALSE)) {
        break;
      }

      // do for body
      retValue = visit(ctx.statement());
    }

    return retValue;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * | STRING #StringValue.
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitStringValue(TdElParser.StringValueContext ctx) {
    String text = ctx.StringLiteral().getText();

    if (text != null) {
      // trim front/end '"'
      int length = text.length();

      if (text.startsWith("\"") && text.endsWith("\"")) {
        text = text.substring(1, length - 1);
      } else if (text.startsWith("'") && text.endsWith("'")) {
        text = text.substring(1, length - 1);
      }

      return new TdElValue(text);
    }

    return new TdElValue();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitSwitchBlock(com.tdstrategy.el.antlr.TdElParser.SwitchBlockContext)
   */
  @Override public TdElValue visitSwitchBlock(TdElParser.SwitchBlockContext ctx) {
    return super.visitSwitchBlock(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitSwitchBlockStatementGroup(com.tdstrategy.el.antlr.TdElParser.SwitchBlockStatementGroupContext)
   */
  @Override public TdElValue visitSwitchBlockStatementGroup(TdElParser.SwitchBlockStatementGroupContext ctx) {
    return super.visitSwitchBlockStatementGroup(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitSwitchCase(com.tdstrategy.el.antlr.TdElParser.SwitchCaseContext)
   */
  @Override public TdElValue visitSwitchCase(TdElParser.SwitchCaseContext ctx) {
    return super.visitSwitchCase(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitSwitchDefault(com.tdstrategy.el.antlr.TdElParser.SwitchDefaultContext)
   */
  @Override public TdElValue visitSwitchDefault(TdElParser.SwitchDefaultContext ctx) {
    return super.visitSwitchDefault(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * : TRUE #TrueValue
   *
   * @param   ctx  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  @Override public TdElValue visitTrueValue(TdElParser.TrueValueContext ctx) {
    return new TdElValue(Boolean.TRUE);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitUnaryOp(com.tdstrategy.el.antlr.TdElParser.UnaryOpContext)
   */
  @Override public TdElValue visitUnaryOp(TdElParser.UnaryOpContext ctx) {
    int negative = 1;

    if (ctx.MINUS() != null) {
      negative = -1;
    }

    TdElValue rightSide = visit(ctx.expression());

    if (rightSide.isIntegerValue()) {
      return new TdElValue(negative * rightSide.getIntegerValue());
    }

    if (rightSide.isLongValue()) {
      return new TdElValue(negative * rightSide.getLongValue());
    }

    if (rightSide.isDecimalValue()) {
      if (negative == -1) {
        return new TdElValue(rightSide.getDecimalValue().negate());
      } else {
        return new TdElValue(rightSide.getDecimalValue());
      }
    }

    if (logger.isDebugEnabled()) {
      logger.debug("'" + rightSide.getStrValue() + "' - Decimal Value Needed.");
    }

    return new TdElValue();
  } // end method visitUnaryOp

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * @see  com.tdstrategy.el.antlr.TdElBaseVisitor#visitVariable(com.tdstrategy.el.antlr.TdElParser.VariableContext)
   */
  @Override public TdElValue visitVariable(TdElParser.VariableContext ctx) {
    return super.visitVariable(ctx); // To change body of overridden methods use File | Settings | File Templates.
  }
} // end class EvalVisitor
