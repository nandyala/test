package com.tdstrategy.el.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import java.math.BigDecimal;

import java.util.*;
import java.util.concurrent.TimeUnit;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

import org.ehcache.UserManagedCache;
import org.ehcache.ValueSupplier;

import org.ehcache.config.builders.ResourcePoolsBuilder;
import org.ehcache.config.builders.UserManagedCacheBuilder;

import org.ehcache.expiry.Duration;
import org.ehcache.expiry.Expiry;

import org.reflections.Reflections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tdstrategy.el.annotation.TdCacheable;
import com.tdstrategy.el.annotation.TdExposedClass;
import com.tdstrategy.el.annotation.TdExposedMethod;
import com.tdstrategy.el.antlr.TdElLexer;
import com.tdstrategy.el.antlr.TdElParser;
import com.tdstrategy.el.antlr.TdVerboseListener;
import com.tdstrategy.el.exception.UnknownVariableException;
import com.tdstrategy.el.util.CalculateUtil;
import com.tdstrategy.el.util.FunctionUtil;
import com.tdstrategy.el.util.NoCaseHashMap;


/**
 * Created with IntelliJ IDEA. User: rojer Date: 7/6/13 Time: 10:10 PM To change this template use File | Settings |
 * File Templates.
 *
 * @author   Rojer Luo
 * @version  $Revision$, $Date$
 */
public class ResolverContext {
  //~ Static fields/initializers ---------------------------------------------------------------------------------------

  private static NoCaseHashMap<ExposedMethod> exposedMethods = new NoCaseHashMap<ExposedMethod>();
  private static NoCaseHashMap<TdElContext>   sharedContext  = new NoCaseHashMap<TdElContext>();

  //~ Instance fields --------------------------------------------------------------------------------------------------

  private boolean batchMode = true;
  private boolean cacheMode = false;

  private NoCaseHashMap<TdElContext> context = new NoCaseHashMap<TdElContext>();

  // private NoCaseHashMap<TdElValue>   exprCache = new NoCaseHashMap<TdElValue>();
  private UserManagedCache<String, TdElValue> exprCache = null;
  private Logger                              logger    = LoggerFactory.getLogger(ResolverContext.class);

  private NoCaseHashMap<ExposedMethod> overrideMethods = new NoCaseHashMap<ExposedMethod>();

  //~ Constructors -----------------------------------------------------------------------------------------------------

  /**
   * Creates a new ResolverContext object.
   */
  public ResolverContext() {
    updateExposedValues();

  } // end ResolverContext

  //~ Methods ----------------------------------------------------------------------------------------------------------

  /**
   * addExposedClass - Add static methods of an exposed class.
   *
   * @param  clazz          Class
   * @param  annotatedOnly  boolean
   */
  public static synchronized void addExposedClass(Class clazz, boolean annotatedOnly) {
    for (Method method : clazz.getMethods()) {
      if ((!annotatedOnly) || method.isAnnotationPresent(TdExposedMethod.class)) {
        // if annotatedOnly is true then only add those method with annotations
        addExposedMethod(method);
      }
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * addExposedMethod - Add a exposed method if it is a static one.
   *
   * @param  method  Method
   */
  public static synchronized void addExposedMethod(Method method) {
    int    modifiers  = method.getModifiers();
    String methodName = method.getName().toLowerCase();

    if (Modifier.isStatic(modifiers)) {
      boolean cacheable = method.isAnnotationPresent(TdCacheable.class);
      exposedMethods.put(methodName, new ExposedMethod(methodName, method.getDeclaringClass()));

      if (method.getParameterCount() == 0) {
        // add shortcut variables for method
        sharedContext.put(methodName, new TdElContext(methodName, methodName, method.getReturnType(), true));
      }
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * addExposedPackage - Add all exposed methods for exposed classes under one package.
   *
   * @param  packageName  String
   */
  public static synchronized void addExposedPackage(String packageName) {
    Reflections        reflections = new Reflections(packageName);
    Set<Class<?>>      classes     = reflections.getTypesAnnotatedWith(TdExposedClass.class);
    Iterator<Class<?>> it          = classes.iterator();

    while (it.hasNext()) {
      Class<?> clazz = it.next();
      addExposedClass(clazz, true);
    } // end while
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * initWithCalculateUtil - init exposed methods with calculate utils.
   */
  public static synchronized void initWithCalculateUtil() {
    addExposedClass(CalculateUtil.class, false);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * addDefinition - Add an variable definition.
   *
   * @param  name        String
   * @param  expression  String
   * @param  resultType  Class
   */
  public void addDefinition(String name, String expression, Class resultType) {
    context.put(name, new TdElContext(name, expression, resultType, false));
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * addFunction - Add an function definition.
   *
   * @param  name        String
   * @param  expression  String
   * @param  resultType  Class
   */
  public void addFunction(String name, String expression, Class resultType) {
    addFunction(name, expression, resultType, true);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * addFunction - Add an function definition.
   *
   * @param  name        String
   * @param  expression  String
   * @param  resultType  Class
   * @param  cacheable   boolean
   */
  public void addFunction(String name, String expression, Class resultType, boolean cacheable) {
    String[] buf = expression.split("\\.");

    ExposedMethod exposedMethod = null;
    boolean       matched       = false;

    if (buf.length == 1) {
      // just using defined method name
      exposedMethod = exposedMethods.get(buf[0].split("\\(")[0]);

      if (exposedMethod != null) {
        overrideMethods.put(name, exposedMethod);

        matched = true;
      }
    } else if (buf.length == 2) {
      // using complete method with instance name
      TdElContext elContext  = getContext(buf[0]);
      String      methodName = buf[1].split("\\(")[0];

      if (elContext != null) {
        // the context is defined
        // then check the method
        exposedMethod = exposedMethods.get(methodName);

        if (exposedMethod != null) {
          // found a method with the different name
          if (name.equals(methodName)) {
            matched = true;
          }
          // then check the context is the same class?
          else if (exposedMethod.getMethodClass().equals(elContext.getTdElType().getClazz())) {
            // there are same class, so alias will be created
            overrideMethods.put(name, exposedMethod);
            matched = true;
          } else {
            // no match found, ignore this method
            exposedMethod = null;
          }
        }

        if (exposedMethod == null) {
          // can not found matched method,
          // create a runtime alias method
          // add to runtime map
          RuntimeMethod runtimeMethod = new RuntimeMethod(buf[0], methodName, elContext.getTdElType().getClazz());
          overrideMethods.put(name, runtimeMethod);
          matched = true;
        }
      } // end if
    }   // end if-else

    if (matched) {
      context.put(name, new TdElContext(name, expression, resultType, true));
    }
  } // end method addFunction

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * addValue - Add a variable with value.
   *
   * @param  name   String
   * @param  value  Object
   */
  public void addValue(String name, Object value) {
    if (value == null) {
      context.put(name, new TdElContext(name, new TdElValue()));
    } else if (value instanceof TdElValue) {
      context.put(name, new TdElContext(name, (TdElValue) value));
    } else {
      context.put(name, new TdElContext(name, new TdElValue(name, value), value.getClass()));
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * addValues - Load variables from map.
   *
   * @param  values  Map
   */
  public void addValues(Map<String, Object> values) {
    if (values != null) {
      for (Map.Entry<String, Object> entry : values.entrySet()) {
        addValue(entry.getKey(), entry.getValue());
      }
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * callFunction - Call a function with params.
   *
   * @param   functionName  String
   * @param   params        String
   *
   * @return  TdElValue
   */
  public TdElValue callFunction(String functionName, String params) {
    TdElValue tdElValue = null;

    TdElContext tdElContext = sharedContext.get(functionName);

    if (tdElContext == null) {
      tdElContext = getContext(functionName);
    }

    if (tdElContext != null) {
      tdElValue = tdElContext.getTdElValue();

      if ((tdElValue != null) && (tdElValue.isFunctionValue() || tdElValue.isExpressionValue())) {
        TdElValue value = null;

        if (params == null) {
          value = evalExpr(tdElValue.getStrValue());
        } else {
          // remove "("
          String[] buf = tdElValue.getStrValue().split("\\(");
          value = evalExpr(buf[0] + "(" + params + ")");
        }

        return value;
      }
    }

    return tdElValue;
  } // end method callFunction

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * clearDefinition - Clear all definition.
   */
  public void clearDefinition() {
    context.clear();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * clearVariableCache - Clear Cache for Variable.
   *
   * @param  variableName  DOCUMENT ME!
   */
  public void clearVariableCache(String variableName) {
    if (cacheMode) {
      exprCache.remove(variableName);
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * contains - Check there is a variable in the context.
   *
   * @param   name  String
   *
   * @return  boolean
   */
  public boolean contains(String name) {
    return context.containsKey(name);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * detectReturnType - Detect the return type for the expression.
   *
   * @param   expression  String
   *
   * @return  Class
   */
  public Class detectReturnType(String expression) {
    if (logger.isDebugEnabled()) {
      logger.debug("Detect Return for Expression:" + expression);
    }

    CharStream        input  = new ANTLRInputStream(expression);
    TdElLexer         lexer  = new TdElLexer(input);
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    TdElParser        parser = new TdElParser(tokens);

    lexer.removeErrorListeners();
    lexer.addErrorListener(new TdVerboseListener());
    parser.removeErrorListeners();
    parser.addErrorListener(new TdVerboseListener());

    VerifyVisitor visitor = new VerifyVisitor();

    // Loading Context
    visitor.setResolvers(this);

    try {
      ParseTree tree     = parser.entry(); // parse
      TdElValue retValue = visitor.visit(tree);
      Class     retClass = retValue.getClazz();

      if (logger.isDebugEnabled()) {
        logger.debug("Return Class:" + retClass);
      }

      return retClass;
    } catch (RuntimeException e) {
      if (logger.isDebugEnabled()) {
        logger.debug(e.toString());
      }
    } catch (Exception e) {
      if (logger.isDebugEnabled()) {
        logger.debug(e.toString());
      }
    } // end try-catch

    return null;
  } // end method detectReturnType

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * disableCache - Disable internal cache.
   */
  public void disableCache() {
    if (cacheMode) {
      if (exprCache != null) {
        exprCache.close();
      }

      cacheMode = false;
    }
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * enableCache - Enable the internal cache.
   *
   * @param  ttl  int - cache life in seconds
   */
  public void enableCache(final int ttl) {
    if (!cacheMode) {
      cacheMode = true;
    } else {
      if (exprCache != null) {
        exprCache.close();
      }
    }

    exprCache = UserManagedCacheBuilder.newUserManagedCacheBuilder(String.class, TdElValue.class).withResourcePools(
        ResourcePoolsBuilder.heap(1000)).withExpiry(new Expiry<String, TdElValue>() {
          @Override public Duration getExpiryForCreation(String key, TdElValue value) {
            return Duration.of(ttl, TimeUnit.SECONDS);
          }

          @Override public Duration getExpiryForAccess(String key, ValueSupplier<? extends TdElValue> value) {
            return null;
          }

          @Override public Duration getExpiryForUpdate(String key, ValueSupplier<? extends TdElValue> oldValue,
            TdElValue newValue) {
            return null;
          }
        }).build(false);

    exprCache.init();
  } // end method enableCache

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * endBatch - Batch mode ended.
   */
  public void endBatch() {
    batchMode = false;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * eval - Eval the expression.
   *
   * @param   expression  String
   *
   * @return  Object
   */
  public Object eval(String expression) {
    if (!batchMode) {
      updateExposedValues();
    }

    TdElValue value = evalExpr(expression);

    return (value != null) ? value.getValue() : null;
  }

  /**
   * Mock eval expression. When this method is called, its silent when reach exception.
   *
   * @param   expression  String
   *
   * @return  Object
   */
  public Object mockEval(String expression) {
    if (!batchMode) {
      updateExposedValues();
    }

    TdElValue value = evalExpr(expression, true);

    return (value != null) ? value.getValue() : null;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * eval - Eval the expressions with the same context.
   *
   * @param   expressions  String[]
   *
   * @return  List
   */
  public List<Object> eval(String[] expressions) {
    if (!batchMode) {
      updateExposedValues();
    }

    List<Object> results = null;

    if (expressions == null) {
      return results;
    } else if (expressions.length == 1) {
      results = new ArrayList<Object>();

      TdElValue value = evalExpr(expressions[0]);

      results.add((value != null) ? value.getValue() : null);

      return results;
    } else {
      StringBuilder sb = new StringBuilder();
      sb.append("{");

      boolean first = true;

      for (String expression : expressions) {
        if (!first) {
          sb.append(",");
        } else {
          first = false;
        }

        sb.append("{").append(expression).append("}");
      }

      sb.append("}");

      TdElValue value = evalExpr(sb.toString());

      if (value.getValue() != null) {
        results = new ArrayList<Object>();
        results.addAll((List) value.getValue());
      }

      return results;
    } // end if-else
  }   // end method eval

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * eval - Evaluate the expression with the designed type.
   *
   * @param   <T>         Class
   * @param   expression  String
   * @param   toType      Class
   *
   * @return  T
   */
  public <T> T eval(String expression, Class<T> toType) {
    Object value = eval(expression);

    if (value != null) {
      if (toType.equals(value.getClass())) {
        return (T) value;
      } else {
        if (toType.equals(BigDecimal.class)) {
          return (T) (new BigDecimal(value.toString()));
        } else if (toType.equals(Long.class) || toType.equals(long.class)) {
          return (T) (Long.valueOf(value.toString()));
        } else if (toType.equals(Integer.class) || toType.equals(int.class)) {
          return (T) (Integer.valueOf(value.toString()));
        } else if (toType.equals(String.class)) {
          return (T) (value.toString());
        }
      }
    }

    return null;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * getExposedMethod - Lookup in the exposed Method.
   *
   * @param   methodName  String
   *
   * @return  ExposedMethod
   */
  public ExposedMethod getExposedMethod(String methodName) {
    return exposedMethods.get(methodName);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * getNames - Get all variable names in the context.
   *
   * @return  Set
   */
  public Set<String> getNames() {
    return context.keySet();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   expression  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public Set<String> getNormalizedVariables(String expression) {
    if (logger.isDebugEnabled()) {
      logger.debug("Normalized Expression : '" + expression + "' ......");
    }

    CharStream        input  = new ANTLRInputStream(expression);
    TdElLexer         lexer  = new TdElLexer(input);
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    TdElParser        parser = new TdElParser(tokens);

    lexer.removeErrorListeners();
    lexer.addErrorListener(new TdVerboseListener());
    parser.removeErrorListeners();
    parser.addErrorListener(new TdVerboseListener());

    VerifyVisitor visitor = new VerifyVisitor();
    visitor.setResolvers(this);

    ParseTree tree = parser.entry(); // parse
    visitor.visit(tree);

    Set<String> usedVariables = new HashSet<String>();
    usedVariables.addAll(visitor.getUsedVariables());
    usedVariables.addAll(visitor.getNormalizedCascadedVariables());
    usedVariables.addAll(visitor.getUsedFunctions());
    usedVariables.addAll(visitor.getNormalizedCascadedFunctions());

    return usedVariables;
  } // end method getNormalizedVariables

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * getObjectValue - Get the value for the named variable.
   *
   * @param   name  String
   *
   * @return  Object
   */
  public Object getObjectValue(String name) {
    TdElValue tdElValue = getValue(name);

    if (tdElValue != null) {
      return tdElValue.getValue();
    }

    return null;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * getRuntimeMethod - Lookup overwritten runtime Method.
   *
   * @param   methodName  String
   *
   * @return  ExposedMethod
   */
  public ExposedMethod getRuntimeMethod(String methodName) {
    return overrideMethods.get(methodName);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * getUsedVariables - List all used variables in the expression.
   *
   * @param   expression  String
   *
   * @return  Set
   */
  public Set<String> getUsedVariables(String expression) {
    if (logger.isDebugEnabled()) {
      logger.debug("Verify Expression : '" + expression + "' ......");
    }

    CharStream        input  = new ANTLRInputStream(expression);
    TdElLexer         lexer  = new TdElLexer(input);
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    TdElParser        parser = new TdElParser(tokens);

    lexer.removeErrorListeners();
    lexer.addErrorListener(new TdVerboseListener());
    parser.removeErrorListeners();
    parser.addErrorListener(new TdVerboseListener());

    VerifyVisitor visitor = new VerifyVisitor();
    visitor.setResolvers(this);

    ParseTree tree = parser.entry(); // parse
    visitor.visit(tree);

    Set<String> usedVariables = new LinkedHashSet<>();
    usedVariables.addAll(visitor.getUsedVariables());
    usedVariables.addAll(visitor.getUsedFunctions());
    usedVariables.addAll(visitor.getOriginalCascadedVariables());
    usedVariables.addAll(visitor.getOriginalCascadedFunctions());
    usedVariables.addAll(visitor.getDefinedVariables());

    return usedVariables;
  } // end method getUsedVariables

  /**
   * getVariablePaths - List all variable Paths in the expression.
   *
   * @param   expression  String
   *
   * @return  Set
   */
  public Set<String> getVariablePaths(String expression) {
    if (logger.isDebugEnabled()) {
      logger.debug("Verify Expression : '" + expression + "' ......");
    }

    CharStream        input  = new ANTLRInputStream(expression);
    TdElLexer         lexer  = new TdElLexer(input);
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    TdElParser        parser = new TdElParser(tokens);

    lexer.removeErrorListeners();
    lexer.addErrorListener(new TdVerboseListener());
    parser.removeErrorListeners();
    parser.addErrorListener(new TdVerboseListener());

    VerifyVisitor visitor = new VerifyVisitor();
    visitor.setResolvers(this);

    ParseTree tree = parser.entry(); // parse
    visitor.visit(tree);

    Set<String> variablePaths = new LinkedHashSet<>();
    variablePaths.addAll(visitor.getCallPaths());

    return variablePaths;
  } // end method getUsedVariables

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * getValue - Get TdElValue for variable.
   *
   * @param   name  String
   *
   * @return  TdElValue
   */
  public TdElValue getValue(String name) {
    TdElValue tdElValue = null;

    if (cacheMode && exprCache.containsKey(name)) {
      tdElValue = exprCache.get(name);

      if (logger.isDebugEnabled()) {
        logger.debug("Load value from cache for name : '" + name + "' --> "
          + ((tdElValue == null) ? null : tdElValue.getValue()));
      }

      return tdElValue;
    } else {
      TdElContext tdElContext = sharedContext.get(name);

      if (tdElContext == null) {
        tdElContext = getContext(name);
      }

      if (tdElContext != null) {
        tdElValue = tdElContext.getTdElValue();

        if (tdElValue != null) {
          if (tdElValue.isExpressionValue()) {
            TdElValue value = evalExpr(tdElValue.getStrValue());

            if (cacheMode && value.isCacheable()) {
              exprCache.put(name, value);
            }

            return value;
          } else if (tdElValue.isFunctionValue()) {
            String expr = tdElValue.getStrValue();

            if (!expr.endsWith(")")) {
              expr += "()";
            }

            TdElValue value = evalExpr(expr);

            return value;
          }
        }
      } // end if

      return tdElValue;
    } // end if-else
  }   // end method getValue

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * getValueType - Get the TdElValue Type for the variable.
   *
   * @param   name  String
   *
   * @return  TdElValue
   */
  public TdElValue getValueType(String name) {
    TdElContext tdElContext = getContext(name);

    if (tdElContext != null) {
      TdElValue tdElValue = tdElContext.getTdElType();
      if(tdElValue.isMapValue()){
        tdElValue = tdElContext.getTdElValue();
      }
      return tdElValue;
    }

    return null;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * startBatch - Starting the batch mode.
   */
  public void startBatch() {
    batchMode = true;

    updateExposedValues();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * updateExposedValues - Refresh the exposed values.
   */
  public void updateExposedValues() {
    // clear all expression cache
    if (cacheMode) {
      exprCache.close();
      exprCache.init();
    }

    String[] names = getExposedValueNames();

    if ((names != null) && (names.length > 0)) {
      for (String name : names) {
        try {
          Method method = FunctionUtil.getGetterMethod(getClass(), name);

          Object value = null;
          value = method.invoke(this, new Object[] {});

          if (logger.isDebugEnabled()) {
            logger.debug("Found '" + name + "', updated....");
          }

          context.put(name, new TdElContext(name, new TdElValue(name, value), method.getReturnType()));
        } catch (IllegalAccessException e) {
          if (logger.isDebugEnabled()) {
            logger.debug("'" + name + "' not found...Ignore...");
          }
        } catch (InvocationTargetException e) {
          if (logger.isDebugEnabled()) {
            logger.debug("'" + name + "' not found...Ignore...");
          }
        } catch (NullPointerException e) {
          if (logger.isDebugEnabled()) {
            logger.debug("'" + name + "' not found...Ignore...");
          }
        } catch (NoSuchFieldException e) {
          if (logger.isDebugEnabled()) {
            logger.debug("'" + name + "' not found...Ignore...");
          }
        } // end try-catch
      }   // end for
    }     // end if
  }       // end method updateExposedValues

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * verify - Verify the expression.
   *
   * @param   expression  String
   *
   * @return  boolean
   *
   * @throws  UnknownVariableException  exception
   */
  public boolean verify(String expression) {
    if (logger.isDebugEnabled()) {
      logger.debug("Verify Expression : '" + expression + "' ......");
    }

    CharStream        input  = new ANTLRInputStream(expression);
    TdElLexer         lexer  = new TdElLexer(input);
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    TdElParser        parser = new TdElParser(tokens);

    lexer.removeErrorListeners();
    lexer.addErrorListener(new TdVerboseListener());
    parser.removeErrorListeners();
    parser.addErrorListener(new TdVerboseListener());

    VerifyVisitor visitor = new VerifyVisitor();
    visitor.setResolvers(this);

    if (logger.isDebugEnabled()) {
      logger.debug("Parsing Expression...");
    }

    try {
      ParseTree tree = parser.entry(); // parse
      visitor.visit(tree);

      if (logger.isDebugEnabled()) {
        logger.debug("Verify Completed...");
      }
    } catch (NullPointerException e) {
      if (logger.isDebugEnabled()) {
        logger.debug(e.getMessage(), e);
      }

      if (visitor.hasUnknownVariables()) {
        throw new UnknownVariableException(visitor.getUnknownVariableNames());
      }

      return false;
    }

    if (visitor.hasUnknownVariables()) {
      throw new UnknownVariableException(visitor.getUnknownVariableNames());
    }

    return true;
  } // end method verify

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * evalExpr - Eval the expression.
   *
   * @param   expression  String
   *
   * @return  TdElValue
   */
  protected TdElValue evalExpr(String expression) {
    return evalExpr(expression, false);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * evalExpr - Eval the expression.
   *
   * @param   expression  String
   * @param   silent      boolean
   *
   * @return  TdElValue
   */
  protected TdElValue evalExpr(String expression, boolean silent) {
    if (logger.isDebugEnabled()) {
      logger.debug("Eval Expression : '" + expression + "' ......");
    }

    TdElValue retValue = null;

    if (expression == null) {
      return null;
    } else if (expression.trim().length() == 0) {
      return new TdElValue();
    }

    if (cacheMode && exprCache.containsKey(expression)) {
      retValue = exprCache.get(expression);

      if (logger.isDebugEnabled()) {
        logger.debug("Load value from cache for Expression : '" + expression + "' --> "
          + ((retValue == null) ? null : retValue.getValue()));
      }

      return retValue;
    } else {
      try {
        CharStream        input  = new ANTLRInputStream(expression);
        TdElLexer         lexer  = new TdElLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        TdElParser        parser = new TdElParser(tokens);

        lexer.removeErrorListeners();
        lexer.addErrorListener(new TdVerboseListener());
        parser.removeErrorListeners();
        parser.addErrorListener(new TdVerboseListener());

        EvalVisitor visitor = new EvalVisitor(silent);

        visitor.setResolvers(this);

        ParseTree tree = parser.entry(); // parse
        retValue = visitor.visit(tree);

        if (cacheMode && retValue.isCacheable()) {
          exprCache.put(expression, retValue);

          if (logger.isDebugEnabled()) {
            logger.debug("Store value to cache for  Expression : '" + expression + "'");
          }
        }
      } catch (Exception e) {
        logger.error("Return null due to " + e.getMessage());

        if (logger.isDebugEnabled()) {
          logger.debug(e.getMessage(), e);
        }
      } // end try-catch

      if (logger.isDebugEnabled()) {
        logger.debug("Eval '" + expression + "' --> " + ((retValue == null) ? null : retValue.getValue()));
      }

      return retValue;
    } // end if-else
  }   // end method evalExpr

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param   name  DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  protected TdElContext getContext(String name) {
    return context.get(name);
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * getExposedValueNames - Get all exposed value names\.
   *
   * @return  String[]
   */
  protected String[] getExposedValueNames() {
    return new String[] {};
  }
} // end class ResolverContext
