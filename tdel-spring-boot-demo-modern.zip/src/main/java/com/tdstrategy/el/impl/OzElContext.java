package com.tdstrategy.el.impl;

/**
 * Created with IntelliJ IDEA. User: rojer Date: 11/13/13 Time: 2:47 PM To change this template use File | Settings |
 * File Templates.
 *
 * @author   Rojer Luo
 * @version  $Revision$, $Date$
 */
public class TdElContext {
  //~ Instance fields --------------------------------------------------------------------------------------------------

  /** DOCUMENT ME! */
  protected String name;

  /** DOCUMENT ME! */
  protected TdElValue tdElType;

  /** DOCUMENT ME! */
  protected TdElValue tdElValue;

  //~ Constructors -----------------------------------------------------------------------------------------------------

  /**
   * Creates a new TdElContext object.
   *
   * @param  name       DOCUMENT ME!
   * @param  tdElValue  DOCUMENT ME!
   */
  public TdElContext(String name, TdElValue tdElValue) {
    this.name      = name;
    this.tdElValue = tdElValue;

    if (!tdElValue.isExpressionValue()) {
      this.tdElType = tdElValue;
    }
  }

  /**
   * Creates a new TdElContext object.
   *
   * @param  name        DOCUMENT ME!
   * @param  tdElValue   DOCUMENT ME!
   * @param  resultType  DOCUMENT ME!
   */
  public TdElContext(String name, TdElValue tdElValue, Class resultType) {
    this.name      = name;
    this.tdElType  = TdElValue.createTdElType(name, resultType);

    this.tdElValue = tdElValue;
  }

  /**
   * Creates a new TdElContext object.
   *
   * @param  name        DOCUMENT ME!
   * @param  expression  DOCUMENT ME!
   * @param  resultType  DOCUMENT ME!
   * @param  isFunction  DOCUMENT ME!
   */
  public TdElContext(String name, String expression, Class resultType, boolean isFunction) {
    this.name     = name;
    this.tdElType = TdElValue.createTdElType(name, resultType);

    if (!isFunction) {
      this.tdElValue = TdElValue.createExpression(name, expression);
    } else {
      this.tdElValue = TdElValue.createFunction(name, expression);
    }
  }

  //~ Methods ----------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public String getName() {
    return name;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public TdElValue getTdElType() {
    return tdElType;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public TdElValue getTdElValue() {
    return tdElValue;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @return  DOCUMENT ME!
   */
  public Object getValue() {
    return (tdElValue == null) ? null : tdElValue.getValue();
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param  name  DOCUMENT ME!
   */
  public void setName(String name) {
    this.name = name;
  }

  //~ ------------------------------------------------------------------------------------------------------------------

  /**
   * DOCUMENT ME!
   *
   * @param  tdElValue  DOCUMENT ME!
   */
  public void updateValue(TdElValue tdElValue) {
    this.tdElValue = tdElValue;

    if (!tdElValue.isExpressionValue()) {
      this.tdElType = tdElValue;
    }
  }
} // end class TdElContext
