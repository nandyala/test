package com.visionocr.azure;

import com.visionocr.domain.ClassificationOutput;
import com.visionocr.domain.ExtractionOutput;

import java.nio.file.Path;

/**
 * Our own seam over Azure Document Intelligence. Batch components depend on this,
 * never on the Azure SDK, so they can be tested with {@link StubDocIntelClient}.
 */
public interface DocIntelClient {

    /** Classifier id used by {@link #classify}, recorded in DOC_AZURE_RESULT. */
    String classifierId();

    /** Runs the custom classifier (split mode auto). One entry per document found in the file. */
    ClassificationOutput classify(Path file);

    /** Runs a custom extraction model. pages may be null (all pages) or e.g. "1-2". */
    ExtractionOutput analyze(String modelId, Path file, String pages);
}
