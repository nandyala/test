package com.visionocr.batch;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Runs the real XML job (stub Azure client, in-memory H2) over samples/stub-input,
 * including automatic retry and an operator reprocess request.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EndToEndJobTest {

    private static ClassPathXmlApplicationContext ctx;
    private static JdbcTemplate jdbc;

    @BeforeAll
    static void setUp() throws IOException {
        Path work = Files.createTempDirectory("vision-ocr-e2e");
        Path input = work.resolve("input");
        copyTree(Path.of("samples/stub-input"), input);

        byte[] key = new byte[32];
        new SecureRandom().nextBytes(key);

        System.setProperty("spring.profiles.active", "stub");
        System.setProperty("config.file", work.resolve("none.properties").toString());
        System.setProperty("db.url", "jdbc:h2:mem:e2e;MODE=PostgreSQL;DB_CLOSE_DELAY=-1");
        System.setProperty("input.dir", input.toString());
        System.setProperty("security.field-encryption-key", Base64.getEncoder().encodeToString(key));
        System.setProperty("retry.base-delay-minutes", "0");   // retry immediately on the next run

        ctx = new ClassPathXmlApplicationContext("job-context.xml");
        jdbc = ctx.getBean("jdbcTemplate", JdbcTemplate.class);
    }

    @AfterAll
    static void tearDown() {
        if (ctx != null) {
            ctx.close();
        }
        for (String p : new String[] {"spring.profiles.active", "config.file", "db.url", "input.dir",
                "security.field-encryption-key", "retry.base-delay-minutes"}) {
            System.clearProperty(p);
        }
    }

    @Test
    @Order(1)
    void firstRunProcessesSamples() throws Exception {
        runJob();
        Map<String, String> status = statuses();
        assertEquals("COMPLETED", status.get("apa-typed-good.pdf"));
        assertEquals("COMPLETED", status.get("apa-folder-hint.pdf"));
        assertEquals("REVIEW", status.get("apa-handwritten-review.tif"));
        assertEquals("REVIEW", status.get("unknown-letter.pdf"));
        assertEquals("ERROR", status.get("apa-throttled.pdf"), "429 -> retryable");
        assertEquals("FAILED", status.get("apa-corrupt.pdf"), "400 -> not retryable");

        String reasons = jdbc.queryForObject(
                "SELECT review_reasons FROM doc_job WHERE file_name = 'apa-handwritten-review.tif'", String.class);
        assertTrue(reasons.contains("INVALID:routingNumber:ROUTING_CHECKSUM_FAILED"), reasons);
        assertTrue(reasons.contains("INVALID:signature:NOT_SIGNED"), reasons);
        assertTrue(reasons.contains("LOW_CONFIDENCE:checkingAccountNumber"), reasons);
        assertTrue(reasons.contains("ACCOUNT_HOLDER_NAME_MISMATCH"), reasons);

        // Sensitive values encrypted at rest, masked for display
        Map<String, Object> routing = jdbc.queryForMap("SELECT f.field_value, f.display_value FROM doc_field f "
                + "JOIN doc_job j ON j.id = f.doc_id WHERE j.file_name = 'apa-typed-good.pdf' AND f.field_name = 'routingNumber'");
        assertEquals("*****0021", routing.get("display_value"));
        assertTrue(((String) routing.get("field_value")).startsWith("enc:v1:"));

        // Azure JSON stored per call, encrypted
        String fieldsJson = jdbc.queryForObject("SELECT r.fields_json FROM doc_azure_result r JOIN doc_job j ON j.id = r.doc_id "
                + "WHERE j.file_name = 'apa-typed-good.pdf' AND r.operation = 'EXTRACT' AND r.is_current = TRUE", String.class);
        assertTrue(fieldsJson.startsWith("enc:v1:"));

        // Errors recorded with retryable flag
        assertEquals(Boolean.TRUE, jdbc.queryForObject("SELECT e.retryable FROM doc_error e JOIN doc_job j ON j.id = e.doc_id "
                + "WHERE j.file_name = 'apa-throttled.pdf'", Boolean.class));
        assertEquals(Boolean.FALSE, jdbc.queryForObject("SELECT e.retryable FROM doc_error e JOIN doc_job j ON j.id = e.doc_id "
                + "WHERE j.file_name = 'apa-corrupt.pdf'", Boolean.class));
    }

    @Test
    @Order(2)
    void secondRunRetriesTheThrottledDocument() throws Exception {
        runJob();
        Map<String, String> status = statuses();
        assertEquals("COMPLETED", status.get("apa-throttled.pdf"));
        assertEquals("FAILED", status.get("apa-corrupt.pdf"), "non-retryable failures are not retried automatically");
        assertEquals(6, jdbc.queryForObject("SELECT COUNT(*) FROM doc_job", Integer.class), "nothing ingested twice");

        String path = String.join(" > ", jdbc.queryForList("SELECT h.to_status FROM doc_status_history h "
                + "JOIN doc_job j ON j.id = h.doc_id WHERE j.file_name = 'apa-throttled.pdf' ORDER BY h.id", String.class));
        assertEquals("NEW > CLASSIFIED > ERROR > CLASSIFIED > EXTRACTED > COMPLETED", path);
    }

    @Test
    @Order(3)
    void reprocessRequestReMapsWithoutCallingAzure() throws Exception {
        Long id = jdbc.queryForObject("SELECT id FROM doc_job WHERE file_name = 'apa-handwritten-review.tif'", Long.class);
        jdbc.update("INSERT INTO doc_reprocess_request (from_stage, doc_id, reason, requested_by) VALUES ('MAP', ?, 'rules changed', 'test')", id);

        runJob();

        assertEquals("APPLIED", jdbc.queryForObject("SELECT state FROM doc_reprocess_request WHERE doc_id = ?", String.class, id));
        assertEquals("REVIEW", jdbc.queryForObject("SELECT status FROM doc_job WHERE id = ?", String.class, id));
        assertEquals(1, jdbc.queryForObject(
                "SELECT COUNT(*) FROM doc_azure_result WHERE doc_id = ? AND operation = 'EXTRACT'", Integer.class, id),
                "MAP reprocess must reuse the stored Azure result");
        assertEquals(1, jdbc.queryForObject(
                "SELECT COUNT(*) FROM doc_status_history WHERE doc_id = ? AND stage = 'REPROCESS'", Integer.class, id));
        assertTrue(jdbc.queryForObject("SELECT COUNT(*) FROM doc_field WHERE doc_id = ?", Integer.class, id) > 0);
    }

    @Test
    @Order(4)
    void correctionWinsInFinalView() {
        Long id = jdbc.queryForObject("SELECT id FROM doc_job WHERE file_name = 'apa-typed-good.pdf'", Long.class);
        jdbc.update("INSERT INTO doc_field_correction (doc_id, field_name, original_value, corrected_value, display_value, "
                + "reason, corrected_by) VALUES (?, 'customerName', 'JOHN Q SAMPLE', 'JOHN Q. SAMPLE JR', 'JOHN Q. SAMPLE JR', "
                + "'OCR_MISREAD', 'reviewer1')", id);
        Map<String, Object> row = jdbc.queryForMap("SELECT final_value, value_source FROM v_doc_field_final "
                + "WHERE doc_id = ? AND field_name = 'customerName'", id);
        assertEquals("JOHN Q. SAMPLE JR", row.get("final_value"));
        assertEquals("CORRECTED", row.get("value_source"));
    }

    private static void runJob() throws Exception {
        JobLauncher launcher = ctx.getBean("jobLauncher", JobLauncher.class);
        Job job = ctx.getBean("docExtractionJob", Job.class);
        JobExecution exec = launcher.run(job, new JobParametersBuilder().addLong("run.ts", System.nanoTime()).toJobParameters());
        assertEquals(BatchStatus.COMPLETED, exec.getStatus(), exec.getAllFailureExceptions().toString());
    }

    private static Map<String, String> statuses() {
        return jdbc.queryForList("SELECT file_name, status FROM doc_job").stream()
                .collect(Collectors.toMap(r -> (String) r.get("file_name"), r -> (String) r.get("status")));
    }

    private static void copyTree(Path from, Path to) throws IOException {
        try (Stream<Path> walk = Files.walk(from)) {
            for (Path p : (Iterable<Path>) walk::iterator) {
                Path target = to.resolve(from.relativize(p).toString());
                if (Files.isDirectory(p)) {
                    Files.createDirectories(target);
                } else {
                    Files.copy(p, target);
                }
            }
        }
    }
}
