package com.visionocr.batch;

import com.visionocr.domain.DocumentRecord;
import com.visionocr.security.FieldEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Keeps the full Azure AnalyzeResult JSON per document (encrypted when a key is set) for audit,
 * debugging and building new training labels. Swap for a Blob Storage implementation in Azure.
 */
public class RawResultStore {

    private static final Logger log = LoggerFactory.getLogger(RawResultStore.class);

    private final boolean enabled;
    private final Path dir;
    private final FieldEncryptor encryptor;

    public RawResultStore(boolean enabled, String dir, FieldEncryptor encryptor) {
        this.enabled = enabled;
        this.dir = Path.of(dir);
        this.encryptor = encryptor;
    }

    public void save(DocumentRecord doc, String json) {
        if (!enabled || json == null) {
            return;
        }
        try {
            Files.createDirectories(dir);
            Files.writeString(dir.resolve(doc.getId() + ".json"), encryptor.encrypt(json), StandardCharsets.UTF_8);
        } catch (IOException e) {
            // Not fatal: the simplified fields are still stored in the DB.
            log.warn("{} could not store raw result: {}", doc, e.getMessage());
        }
    }
}
