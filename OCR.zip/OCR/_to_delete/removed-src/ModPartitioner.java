package com.visionocr.batch;

import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;

import java.util.HashMap;
import java.util.Map;

/**
 * Splits work by MOD(id, gridSize). Each partition's reader filters on its own slice, so
 * gridSize = number of concurrent Azure calls. Keep it within your Azure TPS quota.
 */
public class ModPartitioner implements Partitioner {

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {
        Map<String, ExecutionContext> map = new HashMap<>();
        for (int i = 0; i < gridSize; i++) {
            ExecutionContext ctx = new ExecutionContext();
            ctx.putInt("partition", i);
            ctx.putInt("gridSize", gridSize);
            map.put("partition" + i, ctx);
        }
        return map;
    }
}
