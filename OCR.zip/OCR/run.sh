#!/usr/bin/env bash
# Usage:  ./run.sh            -> real Azure (needs AZURE_DI_ENDPOINT etc.)
#         ./run.sh stub       -> offline run over samples/stub-input (no Azure needed)
set -euo pipefail
JAR=target/vision-ocr-batch.jar
[ -f "$JAR" ] || mvn -q -DskipTests package
if [ "${1:-}" = "stub" ]; then
  exec java -Dspring.profiles.active=stub -Dinput.dir=samples/stub-input \
            -Ddb.url="jdbc:h2:file:./data/db/stub;MODE=PostgreSQL;AUTO_SERVER=TRUE" \
            -jar "$JAR" job-context.xml docExtractionJob -next
fi
exec java -jar "$JAR" job-context.xml docExtractionJob -next
