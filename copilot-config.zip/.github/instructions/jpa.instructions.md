---
applyTo: "**/entity/**/*.java,**/domain/**/*.java,**/repository/**/*.java,**/service/**/*.java"
---
# JPA / Hibernate rules
- Never expose entities in REST APIs. Map to DTO records (MapStruct or hand-written); use interface/record projections for read-only queries.
- All associations LAZY. No FetchType.EAGER. Prevent N+1 with @EntityGraph, JOIN FETCH, or projections; never fetch-join multiple collections.
- Always paginate list endpoints (Pageable with a max page size). Never return unbounded lists.
- Transactions belong on the service layer: @Transactional(readOnly = true) for reads, @Transactional for writes. Keep transactions short; no remote calls inside them.
- Use @Version for optimistic locking on mutable aggregates. Handle OptimisticLockingFailureException explicitly.
- Entities: no Lombok @Data; implement equals/hashCode on a stable business key or id carefully; no-arg constructor protected; no business logic dependent on lazy loading outside a transaction.
- Schema changes only through Flyway (or Liquibase) migrations; never rely on ddl-auto. Migrations are forward-only, idempotent where possible, backward-compatible for rolling deploys (expand/contract).
- Add indexes for every foreign key and every filtered/sorted column; justify them in the migration.
- Use parameterized queries only (Spring Data derived queries, @Query with named params). Never concatenate input into JPQL/SQL.
- Batch writes: saveAll with hibernate.jdbc.batch_size; avoid IDENTITY generation where batching matters (use sequences).
- Repository tests: @DataJpaTest with Testcontainers using the production DB engine, not H2.
