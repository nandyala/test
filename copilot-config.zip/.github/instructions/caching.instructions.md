---
applyTo: "**/service/**/*.java,**/config/**/*.java,**/application*.yml,**/application*.properties"
---
# Caching rules
- Static / reference data (countries, codes, lookup tables, feature config) is cached at the SERVICE layer with Spring Cache (@Cacheable), not in controllers or repositories.
- Default provider: Caffeine (spring-boot-starter-cache + com.github.ben-manes.caffeine:caffeine). Use Redis only if the cache must be shared or invalidated across instances.
- Every cache must define: maximumSize, a TTL (expireAfterWrite), and recordStats. No unbounded caches.
- Cache immutable DTO records, never JPA entities (no lazy-proxy or detached-entity leaks).
- Use explicit, stable keys; use @Cacheable(sync = true) for expensive loads to avoid cache stampede.
- Admin/update paths must @CacheEvict or @CachePut the affected entries (after commit).
- Remember proxy rules: @Cacheable does not work on self-invocation or private methods.
- Do not enable the Hibernate second-level cache by default. If needed, only for @Immutable/read-only entities with READ_ONLY concurrency and a JCache provider.
- Never cache user-specific or security-sensitive data in a shared cache without the user/tenant in the key.
- Expose cache metrics through Micrometer/Actuator (hit rate, size, evictions) and add a test proving caching and eviction work.
- HTTP layer for static endpoints: set Cache-Control and ETag (ShallowEtagHeaderFilter or ResponseEntity.eTag) so browsers/CDNs can cache.
