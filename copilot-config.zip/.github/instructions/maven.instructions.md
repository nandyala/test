---
applyTo: "**/pom.xml"
---
# Maven rules
- Inherit from spring-boot-starter-parent (or import spring-boot-dependencies BOM). Do not declare versions for BOM-managed dependencies.
- Use the Maven Wrapper (mvnw) and pin the Maven version. java.version=21.
- Keep maven-enforcer-plugin rules: requireJavaVersion, requireMavenVersion, dependencyConvergence, banDuplicatePomDependencyVersions.
- Unit tests via surefire (*Test), integration tests via failsafe (*IT); run `./mvnw -B verify` in CI.
- Add quality gates: JaCoCo coverage threshold, Spotless/Checkstyle, SpotBugs.
- Supply chain: generate a CycloneDX SBOM; run OWASP dependency-check (or equivalent) in CI; Dependabot/Renovate for updates.
- Never add a dependency without stating why; prefer Boot starters over raw libraries. No SNAPSHOT or milestone versions in release builds.
