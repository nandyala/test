---
applyTo: "**/*.java,**/application*.yml,**/application*.properties"
---
# Production hardening rules
## Configuration
- No secrets in code, properties, or Git. Read from environment variables or a secret manager. Profiles: application-prod must be secure by default.
- spring.jpa.open-in-view=false; spring.jpa.hibernate.ddl-auto=none (or validate); server.error.include-stacktrace=never; server.error.include-message=never.
- server.shutdown=graceful with spring.lifecycle.timeout-per-shutdown-phase set.
- HikariCP: explicit maximum-pool-size, connection-timeout, max-lifetime below the DB/proxy idle limit. Set query/statement timeouts.
- Set explicit timeouts (connect/read) on every outbound HTTP client. Add retries only for idempotent calls, with backoff and a circuit breaker/bulkhead (Resilience4j or Spring Framework 7 resilience features).

## Web security
- Spring Security: deny by default (anyRequest().authenticated()), method security (@PreAuthorize) for authorization, authorization checked server-side on every object access (prevent IDOR).
- Stateless APIs: OAuth2 resource server with JWT validation (issuer, audience, algorithms pinned). Cookie/session auth: keep CSRF enabled with the Angular XSRF cookie pattern.
- CORS: explicit allowed origins/methods/headers; never "*" with credentials.
- Security headers: HSTS, Content-Security-Policy, X-Content-Type-Options, frame protection, Referrer-Policy.
- Validate all input with Jakarta Validation (@Valid) at the boundary; limit request, multipart and JSON payload sizes. Rate-limit auth and expensive endpoints (gateway preferred, otherwise Bucket4j).
- Passwords: DelegatingPasswordEncoder (bcrypt/argon2). Never log passwords, tokens, or PII; never return internal exception details.
- SSRF: never fetch user-supplied URLs without an allowlist.

## Observability and operations
- Actuator: expose only health, info, prometheus; run on a separate management port or require auth; liveness/readiness probes enabled; no env/heapdump/beans exposure.
- Structured JSON logging (logging.structured.format.console) with trace/correlation IDs; no sensitive data. Micrometer metrics + OpenTelemetry tracing.
- Audit logging for authentication, authorization failures and data changes.
- Container: non-root user, read-only filesystem, JVM -XX:MaxRAMPercentage, layered image or spring-boot:build-image.
