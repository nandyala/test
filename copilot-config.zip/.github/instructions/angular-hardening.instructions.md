---
applyTo: "**/*.ts,**/*.html"
---
# Angular production rules
- Never use bypassSecurityTrust*, innerHTML with untrusted data, or eval-like patterns. Rely on Angular's sanitization.
- Do not store tokens in localStorage/sessionStorage. Prefer HttpOnly, Secure, SameSite cookies (BFF or session) or in-memory tokens with silent refresh.
- Central HTTP error handling and auth in functional interceptors; never swallow errors; show user-safe messages.
- Route guards are UX only; the backend enforces authorization.
- Cache static reference data on the client (resource/httpResource or a signal-based store with shareReplay-style reuse) and respect server Cache-Control.
- Lazy-load routes, use @defer for heavy blocks, track by id in @for, and keep strict mode and strict templates on.
- No secrets or environment-specific URLs hard-coded; runtime config injected at deploy time.
- Builds: `npm ci` with the lockfile, `npm audit` in CI, CSP-compatible output (no inline scripts).
