# Project context
- Existing application. Backend: Java 21, Spring Boot 4.1.0 (Spring Framework 7, Security 7, Data 2026.0), Maven, JPA/Hibernate. Frontend: Angular 22, TypeScript 6.
- Read pom.xml and package.json for real versions before suggesting code. Follow existing structure and conventions; do not refactor unrelated code.
- Never change dependency versions or add dependencies unless asked. Versions managed by the Spring Boot BOM must not be overridden.
- Do not use deprecated or removed APIs. If unsure an API exists in this version, say so.
- Security, correctness and operability beat cleverness. Follow OWASP Top 10 / ASVS and 12-factor principles.
- Every change includes tests. After changes, state the Maven/npm commands to verify.

# Backend basics
- Java 21: records for DTOs, sealed types, pattern matching, switch expressions. Constructor injection only.
- Spring Boot 4 modular starters (spring-boot-starter-webmvc, spring-boot-starter-webmvc-test). Jackson 3 (tools.jackson.*). @MockitoBean not @MockBean.
- Security: Spring Security 7 lambda DSL only. Errors returned as ProblemDetail.
- Prefer RestClient / HTTP interface clients over RestTemplate. Config via @ConfigurationProperties records.

# Frontend basics
- Standalone components, signals, new control flow, inject(), OnPush, no zone.js-dependent patterns.
- Signal Forms for new forms; httpResource/resource for reads. Strict TypeScript, no `any`.
