# Copilot configuration (Java 21 / Spring Boot 4.1 / Angular 22 / Maven / JPA)

Unzip into the ROOT of your existing repository (merges into .github/).

1. Review every file and adjust to your project (remove rules for tech you don't use, e.g. Redis, Resilience4j).
2. Fill in details in .github/copilot-instructions.md if needed (npm vs pnpm, test framework).
3. Optionally copy matching files from https://github.com/github/awesome-copilot into
   .github/instructions/ and .github/prompts/, and edit them so they don't contradict these rules
   (e.g. remove @MockBean, NgModule, spring-boot-starter-web advice).
4. Commit the .github folder. In IntelliJ: Tools > GitHub Copilot > Customizations to verify they are picked up.

Instruction files guide Copilot; they do not enforce anything. Back them with CI gates (enforcer, SpotBugs, CodeQL, dependency-check).
