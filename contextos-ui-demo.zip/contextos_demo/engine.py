from __future__ import annotations

import json, math, re
from collections import Counter
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import yaml
except Exception:  # minimal fallback for environments without pyyaml
    yaml = None

WORD_RE = re.compile(r"[a-zA-Z0-9$%]+")


def tokenize(text: str) -> List[str]:
    return [w.lower() for w in WORD_RE.findall(text)]


def load_yaml(path: Path) -> Dict[str, Any]:
    if yaml:
        return yaml.safe_load(path.read_text())
    raise RuntimeError("PyYAML is required for config parsing. Install with: pip install pyyaml")


@dataclass
class ContextBlock:
    id: str
    source: str
    title: str
    date: str
    customer: str
    text: str
    tags: List[str]
    path: Optional[str] = None
    chunk: Optional[int] = None


class ContextEngine:
    def __init__(self, config_path: str | Path, data_path: str | Path):
        self.config = load_yaml(Path(config_path))
        raw_blocks = json.loads(Path(data_path).read_text())
        self.blocks = [ContextBlock(**b) for b in raw_blocks]
        self._doc_freq = self._build_doc_freq()

    def get_context(self, goal: str, customer: str = "Acme Corp", token_budget: int | None = None) -> Dict[str, Any]:
        token_budget = token_budget or self.config["product"]["default_token_budget"]
        query_terms = tokenize(f"{goal} {customer}")
        scored = []
        for block in self.blocks:
            if block.customer not in (customer, "general"):
                continue
            scored.append(self._score_block(block, query_terms))
        scored.sort(key=lambda x: x["score"], reverse=True)

        selected, used_tokens = [], 0
        for item in scored:
            compressed = self._compress(item["block"], goal)
            approx_tokens = max(1, len(compressed.split()) * 4 // 3)
            if used_tokens + approx_tokens <= token_budget:
                item = {k: v for k, v in item.items() if k != "block"}
                item["compressed"] = compressed
                item["approx_tokens"] = approx_tokens
                selected.append(item)
                used_tokens += approx_tokens

        return {
            "goal": goal,
            "customer": customer,
            "token_budget": token_budget,
            "used_tokens_estimate": used_tokens,
            "context_blocks": selected,
            "briefing": self._compose_briefing(selected, customer),
            "memory_candidates": self._memory_candidates(selected),
            "excluded_context": [s["block"].id for s in scored if s["block"].id not in {x["id"] for x in selected}],
        }

    def _build_doc_freq(self) -> Counter:
        df = Counter()
        for b in self.blocks:
            df.update(set(tokenize(" ".join([b.title, b.text, " ".join(b.tags)]))))
        return df

    def _relevance(self, block: ContextBlock, query_terms: List[str]) -> float:
        corpus = tokenize(" ".join([block.title, block.text, " ".join(block.tags)]))
        counts = Counter(corpus)
        score = 0.0
        n = len(self.blocks)
        for term in query_terms:
            if term in counts:
                idf = math.log((n + 1) / (1 + self._doc_freq[term])) + 1
                score += counts[term] * idf
        return min(score / 10, 1.0)

    def _recency(self, datestr: str) -> float:
        d = datetime.strptime(datestr, "%Y-%m-%d").date()
        days = max(0, (date(2026, 6, 4) - d).days)
        return max(0.0, 1.0 - days / 120)

    def _score_block(self, block: ContextBlock, query_terms: List[str]) -> Dict[str, Any]:
        weights = self.config["ranking"]
        source_cfg = self.config["sources"].get(block.source, {})
        relevance = self._relevance(block, query_terms)
        recency = self._recency(block.date)
        authority = source_cfg.get("authority", 0.5)
        priority = source_cfg.get("priority", 0.5)
        score = (
            relevance * weights["relevance"]
            + recency * weights["recency"]
            + authority * weights["authority"]
            + priority * weights["source_priority"]
            - (1 - recency) * weights["freshness_penalty"]
        )
        return {
            "id": block.id,
            "source": block.source,
            "title": block.title,
            "date": block.date,
            "score": round(score, 3),
            "score_parts": {
                "relevance": round(relevance, 3),
                "recency": round(recency, 3),
                "authority": authority,
                "source_priority": priority,
            },
            "citation": f"{block.source}:{block.id}",
            "path": block.path,
            "chunk": block.chunk,
            "block": block,
        }

    def _compress(self, block: ContextBlock, goal: str) -> str:
        sentences = re.split(r"(?<=[.!?])\s+", block.text.strip())
        goal_terms = set(tokenize(goal))
        ranked = sorted(sentences, key=lambda s: len(goal_terms & set(tokenize(s))), reverse=True)
        max_facts = self.config["compression"]["max_facts_per_block"]
        return " ".join(ranked[:max_facts])

    def _compose_briefing(self, selected: List[Dict[str, Any]], customer: str) -> Dict[str, Any]:
        """Create a lightweight extractive briefing from selected context.

        This avoids inventing facts. It assembles the highest-ranked snippets into
        a task-ready answer and groups likely risks/actions when those words appear.
        """
        snippets = [item.get("compressed", "").strip() for item in selected if item.get("compressed")]
        key_points = []
        risks = []
        actions = []

        for item in selected[:6]:
            text = item.get("compressed", "").strip()
            if not text:
                continue
            title = item.get("title") or item.get("source")
            key_points.append(f"{title}: {text[:450]}{'...' if len(text) > 450 else ''}")

            lower = text.lower()
            if any(word in lower for word in ["risk", "issue", "block", "approval", "exception", "audit", "control", "mandatory", "required"]):
                risks.append(f"Check {title} for required controls, approvals, exceptions, or risks.")
            if any(word in lower for word in ["must", "should", "next", "owner", "action", "submit", "review", "approve"]):
                actions.append(f"Use {title} to confirm the required next step or owner.")

        if snippets:
            summary = (
                f"ContextOS found {len(selected)} relevant context block(s) for this request. "
                "The assembled response below is based only on the indexed documents and should be verified using the cited sources."
            )
        else:
            summary = "No relevant indexed context was found for this request."

        # De-duplicate while preserving order
        risks = list(dict.fromkeys(risks))[:5]
        actions = list(dict.fromkeys(actions))[:5]

        return {
            "summary": summary,
            "key_points": key_points,
            "risks": risks,
            "opportunities": [],
            "recommended_next_actions": actions,
            "citations": [item["citation"] for item in selected[:8]],
        }

    def _memory_candidates(self, selected: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        candidates = []
        for item in selected:
            if item["score"] >= self.config["policies"]["require_confidence_for_memory_write"]:
                candidates.append({
                    "type": "customer_context",
                    "source": item["citation"],
                    "content": item["compressed"],
                    "confidence": item["score"],
                    "action": "propose_write",
                })
        return candidates
