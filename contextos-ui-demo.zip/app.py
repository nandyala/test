from pathlib import Path
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from contextos_demo.engine import ContextEngine

ROOT = Path(__file__).parent
engine = ContextEngine(ROOT / "config/contextos.yaml", ROOT / "contextos_demo/data/blocks.json")
app = FastAPI(title="ContextOS Demo", version="0.2.0")

static_dir = ROOT / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/", response_class=HTMLResponse)
def home():
    return (static_dir / "index.html").read_text(encoding="utf-8")

@app.get("/health")
def health():
    return {"status": "ok", "blocks": len(engine.blocks)}

@app.get("/context")
def context(
    goal: str = Query("Summarize the key policies and actions"),
    customer: str = Query("general"),
    token_budget: int = Query(1200, ge=100, le=8000),
):
    return engine.get_context(goal=goal, customer=customer, token_budget=token_budget)

@app.get("/ask")
def ask(
    q: str = Query(..., description="Question to ask over indexed documents"),
    customer: str = Query("general"),
    token_budget: int = Query(1200, ge=100, le=8000),
):
    return engine.get_context(goal=q, customer=customer, token_budget=token_budget)
