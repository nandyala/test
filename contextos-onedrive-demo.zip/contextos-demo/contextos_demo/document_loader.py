from __future__ import annotations

from pathlib import Path
from typing import Iterable, List, Dict
import hashlib
import re
from datetime import datetime

from docx import Document

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None

SUPPORTED_EXTENSIONS = {".docx", ".txt", ".md", ".pdf"}


def read_file(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".docx":
        doc = Document(str(path))
        paragraphs = [p.text.strip() for p in doc.paragraphs if p.text and p.text.strip()]
        return "\n".join(paragraphs)
    if suffix in {".txt", ".md"}:
        return path.read_text(encoding="utf-8", errors="ignore")
    if suffix == ".pdf":
        if PdfReader is None:
            raise RuntimeError("pypdf is required for PDF parsing. Install requirements.txt")
        reader = PdfReader(str(path))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    raise ValueError(f"Unsupported file type: {suffix}")


def chunk_text(text: str, max_words: int = 220, overlap_words: int = 35) -> List[str]:
    cleaned = re.sub(r"\s+", " ", text).strip()
    words = cleaned.split()
    chunks = []
    step = max(1, max_words - overlap_words)
    for i in range(0, len(words), step):
        chunk = " ".join(words[i:i + max_words]).strip()
        if chunk:
            chunks.append(chunk)
    return chunks


def file_date(path: Path) -> str:
    return datetime.fromtimestamp(path.stat().st_mtime).date().isoformat()


def stable_id(*parts: str) -> str:
    digest = hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()[:12]
    return f"doc-{digest}"


def blocks_from_file(path: Path, source_name: str = "local_docs", customer: str = "general") -> List[Dict]:
    text = read_file(path)
    chunks = chunk_text(text)
    blocks = []
    for idx, chunk in enumerate(chunks):
        blocks.append({
            "id": stable_id(source_name, str(path), str(idx)),
            "source": source_name,
            "title": path.name,
            "date": file_date(path),
            "customer": customer,
            "text": chunk,
            "tags": [path.suffix.lower().replace('.', ''), "document", source_name],
            "path": str(path),
            "chunk": idx,
        })
    return blocks


def iter_supported_files(folder: Path) -> Iterable[Path]:
    for path in folder.rglob("*"):
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS and not path.name.startswith("~$"):
            yield path
