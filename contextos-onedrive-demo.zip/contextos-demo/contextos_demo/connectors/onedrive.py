from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import requests


from contextos_demo.document_loader import SUPPORTED_EXTENSIONS, blocks_from_file

GRAPH_ROOT = "https://graph.microsoft.com/v1.0"
DEFAULT_SCOPES = ["Files.Read", "User.Read"]


def get_token_device_flow(client_id: str, tenant_id: str = "common", scopes: Optional[List[str]] = None) -> str:
    """Interactive CLI login using Microsoft device-code flow."""
    scopes = scopes or DEFAULT_SCOPES
    try:
        import msal
    except ImportError as exc:
        raise RuntimeError("msal is required for OneDrive ingestion. Run: pip install -r requirements.txt") from exc

    app = msal.PublicClientApplication(
        client_id=client_id,
        authority=f"https://login.microsoftonline.com/{tenant_id}",
    )
    accounts = app.get_accounts()
    result = app.acquire_token_silent(scopes, account=accounts[0]) if accounts else None
    if not result:
        flow = app.initiate_device_flow(scopes=scopes)
        if "user_code" not in flow:
            raise RuntimeError(f"Failed to create device flow: {flow}")
        print(flow["message"])
        result = app.acquire_token_by_device_flow(flow)
    if "access_token" not in result:
        raise RuntimeError(f"Could not acquire token: {result}")
    return result["access_token"]


def graph_get(url: str, token: str) -> Dict:
    response = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=60)
    response.raise_for_status()
    return response.json()


def graph_download(url: str, token: str, out_path: Path) -> None:
    response = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=120)
    response.raise_for_status()
    out_path.write_bytes(response.content)


def children_url(folder_path: str = "") -> str:
    folder_path = folder_path.strip("/")
    if not folder_path:
        return f"{GRAPH_ROOT}/me/drive/root/children"
    return f"{GRAPH_ROOT}/me/drive/root:/{folder_path}:/children"


def list_files_recursive(token: str, folder_path: str = "", limit: int = 100) -> Iterable[Dict]:
    stack = [children_url(folder_path)]
    count = 0
    while stack and count < limit:
        url = stack.pop()
        while url and count < limit:
            data = graph_get(url, token)
            for item in data.get("value", []):
                if "folder" in item:
                    stack.append(f"{GRAPH_ROOT}/me/drive/items/{item['id']}/children")
                elif "file" in item:
                    suffix = Path(item.get("name", "")).suffix.lower()
                    if suffix in SUPPORTED_EXTENSIONS:
                        count += 1
                        yield item
                        if count >= limit:
                            break
            url = data.get("@odata.nextLink")


def load_onedrive_folder(
    client_id: str,
    tenant_id: str = "common",
    folder_path: str = "",
    customer: str = "general",
    limit: int = 100,
) -> List[Dict]:
    token = get_token_device_flow(client_id=client_id, tenant_id=tenant_id)
    blocks: List[Dict] = []

    with tempfile.TemporaryDirectory() as tmp:
        tmpdir = Path(tmp)
        for item in list_files_recursive(token, folder_path=folder_path, limit=limit):
            name = item["name"]
            local_path = tmpdir / name
            download_url = f"{GRAPH_ROOT}/me/drive/items/{item['id']}/content"
            try:
                graph_download(download_url, token, local_path)
                item_blocks = blocks_from_file(local_path, source_name="onedrive", customer=customer)
                for block in item_blocks:
                    block["title"] = name
                    block["path"] = item.get("webUrl", item.get("parentReference", {}).get("path", "OneDrive"))
                    block["date"] = item.get("lastModifiedDateTime", "")[:10] or block["date"]
                    block["onedrive_item_id"] = item["id"]
                blocks.extend(item_blocks)
            except Exception as exc:
                print(f"Skipped OneDrive item {name}: {exc}")
    return blocks
