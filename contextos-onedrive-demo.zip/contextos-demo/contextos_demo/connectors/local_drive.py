from __future__ import annotations

from pathlib import Path
from typing import List, Dict

from contextos_demo.document_loader import iter_supported_files, blocks_from_file


def load_local_folder(folder: str | Path, customer: str = "general") -> List[Dict]:
    folder = Path(folder)
    if not folder.exists():
        raise FileNotFoundError(f"Folder not found: {folder}")

    blocks: List[Dict] = []
    for path in iter_supported_files(folder):
        try:
            blocks.extend(blocks_from_file(path, source_name="local_docs", customer=customer))
        except Exception as exc:
            print(f"Skipped {path}: {exc}")
    return blocks
