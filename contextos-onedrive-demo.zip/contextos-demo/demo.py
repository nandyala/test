import json
from pathlib import Path
from contextos_demo.engine import ContextEngine

ROOT = Path(__file__).parent
engine = ContextEngine(ROOT / "config/contextos.yaml", ROOT / "contextos_demo/data/blocks.json")
result = engine.get_context(
    goal="Prepare renewal briefing with risks, expansion opportunity, blockers, and next best action",
    customer="Acme Corp",
    token_budget=900,
)
print(json.dumps(result, indent=2))
