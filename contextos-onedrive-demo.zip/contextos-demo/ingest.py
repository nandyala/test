from __future__ import annotations

import argparse
import json
from pathlib import Path

from contextos_demo.connectors.local_drive import load_local_folder
from contextos_demo.connectors.onedrive import load_onedrive_folder

ROOT = Path(__file__).parent
DEFAULT_OUT = ROOT / "contextos_demo/data/blocks.json"


def write_blocks(blocks, output: Path, append: bool):
    existing = []
    if append and output.exists():
        existing = json.loads(output.read_text(encoding="utf-8"))
    merged = existing + blocks
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(merged, indent=2), encoding="utf-8")
    print(f"Wrote {len(blocks)} new blocks, {len(merged)} total blocks -> {output}")


def main():
    parser = argparse.ArgumentParser(description="Ingest documents into ContextOS blocks.json")
    parser.add_argument("--source", choices=["local", "onedrive"], required=True)
    parser.add_argument("--path", default="docs", help="Local folder path, or OneDrive folder path relative to root")
    parser.add_argument("--customer", default="general", help="Optional grouping label used by the demo engine")
    parser.add_argument("--output", default=str(DEFAULT_OUT))
    parser.add_argument("--append", action="store_true", help="Append to existing blocks.json instead of replacing it")
    parser.add_argument("--client-id", default=None, help="Azure app/client ID for OneDrive device-code auth")
    parser.add_argument("--tenant-id", default="common", help="Tenant ID, or 'common' for demo")
    parser.add_argument("--limit", type=int, default=50, help="Max OneDrive files to ingest")
    args = parser.parse_args()

    if args.source == "local":
        blocks = load_local_folder(args.path, customer=args.customer)
    else:
        if not args.client_id:
            raise SystemExit("--client-id is required for OneDrive ingestion")
        blocks = load_onedrive_folder(
            client_id=args.client_id,
            tenant_id=args.tenant_id,
            folder_path=args.path,
            customer=args.customer,
            limit=args.limit,
        )

    write_blocks(blocks, Path(args.output), args.append)


if __name__ == "__main__":
    main()
