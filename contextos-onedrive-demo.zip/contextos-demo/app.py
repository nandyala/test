from pathlib import Path
from fastapi import FastAPI, Query
from contextos_demo.engine import ContextEngine

ROOT = Path(__file__).parent
engine = ContextEngine(ROOT / "config/contextos.yaml", ROOT / "contextos_demo/data/blocks.json")
app = FastAPI(title="ContextOS Demo", version="0.1.0")

@app.get("/")
def home():
    return {
        "name": "ContextOS Demo",
        "try": "/context?customer=Acme%20Corp&goal=Prepare%20renewal%20briefing",
    }

@app.get("/context")
def context(
    goal: str = Query("Prepare renewal briefing with risks, expansion opportunity, blockers, and next best action"),
    customer: str = Query("Acme Corp"),
    token_budget: int = Query(900, ge=100, le=8000),
):
    return engine.get_context(goal=goal, customer=customer, token_budget=token_budget)
