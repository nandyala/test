# ContextOS Demo with Local + OneDrive Connectors

A lightweight demo of ContextOS: ingest documents, rank context, compress into a token budget, and return cited context blocks.

## Supported document inputs

- Local folder: `.docx`, `.pdf`, `.txt`, `.md`
- OneDrive folder via Microsoft Graph: `.docx`, `.pdf`, `.txt`, `.md`

## Install on Windows

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Option A: Ingest local documents

Put your files in the `docs/` folder, then run:

```powershell
python ingest.py --source local --path docs --customer general
```

Ask a question through the API:

```powershell
uvicorn app:app --reload
```

Open:

```text
http://127.0.0.1:8000/context?customer=general&goal=What%20is%20the%20vendor%20onboarding%20process
```

## Option B: Ingest OneDrive documents

1. Register an app in Microsoft Entra ID.
2. Use a **public client / mobile and desktop** app registration.
3. Allow delegated Microsoft Graph permissions: `Files.Read` and `User.Read`.
4. Copy the Application / client ID.

Run:

```powershell
python ingest.py --source onedrive --path "ContextOSDemo" --client-id "YOUR_CLIENT_ID" --tenant-id "common" --customer general --limit 20
```

The console will show a Microsoft device-code login message. Sign in, then the connector downloads supported files temporarily, extracts text, and writes indexed blocks to `contextos_demo/data/blocks.json`.

## Append instead of replace

```powershell
python ingest.py --source local --path docs --append
python ingest.py --source onedrive --path "ContextOSDemo" --client-id "YOUR_CLIENT_ID" --append
```

## API

```powershell
uvicorn app:app --reload
```

```text
/context?customer=general&goal=your question here&token_budget=1200
```

## Demo architecture

```text
Local folder / OneDrive
  -> connector
  -> text extraction
  -> chunks
  -> blocks.json
  -> ContextEngine
  -> ranked context + citations
  -> API response
```

## Notes for bank demos

For a real bank environment, use tenant-specific app registration, least-privilege delegated access, permission-aware retrieval, audit logs, and approved network/security controls. This demo intentionally keeps the data local after ingestion.
